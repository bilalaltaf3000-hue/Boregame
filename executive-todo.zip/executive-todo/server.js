'use strict';
// Executive To-Do - a private, offline task list with user accounts.
// Zero dependencies: only Node.js built-ins.

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const store = require('./store');

const PORT = parseInt(process.env.PORT || '3001', 10);
const HOST = process.env.HOST || '0.0.0.0';
const ALLOW_SIGNUP = String(process.env.ALLOW_SIGNUP || 'true').toLowerCase() !== 'false';
const PUBLIC_DIR = path.join(__dirname, 'public');
const COOKIE = 'etd_session';
const MAX_BODY = 64 * 1024;
const MAX_TASKS = 5000;

store.ensureDirs();

function log() {
  console.log.apply(console, ['[' + new Date().toISOString() + ']'].concat([].slice.call(arguments)));
}

// ---------------------------------------------------------------- helpers
const SEC_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'no-referrer',
  'Content-Security-Policy': "default-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; font-src 'self'; connect-src 'self'; frame-ancestors 'none'; form-action 'self'; base-uri 'none'"
};

function send(res, status, obj, extraHeaders) {
  const body = JSON.stringify(obj);
  res.writeHead(status, Object.assign({
    'Content-Type': 'application/json; charset=utf-8',
    'Content-Length': Buffer.byteLength(body),
    'Cache-Control': 'no-store'
  }, SEC_HEADERS, extraHeaders || {}));
  res.end(body);
}

function parseCookies(req) {
  const out = {};
  (req.headers.cookie || '').split(';').forEach((c) => {
    const i = c.indexOf('=');
    if (i > 0) out[c.slice(0, i).trim()] = decodeURIComponent(c.slice(i + 1).trim());
  });
  return out;
}

function sessionCookie(token, maxAgeSec) {
  return COOKIE + '=' + (token || '') + '; Path=/; HttpOnly; SameSite=Strict; Max-Age=' + maxAgeSec +
    (process.env.COOKIE_SECURE === 'true' ? '; Secure' : '');
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    const tooLarge = () => Object.assign(new Error('Request too large'), { status: 413 });
    if (parseInt(req.headers['content-length'] || '0', 10) > MAX_BODY) { req.resume(); return reject(tooLarge()); }
    let size = 0;
    let over = false;
    const chunks = [];
    req.on('data', (c) => {
      size += c.length;
      if (size > MAX_BODY) { over = true; chunks.length = 0; return; } // keep draining, store nothing
      chunks.push(c);
    });
    req.on('end', () => {
      if (over) return reject(tooLarge());
      if (!chunks.length) return resolve({});
      try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
      catch (e) { reject(Object.assign(new Error('Invalid JSON'), { status: 400 })); }
    });
    req.on('error', reject);
  });
}

function clientIp(req) { return (req.socket && req.socket.remoteAddress) || 'unknown'; }

// ---------------------------------------------------------------- login rate limit
const attempts = new Map(); // key -> [timestamps]
function tooMany(key) {
  const now = Date.now();
  const list = (attempts.get(key) || []).filter((t) => now - t < 10 * 60 * 1000);
  attempts.set(key, list);
  return list.length >= 8;
}
function recordFail(key) { const l = attempts.get(key) || []; l.push(Date.now()); attempts.set(key, l); }
setInterval(() => { const now = Date.now(); attempts.forEach((l, k) => { if (!l.some((t) => now - t < 600000)) attempts.delete(k); }); }, 600000).unref();

// ---------------------------------------------------------------- validation
const USER_RE = /^[a-z0-9][a-z0-9._-]{2,31}$/;
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const PRIORITIES = ['high', 'medium', 'low'];
const STATUSES = ['todo', 'doing', 'done'];

function cleanText(v, max) {
  return String(v == null ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g, '').trim().slice(0, max);
}
function validPassword(p) { return typeof p === 'string' && p.length >= 8 && p.length <= 200; }

function applyTaskFields(task, body, isNew) {
  if (isNew || 'title' in body) {
    const t = cleanText(body.title, 200).replace(/\s+/g, ' ');
    if (!t) throw Object.assign(new Error('Title is required'), { status: 400 });
    task.title = t;
  }
  if ('notes' in body) task.notes = cleanText(body.notes, 4000);
  if ('priority' in body) {
    if (PRIORITIES.indexOf(body.priority) === -1) throw Object.assign(new Error('Bad priority'), { status: 400 });
    task.priority = body.priority;
  }
  if ('due' in body) {
    if (body.due === null || body.due === '') task.due = null;
    else if (DATE_RE.test(body.due) && !isNaN(Date.parse(body.due))) task.due = body.due;
    else throw Object.assign(new Error('Bad due date'), { status: 400 });
  }
  if ('category' in body) task.category = cleanText(body.category, 40);
  if ('delegatedTo' in body) task.delegatedTo = cleanText(body.delegatedTo, 60);
  if ('order' in body) {
    const o = Number(body.order);
    if (!isFinite(o)) throw Object.assign(new Error('Bad order'), { status: 400 });
    task.order = o;
  }
  if ('status' in body) {
    if (STATUSES.indexOf(body.status) === -1) throw Object.assign(new Error('Bad column'), { status: 400 });
    task.status = body.status;
    body = Object.assign({}, body, { done: body.status === 'done' });
  }
  if ('done' in body) {
    const d = !!body.done;
    if (!('status' in body)) task.status = d ? 'done' : (task.status === 'done' ? 'todo' : (task.status || 'todo'));
    if (d && !task.done) task.doneAt = new Date().toISOString();
    if (!d) task.doneAt = null;
    task.done = d;
  }
  if ('pinned' in body) task.pinned = !!body.pinned;
}

function publicUser(u) { return { id: u.id, username: u.username, name: u.name, isAdmin: !!u.isAdmin }; }

// ---------------------------------------------------------------- API
async function api(req, res, urlPath) {
  const method = req.method;

  // CSRF guard: state-changing requests must be same-origin fetch() calls with JSON
  if (method !== 'GET') {
    const ct = req.headers['content-type'] || '';
    if (req.headers['x-requested-with'] !== 'fetch' || ct.indexOf('application/json') !== 0) {
      return send(res, 403, { error: 'Forbidden' });
    }
    const origin = req.headers.origin;
    if (origin && origin.replace(/^https?:\/\//, '') !== req.headers.host) return send(res, 403, { error: 'Forbidden' });
  }

  const cookies = parseCookies(req);
  const token = cookies[COOKIE];
  const session = store.getSession(token);
  const user = session ? store.findUserById(session.userId) : null;

  // ---- public endpoints
  if (urlPath === '/api/config' && method === 'GET') {
    return send(res, 200, { allowSignup: ALLOW_SIGNUP, hasUsers: store.loadUsers().users.length > 0 });
  }

  if (urlPath === '/api/signup' && method === 'POST') {
    const firstUser = store.loadUsers().users.length === 0;
    if (!ALLOW_SIGNUP && !firstUser) return send(res, 403, { error: 'Sign-up is turned off. Ask the administrator for an account.' });
    const ipKey = 'signup:' + clientIp(req);
    if (tooMany(ipKey)) return send(res, 429, { error: 'Too many attempts. Try again in a few minutes.' });
    const b = await readBody(req);
    const username = cleanText(b.username, 32).toLowerCase();
    const name = cleanText(b.name, 60) || username;
    if (!USER_RE.test(username)) return send(res, 400, { error: 'Username: 3-32 characters, letters, numbers, dot, dash or underscore.' });
    if (!validPassword(b.password)) return send(res, 400, { error: 'Password must be at least 8 characters.' });
    if (store.findUserByName(username)) { recordFail(ipKey); return send(res, 409, { error: 'That username is taken.' }); }
    const u = store.createUser(username, name, b.password);
    const t = store.createSession(u.id);
    log('signup', username, u.isAdmin ? '(admin)' : '');
    return send(res, 201, { user: publicUser(u) }, { 'Set-Cookie': sessionCookie(t, 14 * 86400) });
  }

  if (urlPath === '/api/login' && method === 'POST') {
    const b = await readBody(req);
    const username = cleanText(b.username, 32).toLowerCase();
    const ipKey = 'login:' + clientIp(req), userKey = 'user:' + username;
    if (tooMany(ipKey) || tooMany(userKey)) return send(res, 429, { error: 'Too many failed attempts. Try again in 10 minutes.' });
    const u = store.findUserByName(username);
    // always run a hash so response time doesn't reveal whether the user exists
    const ok = u ? store.verifyPassword(u, String(b.password || '')) : (store.verifyPassword({ salt: 'x', hash: '00' }, 'x'), false);
    if (!ok) {
      recordFail(ipKey); recordFail(userKey);
      log('login failed', username, clientIp(req));
      return send(res, 401, { error: 'Wrong username or password.' });
    }
    attempts.delete(userKey);
    const t = store.createSession(u.id);
    log('login', username);
    return send(res, 200, { user: publicUser(u) }, { 'Set-Cookie': sessionCookie(t, 14 * 86400) });
  }

  if (urlPath === '/api/logout' && method === 'POST') {
    store.destroySession(token);
    return send(res, 200, { ok: true }, { 'Set-Cookie': sessionCookie('', 0) });
  }

  // ---- everything below needs a signed-in user
  if (!user) return send(res, 401, { error: 'Please sign in.' }, token ? { 'Set-Cookie': sessionCookie('', 0) } : null);

  if (urlPath === '/api/me' && method === 'GET') return send(res, 200, { user: publicUser(user) });

  if (urlPath === '/api/password' && method === 'POST') {
    const b = await readBody(req);
    if (!store.verifyPassword(user, String(b.current || ''))) return send(res, 400, { error: 'Current password is wrong.' });
    if (!validPassword(b.next)) return send(res, 400, { error: 'New password must be at least 8 characters.' });
    store.setPassword(user, b.next);
    store.removeSessionsForUser(user.id, token); // sign out other devices
    log('password changed', user.username);
    return send(res, 200, { ok: true });
  }

  if (urlPath === '/api/profile' && method === 'PATCH') {
    const b = await readBody(req);
    const name = cleanText(b.name, 60);
    if (!name) return send(res, 400, { error: 'Name is required.' });
    store.setName(user, name);
    return send(res, 200, { user: publicUser(user) });
  }

  if (urlPath === '/api/todos' && method === 'GET') return send(res, 200, { todos: store.getTodos(user.id) });

  if (urlPath === '/api/todos' && method === 'POST') {
    const list = store.getTodos(user.id);
    if (list.length >= MAX_TASKS) return send(res, 400, { error: 'Task limit reached. Delete some completed tasks.' });
    const b = await readBody(req);
    const now = new Date().toISOString();
    const task = { id: crypto.randomUUID(), title: '', notes: '', priority: 'medium', due: null, category: '', delegatedTo: '', status: 'todo', order: null, done: false, doneAt: null, pinned: false, createdAt: now, updatedAt: now };
    applyTaskFields(task, b, true);
    if (task.order === null) {
      // new cards go to the bottom of their column
      const max = list.filter((t) => (t.status || (t.done ? 'done' : 'todo')) === task.status)
        .reduce((m, t) => Math.max(m, typeof t.order === 'number' ? t.order : 0), 0);
      task.order = max + 1024;
    }
    list.push(task);
    store.saveTodos(user.id);
    return send(res, 201, { todo: task });
  }

  const m = urlPath.match(/^\/api\/todos\/([0-9a-f-]{36})$/);
  if (m) {
    const list = store.getTodos(user.id);
    const idx = list.findIndex((t) => t.id === m[1]);
    if (idx === -1) return send(res, 404, { error: 'Task not found.' });
    if (method === 'PATCH') {
      const b = await readBody(req);
      const copy = Object.assign({}, list[idx]);
      applyTaskFields(copy, b, false);
      copy.updatedAt = new Date().toISOString();
      list[idx] = copy;
      store.saveTodos(user.id);
      return send(res, 200, { todo: copy });
    }
    if (method === 'DELETE') {
      list.splice(idx, 1);
      store.saveTodos(user.id);
      return send(res, 200, { ok: true });
    }
  }

  if (urlPath === '/api/todos/clear-completed' && method === 'POST') {
    const list = store.getTodos(user.id);
    const before = list.length;
    for (let i = list.length - 1; i >= 0; i--) if (list[i].done) list.splice(i, 1);
    store.saveTodos(user.id);
    return send(res, 200, { removed: before - list.length });
  }

  return send(res, 404, { error: 'Not found' });
}

// ---------------------------------------------------------------- static files
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.woff2': 'font/woff2', '.svg': 'image/svg+xml', '.txt': 'text/plain; charset=utf-8'
};

function serveStatic(req, res, urlPath) {
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  if (urlPath === '/') urlPath = '/index.html';
  const filePath = path.normalize(path.join(PUBLIC_DIR, urlPath));
  if (filePath.indexOf(PUBLIC_DIR + path.sep) !== 0) { res.writeHead(403); return res.end(); }
  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, Object.assign({ 'Content-Type': 'text/plain' }, SEC_HEADERS)); return res.end('Not found'); }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, Object.assign({
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': ext === '.woff2' ? 'public, max-age=604800' : 'no-cache'
    }, SEC_HEADERS));
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(filePath).pipe(res);
  });
}

// ---------------------------------------------------------------- server
const server = http.createServer(async (req, res) => {
  let urlPath;
  try { urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname); }
  catch (e) { res.writeHead(400); return res.end(); }
  if (urlPath === '/health') return send(res, 200, { ok: true, users: store.loadUsers().users.length });
  if (urlPath.indexOf('/api/') === 0) {
    try { await api(req, res, urlPath); }
    catch (e) {
      if (!res.headersSent) send(res, e.status || 500, { error: e.status ? e.message : 'Server error' });
      if (!e.status) log('error', e.stack || e.message);
    }
    return;
  }
  serveStatic(req, res, urlPath);
});

server.listen(PORT, HOST, () => {
  log('Executive To-Do running on http://' + HOST + ':' + PORT + ' (data: ' + store.DATA_DIR + ', sign-up ' + (ALLOW_SIGNUP ? 'on' : 'off') + ')');
});

function shutdown(sig) {
  log('received ' + sig + ', shutting down');
  try { store.flushSessions(); } catch (e) { /* ignore */ }
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 2000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
