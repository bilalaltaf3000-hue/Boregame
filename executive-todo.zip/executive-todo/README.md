# Executive To-Do

A clean, private task list for your team, hosted on your own VM.

- Each person signs in and sees **only their own tasks**.
- Works fully **offline**. It has no dependencies (just Node.js), so there is no `npm install`.
- Runs as a **systemd service** on port **3001**: it survives PuTTY timeouts and reboots.
- Installs to `/data/executive-todo`. Data is stored in `/data/executive-todo/data`.

---

## 1. Install (about 1 minute)

Upload `executive-todo.zip` to `/tmp` on the VM with WinSCP, then in PuTTY run:

```bash
sudo python3 -m zipfile -e /tmp/executive-todo.zip /data/
sudo bash /data/executive-todo/deploy/install.sh
```

The installer:

1. Finds Node.js (including `/data/node-v20…`) and applies the SELinux label fix automatically.
2. Creates a locked-down system user `etodo`.
3. Creates the private data folder.
4. Writes the settings file `/etc/executive-todo.env`.
5. Creates and starts the systemd service `executive-todo`.
6. Opens port 3001/tcp in firewalld.

Then open `http://<VM-IP>:3001`.

> **The first account created becomes the administrator.** Create yours right after installing.

---

## 2. Accounts

Out of the box, anyone who can open the page can create an account (**self sign-up**).
You can switch that off once everyone is set up. You then add new users yourself.

```bash
M="sudo bash /data/executive-todo/deploy/manage.sh"

$M list                          # all users and their open task counts
$M add-user ali "Ali Raza"       # create a user, prints a temporary password
$M reset-password ali            # new temporary password, signs them out everywhere
$M delete-user ali               # removes the user AND all their tasks
$M make-admin ali
$M signup off                    # block self sign-up (on to allow again)
```

The tool briefly stops and restarts the service while it saves changes (about 1 second).

Users can change their own password and display name from the menu under their name (top right).

### Security in brief

- Passwords are hashed with **scrypt**. They are never stored in plain text.
- Sessions use a random token in an **HttpOnly, SameSite=Strict** cookie, valid for 14 days of inactivity.
- **Repeated wrong passwords are blocked** for 10 minutes.
- **Requests from other websites are rejected** (cross-site request forgery protection), and a strict Content-Security-Policy is applied.
- **Changing a password signs out all other devices.**
- Traffic is plain HTTP on your LAN. If you later put it behind HTTPS (e.g. nginx), add `COOKIE_SECURE=true` to the settings file.

---

## 3. Everyday commands

```bash
sudo systemctl status executive-todo       # running?
sudo systemctl restart executive-todo      # restart (e.g. after editing /etc/executive-todo.env)
sudo journalctl -u executive-todo -f       # live logs: sign-ins, failed logins, errors
curl -s http://127.0.0.1:3001/health       # quick check
```

### Backup

Everything lives in one folder:

```bash
sudo tar czf /data/executive-todo-backup-$(date +%F).tgz -C /data/executive-todo data
```

To restore, stop the service, extract the backup over `/data/executive-todo/`, then start the service again.

### Update to a new version

Your data and settings are kept:

```bash
sudo python3 -m zipfile -e /tmp/executive-todo.zip /data/
sudo bash /data/executive-todo/deploy/install.sh
```

### Remove

```bash
sudo bash /data/executive-todo/deploy/uninstall.sh
```

This removes the service but keeps your data.

---

## 4. Using it

Each person gets a simple board with three columns: **To do**, **In progress** and **Done**.

- **Add a card:** click **Add a card** under any column, type, and press Enter. The box stays open so you can add several cards in a row; press Esc when finished.
- **Move a card:** drag it to another column, or up and down to reorder. On a phone, **press and hold** a card for a moment, then drag. **Undo** appears after a move.
- **Edit a card:** click it to change the title, add notes, set a due date, mark it **High priority**, move it to another column, or delete it.
- Cards show a red **High** tag, plus a due-date tag that turns amber on the due day and red once overdue.
- **Clear** in the Done column removes all finished cards.
- The moon icon switches light/dark mode, remembered per browser.

---

## 5. Troubleshooting

| Symptom | Check |
|---|---|
| `status=203/EXEC` in the logs | SELinux label on Node. Run `sudo chcon -R -t bin_t /data/node-v20.18.0-linux-x64/bin`, then restart. |
| Page not reachable from other PCs | `sudo firewall-cmd --list-ports` should include `3001/tcp`. If it does, a network firewall may need TCP 3001 opened by IT. |
| `EADDRINUSE` in the logs | Another program uses 3001. Change `PORT=` in `/etc/executive-todo.env` and re-run the installer. |
| Someone forgot their password | `sudo bash /data/executive-todo/deploy/manage.sh reset-password <username>` |
| "Too many failed attempts" | Wait 10 minutes, or restart the service to clear the counter. |
