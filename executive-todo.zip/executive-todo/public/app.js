/* Executive To-Do - simple card board with drag and drop */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var todos = [];
  var me = null;
  var config = { allowSignup: true, hasUsers: true };
  var editing = null;
  var COLS = ['todo', 'doing', 'done'];
  var COL_NAME = { todo: 'To do', doing: 'In progress', done: 'Done' };

  // ------------------------------------------------------------ api
  function api(method, url, body) {
    var opts = { method: method, credentials: 'same-origin', headers: { 'X-Requested-With': 'fetch' } };
    if (method !== 'GET') { opts.headers['Content-Type'] = 'application/json'; opts.body = JSON.stringify(body || {}); }
    return fetch(url, opts).then(function (r) {
      return r.json().catch(function () { return {}; }).then(function (data) {
        if (r.status === 401 && url !== '/api/login' && url !== '/api/me') showAuth();
        if (!r.ok) throw new Error(data.error || 'Something went wrong.');
        return data;
      });
    }, function () { throw new Error('Cannot reach the server. Check your connection.'); });
  }

  // ------------------------------------------------------------ helpers
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text != null) n.textContent = text;
    return n;
  }
  function icon(paths) {
    var s = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
    s.setAttribute('viewBox', '0 0 24 24'); s.setAttribute('aria-hidden', 'true');
    paths.forEach(function (d) { var p = document.createElementNS('http://www.w3.org/2000/svg', 'path'); p.setAttribute('d', d); s.appendChild(p); });
    return s;
  }
  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function isoDay(d) { return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()); }
  function parseDay(s) { var p = s.split('-'); return new Date(+p[0], +p[1] - 1, +p[2]); }
  function dayDiff(s) { return Math.round((parseDay(s) - parseDay(isoDay(new Date()))) / 864e5); }
  function fmtDue(s) {
    var d = dayDiff(s);
    if (d === 0) return 'Today';
    if (d === 1) return 'Tomorrow';
    if (d === -1) return 'Yesterday';
    var dt = parseDay(s);
    var o = { day: 'numeric', month: 'short' };
    if (dt.getFullYear() !== new Date().getFullYear()) o.year = 'numeric';
    return dt.toLocaleDateString(undefined, o);
  }
  function statusOf(t) { return t.status || (t.done ? 'done' : 'todo'); }
  function orderOf(t) { return typeof t.order === 'number' ? t.order : Date.parse(t.createdAt) / 1e6; }
  function byId(id) { for (var i = 0; i < todos.length; i++) if (todos[i].id === id) return todos[i]; return null; }
  function replaceTodo(t) { for (var i = 0; i < todos.length; i++) if (todos[i].id === t.id) { todos[i] = t; return; } todos.push(t); }
  function colCards(status) { return todos.filter(function (t) { return statusOf(t) === status; }).sort(function (a, b) { return orderOf(a) - orderOf(b); }); }

  // ------------------------------------------------------------ auth
  var authMode = 'login';
  function setAuthMode(mode) {
    authMode = mode;
    var signup = mode === 'signup';
    $('authTitle').textContent = signup ? (config.hasUsers ? 'Create your account' : 'Set up the first account') : 'Sign in';
    $('authSub').textContent = signup ? (config.hasUsers ? 'Takes less than a minute.' : 'This account becomes the administrator.') : 'Your priorities, in one place.';
    $('nameRow').hidden = !signup;
    $('passHint').hidden = !signup;
    $('fPass').setAttribute('autocomplete', signup ? 'new-password' : 'current-password');
    $('authSubmit').textContent = signup ? 'Create account' : 'Sign in';
    $('switchText').textContent = signup ? 'Already have an account?' : 'New here?';
    $('switchBtn').textContent = signup ? 'Sign in' : 'Create an account';
    $('switchRow').hidden = !config.allowSignup && config.hasUsers;
    $('authError').textContent = '';
  }
  $('switchBtn').addEventListener('click', function () { setAuthMode(authMode === 'login' ? 'signup' : 'login'); (authMode === 'signup' ? $('fName') : $('fUser')).focus(); });
  $('authForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var body = { username: $('fUser').value.trim(), password: $('fPass').value };
    if (!body.username || !body.password) { $('authError').textContent = 'Enter your username and password.'; return; }
    if (authMode === 'signup') {
      body.name = $('fName').value.trim();
      if (body.password.length < 8) { $('authError').textContent = 'Password must be at least 8 characters.'; return; }
    }
    $('authSubmit').disabled = true;
    api('POST', authMode === 'signup' ? '/api/signup' : '/api/login', body).then(function (d) {
      $('fPass').value = '';
      startApp(d.user);
    }).catch(function (err) { $('authError').textContent = err.message; })
      .then(function () { $('authSubmit').disabled = false; });
  });
  function showAuth() {
    me = null; todos = [];
    closeCard(); closeDialog();
    $('toast').hidden = true;
    $('app').hidden = true;
    $('auth').hidden = false;
    api('GET', '/api/config').then(function (c) { config = c; setAuthMode(c.hasUsers ? 'login' : 'signup'); })
      .catch(function () { setAuthMode('login'); })
      .then(function () { (authMode === 'signup' ? $('fName') : $('fUser')).focus(); });
  }

  function startApp(user) {
    me = user;
    $('auth').hidden = true;
    $('app').hidden = false;
    $('userName').textContent = user.name;
    $('userInitial').textContent = (user.name || user.username).charAt(0).toUpperCase();
    var h = new Date().getHours();
    $('greeting').textContent = (h < 12 ? 'Good morning, ' : h < 17 ? 'Good afternoon, ' : 'Good evening, ') + (user.name || user.username).split(' ')[0];
    api('GET', '/api/todos').then(function (d) { todos = d.todos || []; render(); }).catch(function (e) { toast(e.message); });
  }

  // ------------------------------------------------------------ render
  function render() {
    COLS.forEach(function (s) {
      var box = document.querySelector('.cards[data-status="' + s + '"]');
      box.innerHTML = '';
      var list = colCards(s);
      list.forEach(function (t) { box.appendChild(cardEl(t)); });
      document.querySelector('[data-count="' + s + '"]').textContent = list.length;
    });
    $('clearDone').hidden = !colCards('done').length;
    var n = { todo: colCards('todo').length, doing: colCards('doing').length, done: colCards('done').length };
    var overdue = todos.filter(function (t) { return statusOf(t) !== 'done' && t.due && dayDiff(t.due) < 0; }).length;
    $('summary').textContent = n.todo + ' to do · ' + n.doing + ' in progress · ' + n.done + ' done' + (overdue ? ' · ' + overdue + ' overdue' : '');
  }

  function cardEl(t) {
    var c = el('div', 'card');
    c.setAttribute('role', 'button');
    c.tabIndex = 0;
    c.setAttribute('data-id', t.id);
    c.setAttribute('aria-label', t.title + ', in ' + COL_NAME[statusOf(t)] + '. Press Enter to edit.');
    c.appendChild(el('div', 'card-title', t.title));
    var meta = el('div', 'card-meta');
    if (t.priority === 'high' && statusOf(t) !== 'done') meta.appendChild(el('span', 'chip high', 'High'));
    if (t.due) {
      var d = dayDiff(t.due), live = statusOf(t) !== 'done';
      var chip = el('span', 'chip' + (live && d < 0 ? ' overdue' : live && d === 0 ? ' today' : ''));
      chip.appendChild(icon(['M4 6.5h16v13H4z', 'M4 10.5h16M8.5 4v4M15.5 4v4']));
      chip.appendChild(document.createTextNode(fmtDue(t.due)));
      meta.appendChild(chip);
    }
    if (t.notes) { var nt = el('span', 'chip'); nt.appendChild(icon(['M6 4h9l4 4v12H6z', 'M9 12h7M9 16h5'])); nt.setAttribute('aria-label', 'Has notes'); meta.appendChild(nt); }
    c.appendChild(meta);
    c.addEventListener('keydown', function (e) { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openCard(t.id); } });
    c.addEventListener('contextmenu', function (e) { if (drag) e.preventDefault(); });
    return c;
  }

  // ------------------------------------------------------------ add card (composer)
  function buildComposers() {
    document.querySelectorAll('.composer-slot').forEach(function (slot) {
      var status = slot.getAttribute('data-status');
      slot.innerHTML = '';
      var btn = el('button', 'add-card');
      btn.type = 'button';
      btn.appendChild(icon(['M12 5v14M5 12h14']));
      btn.appendChild(document.createTextNode('Add a card'));
      var form = el('form', 'composer');
      form.hidden = true;
      var ta = el('textarea');
      ta.maxLength = 200; ta.placeholder = 'What needs doing?';
      ta.setAttribute('aria-label', 'New card in ' + COL_NAME[status]);
      var actions = el('div', 'composer-actions');
      var add = el('button', 'btn btn-primary btn-sm', 'Add card'); add.type = 'submit';
      var cancel = el('button', 'icon-btn'); cancel.type = 'button'; cancel.setAttribute('aria-label', 'Cancel');
      cancel.appendChild(icon(['M6 6l12 12M18 6 6 18']));
      actions.appendChild(add); actions.appendChild(cancel);
      form.appendChild(ta); form.appendChild(actions);
      slot.appendChild(btn); slot.appendChild(form);

      function open() { btn.hidden = true; form.hidden = false; ta.focus(); }
      function close() { form.hidden = true; btn.hidden = false; ta.value = ''; }
      btn.addEventListener('click', open);
      cancel.addEventListener('click', close);
      ta.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); form.requestSubmit ? form.requestSubmit() : form.dispatchEvent(new Event('submit', { cancelable: true })); }
        if (e.key === 'Escape') { e.stopPropagation(); close(); btn.focus(); }
      });
      form.addEventListener('submit', function (e) {
        e.preventDefault();
        var title = ta.value.replace(/\s+/g, ' ').trim();
        if (!title) { ta.focus(); return; }
        add.disabled = true;
        api('POST', '/api/todos', { title: title, status: status }).then(function (d) {
          todos.push(d.todo); render(); ta.value = ''; ta.focus();
        }).catch(function (err) { toast(err.message); }).then(function () { add.disabled = false; });
      });
    });
  }
  buildComposers();

  // ------------------------------------------------------------ drag and drop (mouse + touch, pointer events)
  var drag = null;
  var suppressClick = false;

  document.addEventListener('pointerdown', function (e) {
    var card = e.target.closest && e.target.closest('.card');
    if (!card || drag || (e.pointerType === 'mouse' && e.button !== 0)) return;
    drag = { card: card, id: card.getAttribute('data-id'), x0: e.clientX, y0: e.clientY, x: e.clientX, y: e.clientY, pid: e.pointerId, touch: e.pointerType !== 'mouse', started: false, timer: null };
    if (drag.touch) {
      // press and hold to pick up, so normal swipes still scroll the page
      drag.timer = setTimeout(function () { if (drag && !drag.started) { card.classList.add('lifting'); if (navigator.vibrate) { try { navigator.vibrate(15); } catch (x) {} } beginDrag(); } }, 260);
    }
  });

  document.addEventListener('pointermove', function (e) {
    if (!drag || e.pointerId !== drag.pid) return;
    drag.x = e.clientX; drag.y = e.clientY;
    var moved = Math.abs(e.clientX - drag.x0) + Math.abs(e.clientY - drag.y0);
    if (!drag.started) {
      if (drag.touch) { if (moved > 10) cancelDrag(); return; } // finger moved before hold: it's a scroll
      if (moved > 5) beginDrag(); else return;
    }
    e.preventDefault();
    moveGhost();
    updatePlaceholder();
    autoScroll();
  });

  // stop the browser from scrolling while a card is being dragged by touch
  document.addEventListener('touchmove', function (e) { if (drag && drag.started) e.preventDefault(); }, { passive: false });

  document.addEventListener('pointerup', function (e) {
    if (!drag || e.pointerId !== drag.pid) return;
    if (drag.started) { finishDrag(); return; }
    var id = drag.id;
    cancelDrag();
    if (!suppressClick) openCard(id);
  });
  document.addEventListener('pointercancel', function () { if (drag) { if (drag.started) finishDrag(); else cancelDrag(); } });

  function beginDrag() {
    var c = drag.card, r = c.getBoundingClientRect();
    drag.started = true;
    drag.dx = drag.x - r.left; drag.dy = drag.y - r.top;
    drag.from = { status: c.parentNode.getAttribute('data-status'), next: c.nextElementSibling };
    var ghost = c.cloneNode(true);
    ghost.classList.add('ghost'); ghost.classList.remove('lifting');
    ghost.style.width = r.width + 'px';
    document.body.appendChild(ghost);
    drag.ghost = ghost;
    var ph = el('div', 'placeholder');
    ph.style.height = r.height + 'px';
    c.parentNode.insertBefore(ph, c);
    drag.ph = ph;
    c.hidden = true;
    document.body.classList.add('dragging');
    moveGhost();
  }

  function moveGhost() {
    drag.ghost.style.transform = 'translate(' + (drag.x - drag.dx) + 'px,' + (drag.y - drag.dy) + 'px) rotate(1.5deg)';
  }

  function columnAt(x, y) {
    var hit = document.elementFromPoint(x, y);
    var col = hit && hit.closest && hit.closest('.column');
    return col ? col.querySelector('.cards') : null;
  }

  function updatePlaceholder() {
    var list = columnAt(drag.x, drag.y);
    document.querySelectorAll('.cards.drop-target').forEach(function (n) { if (n !== list) n.classList.remove('drop-target'); });
    if (!list) return;
    list.classList.add('drop-target');
    var cards = Array.prototype.filter.call(list.children, function (n) { return n.classList.contains('card') && !n.hidden; });
    var before = null;
    for (var i = 0; i < cards.length; i++) {
      var r = cards[i].getBoundingClientRect();
      if (drag.y < r.top + r.height / 2) { before = cards[i]; break; }
    }
    if (before) { if (drag.ph.nextSibling !== before || drag.ph.parentNode !== list) list.insertBefore(drag.ph, before); }
    else if (drag.ph.parentNode !== list || drag.ph.nextSibling) list.appendChild(drag.ph);
  }

  function autoScroll() {
    var edge = 60, speed = 14;
    if (drag.y < edge) window.scrollBy(0, -speed);
    else if (drag.y > window.innerHeight - edge) window.scrollBy(0, speed);
    var board = $('board');
    if (board.scrollWidth > board.clientWidth) {
      if (drag.x < edge) board.scrollLeft -= speed;
      else if (drag.x > window.innerWidth - edge) board.scrollLeft += speed;
    }
    clearTimeout(drag.scrollTimer);
    drag.scrollTimer = setTimeout(function () { if (drag && drag.started) { updatePlaceholder(); autoScroll(); } }, 40);
  }

  function finishDrag() {
    var d = drag;
    clearTimeout(d.scrollTimer);
    var list = d.ph.parentNode;
    var status = list.getAttribute('data-status');
    var prev = d.ph.previousElementSibling, next = d.ph.nextElementSibling;
    while (prev && (!prev.classList.contains('card') || prev.hidden)) prev = prev.previousElementSibling;
    while (next && (!next.classList.contains('card') || next.hidden)) next = next.nextElementSibling;
    list.insertBefore(d.card, d.ph);
    d.ph.remove();
    d.ghost.remove();
    d.card.hidden = false;
    d.card.classList.remove('lifting');
    document.body.classList.remove('dragging');
    document.querySelectorAll('.cards.drop-target').forEach(function (n) { n.classList.remove('drop-target'); });
    drag = null;
    suppressClick = true; setTimeout(function () { suppressClick = false; }, 50);

    var t = byId(d.id);
    if (!t) return;
    var po = prev ? orderOf(byId(prev.getAttribute('data-id'))) : null;
    var no = next ? orderOf(byId(next.getAttribute('data-id'))) : null;
    var order = po !== null && no !== null ? (po + no) / 2 : po !== null ? po + 1024 : no !== null ? no - 1024 : 1024;
    if (status === statusOf(t) && order === orderOf(t)) { render(); return; }
    moveCard(t, status, order);
  }

  function cancelDrag() {
    if (!drag) return;
    clearTimeout(drag.timer);
    drag.card.classList.remove('lifting');
    drag = null;
  }

  function moveCard(t, status, order) {
    var before = Object.assign({}, t);
    var copy = Object.assign({}, t, { status: status, order: order, done: status === 'done' });
    replaceTodo(copy); render();
    api('PATCH', '/api/todos/' + t.id, { status: status, order: order }).then(function (d) {
      replaceTodo(d.todo); render();
      if (status !== statusOf(before)) toast('Moved to ' + COL_NAME[status], function () { moveCard(d.todo, statusOf(before), orderOf(before)); });
    }).catch(function (err) { replaceTodo(before); render(); toast(err.message); });
  }

  // ------------------------------------------------------------ card dialog
  var lastFocus = null;
  function openCard(id) {
    var t = byId(id);
    if (!t) return;
    editing = t;
    lastFocus = document.activeElement;
    $('cTitle').value = t.title;
    $('cNotes').value = t.notes || '';
    $('cDue').value = t.due || '';
    $('cStatus').value = statusOf(t);
    $('cHigh').checked = t.priority === 'high';
    $('cError').textContent = '';
    $('scrim').hidden = false;
    $('cardDlg').hidden = false;
    setTimeout(function () { $('cTitle').focus(); }, 30);
  }
  function closeCard() {
    editing = null;
    $('scrim').hidden = true;
    $('cardDlg').hidden = true;
    if (lastFocus && lastFocus.focus && document.body.contains(lastFocus)) lastFocus.focus();
  }
  $('cdClose').addEventListener('click', closeCard);
  $('cCancel').addEventListener('click', closeCard);
  $('scrim').addEventListener('click', closeCard);
  $('cardForm').addEventListener('submit', function (e) {
    e.preventDefault();
    if (!editing) return;
    var t = editing;
    var body = { title: $('cTitle').value.trim(), notes: $('cNotes').value, due: $('cDue').value || null, priority: $('cHigh').checked ? 'high' : 'medium' };
    if (!body.title) { $('cError').textContent = 'Title is required.'; return; }
    var newStatus = $('cStatus').value;
    if (newStatus !== statusOf(t)) {
      body.status = newStatus;
      var col = colCards(newStatus);
      body.order = newStatus === 'done' ? (col.length ? orderOf(col[0]) - 1024 : 1024) : (col.length ? orderOf(col[col.length - 1]) + 1024 : 1024);
    }
    api('PATCH', '/api/todos/' + t.id, body).then(function (d) { replaceTodo(d.todo); closeCard(); render(); })
      .catch(function (err) { $('cError').textContent = err.message; });
  });
  $('cDelete').addEventListener('click', function () {
    if (!editing) return;
    var t = editing;
    api('DELETE', '/api/todos/' + t.id).then(function () {
      todos = todos.filter(function (x) { return x.id !== t.id; });
      closeCard(); render();
      toast('Card deleted', function () {
        api('POST', '/api/todos', { title: t.title, notes: t.notes, priority: t.priority, due: t.due, status: statusOf(t), order: orderOf(t) })
          .then(function (d) { todos.push(d.todo); render(); }).catch(function (err) { toast(err.message); });
      });
    }).catch(function (err) { $('cError').textContent = err.message; });
  });

  $('clearDone').addEventListener('click', function () {
    var n = colCards('done').length;
    openDialog('Clear ' + n + ' done card' + (n === 1 ? '' : 's') + '?', [], 'Clear', function () {
      return api('POST', '/api/todos/clear-completed').then(function () {
        todos = todos.filter(function (t) { return statusOf(t) !== 'done'; });
        render(); toast('Done cards cleared');
      });
    }, 'This permanently removes them.');
  });

  // ------------------------------------------------------------ small dialog
  var dlgSubmit = null;
  function openDialog(title, fields, okText, onSubmit, note) {
    $('dlgTitle').textContent = title;
    var box = $('dlgFields');
    box.innerHTML = '';
    if (note) box.appendChild(el('p', 'muted', note));
    fields.forEach(function (f) {
      var wrap = el('div', 'field');
      var lab = el('label', null, f.label); lab.setAttribute('for', f.id);
      var inp = el('input');
      inp.id = f.id; inp.type = f.type || 'text'; inp.value = f.value || ''; inp.maxLength = f.max || 200;
      if (f.autocomplete) inp.setAttribute('autocomplete', f.autocomplete);
      wrap.appendChild(lab); wrap.appendChild(inp); box.appendChild(wrap);
    });
    $('dlgOk').textContent = okText;
    $('dlgError').textContent = '';
    dlgSubmit = onSubmit;
    $('dlgScrim').hidden = false; $('dialog').hidden = false;
    setTimeout(function () { var first = box.querySelector('input'); (first || $('dlgOk')).focus(); }, 30);
  }
  function closeDialog() { $('dlgScrim').hidden = true; $('dialog').hidden = true; dlgSubmit = null; }
  $('dlgCancel').addEventListener('click', closeDialog);
  $('dlgScrim').addEventListener('click', closeDialog);
  $('dlgForm').addEventListener('submit', function (e) {
    e.preventDefault();
    if (!dlgSubmit) return;
    $('dlgOk').disabled = true;
    Promise.resolve().then(dlgSubmit).then(closeDialog)
      .catch(function (err) { $('dlgError').textContent = err.message; })
      .then(function () { $('dlgOk').disabled = false; });
  });

  // ------------------------------------------------------------ user menu
  function toggleMenu(open) { $('userMenu').hidden = !open; $('userBtn').setAttribute('aria-expanded', String(open)); }
  $('userBtn').addEventListener('click', function (e) { e.stopPropagation(); toggleMenu($('userMenu').hidden); });
  document.addEventListener('click', function () { toggleMenu(false); });
  $('miLogout').addEventListener('click', function () { api('POST', '/api/logout').then(showAuth, showAuth); });
  $('miPassword').addEventListener('click', function () {
    openDialog('Change password', [
      { id: 'pwCur', label: 'Current password', type: 'password', autocomplete: 'current-password' },
      { id: 'pwNew', label: 'New password (8+ characters)', type: 'password', autocomplete: 'new-password' },
      { id: 'pwNew2', label: 'Repeat new password', type: 'password', autocomplete: 'new-password' }
    ], 'Change password', function () {
      if ($('pwNew').value !== $('pwNew2').value) throw new Error('The new passwords don\'t match.');
      if ($('pwNew').value.length < 8) throw new Error('New password must be at least 8 characters.');
      return api('POST', '/api/password', { current: $('pwCur').value, next: $('pwNew').value }).then(function () { toast('Password changed. Other devices were signed out.'); });
    });
  });
  $('miName').addEventListener('click', function () {
    openDialog('Display name', [{ id: 'nmNew', label: 'Name', value: me ? me.name : '', max: 60, autocomplete: 'name' }], 'Save', function () {
      return api('PATCH', '/api/profile', { name: $('nmNew').value.trim() }).then(function (d) { startApp(d.user); });
    });
  });

  // ------------------------------------------------------------ theme
  $('themeBtn').addEventListener('click', function () {
    var cur = document.documentElement.getAttribute('data-theme');
    var dark = cur ? cur === 'dark' : window.matchMedia('(prefers-color-scheme: dark)').matches;
    var next = dark ? 'light' : 'dark';
    document.documentElement.setAttribute('data-theme', next);
    try { localStorage.setItem('etd-theme', next); } catch (e) { /* not saved */ }
  });

  // ------------------------------------------------------------ toast
  var toastTimer = null, toastFn = null;
  function toast(text, undo) {
    clearTimeout(toastTimer);
    $('toastText').textContent = text;
    toastFn = undo || null;
    $('toastAction').hidden = !undo;
    $('toast').hidden = false;
    toastTimer = setTimeout(function () { $('toast').hidden = true; toastFn = null; }, undo ? 5000 : 2500);
  }
  $('toastAction').addEventListener('click', function () { var f = toastFn; $('toast').hidden = true; toastFn = null; if (f) f(); });

  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    if (!$('dialog').hidden) return closeDialog();
    if (!$('cardDlg').hidden) return closeCard();
    toggleMenu(false);
  });
  document.addEventListener('visibilitychange', function () {
    if (!document.hidden && me && !drag) api('GET', '/api/todos').then(function (d) { todos = d.todos; render(); }).catch(function () {});
  });

  api('GET', '/api/me').then(function (d) { startApp(d.user); }).catch(function () { showAuth(); });
})();
