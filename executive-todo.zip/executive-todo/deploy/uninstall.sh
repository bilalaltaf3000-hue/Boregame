#!/usr/bin/env bash
# Removes the Executive To-Do service. Your data folder is NOT deleted.
# Usage: sudo bash /data/executive-todo/deploy/uninstall.sh
set -uo pipefail
SERVICE=executive-todo
if [ "$(id -u)" -ne 0 ]; then echo "Please run with sudo"; exit 1; fi
PORT="$(grep -E '^PORT=' /etc/${SERVICE}.env 2>/dev/null | tail -1 | cut -d= -f2)"; PORT="${PORT:-3001}"
systemctl disable --now "$SERVICE" 2>/dev/null
rm -f /etc/systemd/system/${SERVICE}.service
systemctl daemon-reload
if systemctl is-active --quiet firewalld; then
  firewall-cmd --permanent --remove-port="${PORT}/tcp" >/dev/null 2>&1 && firewall-cmd --reload >/dev/null 2>&1
fi
echo "Service removed. Data and /etc/${SERVICE}.env were kept."
