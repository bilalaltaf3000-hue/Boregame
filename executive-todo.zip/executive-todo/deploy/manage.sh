#!/usr/bin/env bash
# Account admin for Executive To-Do. Examples:
#   sudo bash /data/executive-todo/deploy/manage.sh list
#   sudo bash /data/executive-todo/deploy/manage.sh add-user ali "Ali Raza"
#   sudo bash /data/executive-todo/deploy/manage.sh reset-password ali
#   sudo bash /data/executive-todo/deploy/manage.sh delete-user ali
#   sudo bash /data/executive-todo/deploy/manage.sh signup off
set -euo pipefail
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
if [ "$(id -u)" -ne 0 ]; then echo "Please run with sudo"; exit 1; fi
# use the same node the service uses
NODE_BIN="$(systemctl cat executive-todo 2>/dev/null | sed -n 's/^ExecStart=\([^ ]*\) .*/\1/p' | head -1)"
[ -n "$NODE_BIN" ] || NODE_BIN="$(command -v node || ls -d /data/node-v*/bin/node 2>/dev/null | sort -V | tail -1)"
exec "$NODE_BIN" "$APP_DIR/manage.js" "$@"
