#!/usr/bin/env bash
# Executive To-Do - installer for RHEL (systemd + firewalld). Fully offline, no npm needed.
# Usage (from anywhere):   sudo bash /data/executive-todo/deploy/install.sh
set -euo pipefail

SERVICE=executive-todo
APP_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DATA_DIR="$APP_DIR/data"
ENV_FILE=/etc/${SERVICE}.env
UNIT_FILE=/etc/systemd/system/${SERVICE}.service
PORT_DEFAULT=3001

green() { printf '\033[32m%s\033[0m\n' "$*"; }
yellow() { printf '\033[33m%s\033[0m\n' "$*"; }
red() { printf '\033[31m%s\033[0m\n' "$*"; }

if [ "$(id -u)" -ne 0 ]; then red "Please run with sudo:  sudo bash $0"; exit 1; fi

echo "== Executive To-Do installer =="
echo "App folder:  $APP_DIR"
echo "Data folder: $DATA_DIR"
[ -f "$APP_DIR/server.js" ] || { red "server.js not found in $APP_DIR"; exit 1; }

# ---------------------------------------------------------------- node
NODE_BIN="$(command -v node || true)"
if [ -z "$NODE_BIN" ] && [ -n "${SUDO_USER:-}" ]; then NODE_BIN="$(sudo -u "$SUDO_USER" bash -lc 'command -v node' 2>/dev/null || true)"; fi
if [ -z "$NODE_BIN" ]; then NODE_BIN="$(ls -d /data/node-v*/bin/node 2>/dev/null | sort -V | tail -1 || true)"; fi
[ -n "$NODE_BIN" ] || { red "Node.js not found. Add it to PATH or run: sudo NODE_BIN=/path/to/node bash $0"; exit 1; }
NODE_BIN="$(readlink -f "${NODE_BIN}")"
NODE_MAJOR="$("$NODE_BIN" -p 'process.versions.node.split(".")[0]')"
echo "Node:        $NODE_BIN (v$("$NODE_BIN" -v | tr -d v))"
if [ "$NODE_MAJOR" -lt 16 ]; then red "Node 16 or newer is required."; exit 1; fi

# ---------------------------------------------------------------- SELinux: let systemd execute a tarball node
if command -v getenforce >/dev/null 2>&1 && [ "$(getenforce)" != "Disabled" ]; then
  NODE_DIR="$(dirname "$NODE_BIN")"
  case "$NODE_DIR" in /usr/bin|/bin|/usr/local/bin) ;; *)
    if ! ls -Z "$NODE_BIN" 2>/dev/null | grep -q ':bin_t:'; then
      if command -v semanage >/dev/null 2>&1; then
        semanage fcontext -a -t bin_t "${NODE_DIR}(/.*)?" 2>/dev/null || semanage fcontext -m -t bin_t "${NODE_DIR}(/.*)?" 2>/dev/null || true
        restorecon -R "$NODE_DIR" >/dev/null 2>&1 || true
      fi
      ls -Z "$NODE_BIN" 2>/dev/null | grep -q ':bin_t:' || chcon -R -t bin_t "$NODE_DIR" 2>/dev/null || true
      echo "SELinux:     labelled $NODE_DIR as bin_t so systemd can run node"
    fi
  ;; esac
fi
NODE_ROOT="$(dirname "$(dirname "$NODE_BIN")")"
case "$NODE_ROOT" in /usr|/usr/local|/) ;; *) chmod -R o+rX "$NODE_ROOT" 2>/dev/null || true;; esac

# ---------------------------------------------------------------- service user + permissions
SERVICE_USER=etodo
if ! id "$SERVICE_USER" >/dev/null 2>&1; then
  useradd --system --no-create-home --shell /sbin/nologin "$SERVICE_USER" 2>/dev/null \
    && echo "Created system user $SERVICE_USER" || { yellow "Could not create user $SERVICE_USER"; SERVICE_USER=""; }
fi
mkdir -p "$DATA_DIR"
if [ -n "$SERVICE_USER" ]; then
  chown -R root:"$SERVICE_USER" "$APP_DIR"
  chmod -R u=rwX,g=rX,o= "$APP_DIR"
  chown -R "$SERVICE_USER":"$SERVICE_USER" "$DATA_DIR"
  chmod 700 "$DATA_DIR"
  if ! runuser -u "$SERVICE_USER" -- test -r "$APP_DIR/server.js" 2>/dev/null \
     || ! runuser -u "$SERVICE_USER" -- test -w "$DATA_DIR" 2>/dev/null \
     || ! runuser -u "$SERVICE_USER" -- "$NODE_BIN" -v >/dev/null 2>&1; then
    yellow "User $SERVICE_USER cannot reach $APP_DIR or run node (check permissions on parent folders like /data)."
    SERVICE_USER=""
  fi
fi
if [ -z "$SERVICE_USER" ]; then
  SERVICE_USER="${SUDO_USER:-root}"
  yellow "Falling back to running the service as: $SERVICE_USER"
  chown -R "$SERVICE_USER": "$APP_DIR" 2>/dev/null || true
fi
echo "Runs as:     $SERVICE_USER"
chmod 750 "$APP_DIR/deploy/"*.sh 2>/dev/null || true

# ---------------------------------------------------------------- settings (kept on re-install)
if [ ! -f "$ENV_FILE" ]; then
  cat > "$ENV_FILE" <<EOF
# Executive To-Do settings. After editing:  sudo systemctl restart ${SERVICE}
PORT=${PORT_DEFAULT}
HOST=0.0.0.0
# Where users and tasks are stored (back this folder up)
DATA_DIR=${DATA_DIR}
# true = anyone who can open the page may create an account; false = only the admin adds users
ALLOW_SIGNUP=true
# How long a sign-in lasts without activity
SESSION_DAYS=14
EOF
  chmod 640 "$ENV_FILE"
  chgrp "$SERVICE_USER" "$ENV_FILE" 2>/dev/null || true
  echo "Created settings file $ENV_FILE"
else
  echo "Keeping existing settings file $ENV_FILE"
fi
PORT="$(grep -E '^PORT=' "$ENV_FILE" | tail -1 | cut -d= -f2)"; PORT="${PORT:-$PORT_DEFAULT}"

# ---------------------------------------------------------------- systemd unit
cat > "$UNIT_FILE" <<EOF
[Unit]
Description=Executive To-Do
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${APP_DIR}
EnvironmentFile=-${ENV_FILE}
Environment=NODE_ENV=production
ExecStart=${NODE_BIN} ${APP_DIR}/server.js
Restart=always
RestartSec=3
UMask=0077
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=full
ProtectHome=true

[Install]
WantedBy=multi-user.target
EOF
echo "Wrote $UNIT_FILE"

if command -v getenforce >/dev/null 2>&1 && [ "$(getenforce)" != "Disabled" ]; then
  restorecon -R "$APP_DIR" >/dev/null 2>&1 || true
fi

# ---------------------------------------------------------------- firewall
if systemctl is-active --quiet firewalld; then
  if firewall-cmd --query-port="${PORT}/tcp" >/dev/null 2>&1; then
    echo "Firewall:    port ${PORT}/tcp already open"
  else
    firewall-cmd --permanent --add-port="${PORT}/tcp" >/dev/null && firewall-cmd --reload >/dev/null \
      && echo "Firewall:    opened port ${PORT}/tcp" || yellow "Could not open ${PORT}/tcp in firewalld - ask IT."
  fi
else
  yellow "firewalld is not running - if others can't connect, check the network firewall for port ${PORT}."
fi

# ---------------------------------------------------------------- start
systemctl daemon-reload
systemctl enable "$SERVICE" >/dev/null 2>&1
systemctl restart "$SERVICE"

ok=""
for i in 1 2 3 4 5 6 7 8 9 10; do
  sleep 1
  if curl -fsS "http://127.0.0.1:${PORT}/health" >/dev/null 2>&1; then ok=1; break; fi
done
if [ -n "$ok" ]; then
  IP="$(hostname -I 2>/dev/null | awk '{print $1}')"
  green "Executive To-Do is running!"
  green "Open:  http://${IP:-<vm-ip>}:${PORT}"
  echo "The first account you create becomes the administrator."
  echo "Manage accounts:  sudo bash $APP_DIR/deploy/manage.sh list"
else
  red "The service did not respond. Last log lines:"
  journalctl -u "$SERVICE" -n 30 --no-pager || true
  exit 1
fi
