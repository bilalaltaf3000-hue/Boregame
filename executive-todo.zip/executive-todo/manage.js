#!/usr/bin/env node
'use strict';
// Account admin for Executive To-Do. Run on the VM with sudo, e.g.:
//   sudo /data/executive-todo/deploy/manage.sh list
// The service is stopped briefly while changes are written, then started again.

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const SERVICE = 'executive-todo';
const [, , cmd, arg1, arg2] = process.argv;

function usage() {
  console.log([
    'Usage: manage <command>',
    '',
    '  list                          show all users',
    '  add-user <username> [name]    create a user (prints a temporary password)',
    '  reset-password <username>     set a new temporary password and sign out everywhere',
    '  delete-user <username>        delete a user and ALL their tasks',
    '  make-admin <username>         mark a user as admin',
    '  signup on|off                 allow or block self sign-up',
    ''
  ].join('\n'));
  process.exit(1);
}
if (!cmd) usage();

function serviceActive() {
  try { execFileSync('systemctl', ['is-active', '--quiet', SERVICE], { stdio: 'ignore' }); return true; } catch (e) { return false; }
}
function systemctl(action) {
  try { execFileSync('systemctl', [action, SERVICE], { stdio: 'inherit' }); } catch (e) { console.error('systemctl ' + action + ' failed'); }
}
function tempPassword() {
  const chars = 'abcdefghjkmnpqrstuvwxyzABCDEFGHJKMNPQRSTUVWXYZ23456789';
  let p = '';
  const bytes = crypto.randomBytes(12);
  for (let i = 0; i < 12; i++) p += chars[bytes[i] % chars.length];
  return p;
}
function fixOwnership(store) {
  // files written as root must stay owned by the service user
  try {
    const st = fs.statSync(store.DATA_DIR);
    const walk = (p) => {
      fs.chownSync(p, st.uid, st.gid);
      if (fs.statSync(p).isDirectory()) fs.readdirSync(p).forEach((f) => walk(path.join(p, f)));
    };
    walk(store.DATA_DIR);
  } catch (e) { /* not root or nothing to fix */ }
}

function setEnvSignup(on) {
  const envFile = '/etc/' + SERVICE + '.env';
  let txt = '';
  try { txt = fs.readFileSync(envFile, 'utf8'); } catch (e) { /* new */ }
  if (/^ALLOW_SIGNUP=.*$/m.test(txt)) txt = txt.replace(/^ALLOW_SIGNUP=.*$/m, 'ALLOW_SIGNUP=' + (on ? 'true' : 'false'));
  else txt += '\nALLOW_SIGNUP=' + (on ? 'true' : 'false') + '\n';
  fs.writeFileSync(envFile, txt);
}

const writes = ['add-user', 'reset-password', 'delete-user', 'make-admin', 'signup'];
const needsStop = writes.indexOf(cmd) !== -1 && serviceActive();
if (needsStop) systemctl('stop');

let exitCode = 0;
try {
  // load the store with the same DATA_DIR the service uses
  if (!process.env.DATA_DIR) {
    try {
      const env = fs.readFileSync('/etc/' + SERVICE + '.env', 'utf8');
      const m = env.match(/^DATA_DIR=(.+)$/m);
      if (m && m[1].trim()) process.env.DATA_DIR = m[1].trim();
    } catch (e) { /* default */ }
  }
  const store = require('./store');
  store.ensureDirs();
  const find = (u) => {
    const user = store.findUserByName(u);
    if (!user) { console.error('No user called "' + u + '". Run "list" to see users.'); process.exitCode = 2; throw new Error('stop'); }
    return user;
  };

  switch (cmd) {
    case 'list': {
      const users = store.loadUsers().users;
      if (!users.length) console.log('No users yet. The first person to sign up becomes admin.');
      users.forEach((u) => {
        const n = store.getTodos(u.id).filter((t) => !t.done).length;
        console.log((u.username + (u.isAdmin ? ' (admin)' : '')).padEnd(30) + (u.name || '').padEnd(28) + n + ' open tasks');
      });
      break;
    }
    case 'add-user': {
      if (!arg1 || !/^[a-z0-9][a-z0-9._-]{2,31}$/.test(arg1.toLowerCase())) { console.error('Give a username: 3-32 letters/numbers/._-'); exitCode = 1; break; }
      if (store.findUserByName(arg1)) { console.error('That username already exists.'); exitCode = 1; break; }
      const pw = tempPassword();
      store.createUser(arg1.toLowerCase(), arg2 || arg1, pw);
      console.log('Created ' + arg1.toLowerCase() + '  temporary password: ' + pw);
      console.log('Ask them to change it from the account menu after signing in.');
      break;
    }
    case 'reset-password': {
      if (!arg1) usage();
      const u = find(arg1);
      const pw = tempPassword();
      store.setPassword(u, pw);
      store.removeSessionsForUser(u.id);
      console.log('New temporary password for ' + u.username + ': ' + pw);
      break;
    }
    case 'delete-user': {
      if (!arg1) usage();
      const u = find(arg1);
      store.deleteUser(u);
      console.log('Deleted ' + u.username + ' and their tasks.');
      break;
    }
    case 'make-admin': {
      if (!arg1) usage();
      const u = find(arg1);
      store.setAdmin(u, true);
      console.log(u.username + ' is now an admin.');
      break;
    }
    case 'signup': {
      if (arg1 !== 'on' && arg1 !== 'off') usage();
      setEnvSignup(arg1 === 'on');
      console.log('Self sign-up is now ' + arg1.toUpperCase() + '.');
      break;
    }
    default: usage();
  }
  store.flushSessions();
  fixOwnership(store);
} catch (e) {
  if (e.message !== 'stop') { console.error(e.message); exitCode = 1; }
} finally {
  if (needsStop) systemctl('start');
}
process.exitCode = process.exitCode || exitCode;
