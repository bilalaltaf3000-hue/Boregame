'use strict';
// Tiny JSON-file storage with atomic writes. No database needed.
// data/
//   users.json      { users: [...] }
//   sessions.json   { sessions: { token: { userId, expires } } }
//   todos/<userId>.json  [ ...tasks ]

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const DATA_DIR = path.resolve(process.env.DATA_DIR || path.join(__dirname, 'data'));
const TODO_DIR = path.join(DATA_DIR, 'todos');

function ensureDirs() {
  fs.mkdirSync(TODO_DIR, { recursive: true, mode: 0o700 });
}

function readJson(file, fallback) {
  try { return JSON.parse(fs.readFileSync(file, 'utf8')); }
  catch (e) {
    if (e.code === 'ENOENT') return fallback;
    // keep a copy of a damaged file instead of silently losing it
    try { fs.copyFileSync(file, file + '.corrupt-' + Date.now()); } catch (x) { /* ignore */ }
    console.error('[store] could not read ' + file + ': ' + e.message);
    return fallback;
  }
}

function writeJsonAtomic(file, data) {
  const tmp = file + '.' + process.pid + '.' + crypto.randomBytes(4).toString('hex') + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(data, null, 1), { mode: 0o600 });
  fs.renameSync(tmp, file);
}

// ---------------------------------------------------------------- users
const USERS_FILE = path.join(DATA_DIR, 'users.json');
let usersCache = null;

function loadUsers() {
  if (!usersCache) usersCache = readJson(USERS_FILE, { users: [] });
  return usersCache;
}
function saveUsers() { writeJsonAtomic(USERS_FILE, loadUsers()); }

function findUserByName(username) {
  const u = String(username || '').toLowerCase();
  return loadUsers().users.find((x) => x.username === u) || null;
}
function findUserById(id) { return loadUsers().users.find((x) => x.id === id) || null; }

function hashPassword(password, salt) {
  salt = salt || crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(String(password), salt, 64, { N: 16384, r: 8, p: 1 }).toString('hex');
  return { salt, hash };
}
function verifyPassword(user, password) {
  const { hash } = hashPassword(password, user.salt);
  const a = Buffer.from(hash, 'hex'), b = Buffer.from(user.hash, 'hex');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

function createUser(username, name, password) {
  const db = loadUsers();
  const { salt, hash } = hashPassword(password);
  const user = {
    id: crypto.randomUUID(),
    username: String(username).toLowerCase(),
    name: String(name || username),
    salt, hash,
    isAdmin: db.users.length === 0,
    createdAt: new Date().toISOString()
  };
  db.users.push(user);
  saveUsers();
  return user;
}
function setPassword(user, password) {
  const { salt, hash } = hashPassword(password);
  user.salt = salt; user.hash = hash;
  user.passwordChangedAt = new Date().toISOString();
  saveUsers();
}
function setName(user, name) {
  user.name = name;
  saveUsers();
}
function setAdmin(user, isAdmin) {
  user.isAdmin = !!isAdmin;
  saveUsers();
}
function deleteUser(user) {
  const db = loadUsers();
  db.users = db.users.filter((u) => u.id !== user.id);
  saveUsers();
  try { fs.unlinkSync(todoFile(user.id)); } catch (e) { /* none */ }
  removeSessionsForUser(user.id);
}
function reloadUsers() { usersCache = null; }

// ---------------------------------------------------------------- sessions
const SESSIONS_FILE = path.join(DATA_DIR, 'sessions.json');
const SESSION_DAYS = parseInt(process.env.SESSION_DAYS || '14', 10);
let sessionsCache = null;
let sessionsDirty = false;

function loadSessions() {
  if (!sessionsCache) sessionsCache = readJson(SESSIONS_FILE, { sessions: {} });
  return sessionsCache;
}
function flushSessions() {
  if (!sessionsDirty) return;
  sessionsDirty = false;
  writeJsonAtomic(SESSIONS_FILE, loadSessions());
}
setInterval(flushSessions, 5000).unref();

function sha(token) { return crypto.createHash('sha256').update(token).digest('hex'); }

function createSession(userId) {
  const token = crypto.randomBytes(32).toString('base64url');
  loadSessions().sessions[sha(token)] = { userId, expires: Date.now() + SESSION_DAYS * 864e5 };
  sessionsDirty = true;
  flushSessions();
  return token;
}
function getSession(token) {
  if (!token) return null;
  const key = sha(token);
  const s = loadSessions().sessions[key];
  if (!s) return null;
  if (s.expires < Date.now()) { delete loadSessions().sessions[key]; sessionsDirty = true; return null; }
  // sliding expiry, written lazily
  if (s.expires - Date.now() < (SESSION_DAYS - 1) * 864e5) { s.expires = Date.now() + SESSION_DAYS * 864e5; sessionsDirty = true; }
  return s;
}
function destroySession(token) {
  if (!token) return;
  delete loadSessions().sessions[sha(token)];
  sessionsDirty = true;
  flushSessions();
}
function removeSessionsForUser(userId, exceptToken) {
  const all = loadSessions().sessions;
  const keep = exceptToken ? sha(exceptToken) : null;
  Object.keys(all).forEach((k) => { if (all[k].userId === userId && k !== keep) delete all[k]; });
  sessionsDirty = true;
  flushSessions();
}
function pruneSessions() {
  const all = loadSessions().sessions, now = Date.now();
  Object.keys(all).forEach((k) => { if (all[k].expires < now) { delete all[k]; sessionsDirty = true; } });
}
setInterval(pruneSessions, 3600e3).unref();

// ---------------------------------------------------------------- todos
function todoFile(userId) {
  if (!/^[0-9a-f-]{36}$/.test(userId)) throw new Error('bad user id');
  return path.join(TODO_DIR, userId + '.json');
}
const todoCache = new Map();
function getTodos(userId) {
  if (!todoCache.has(userId)) todoCache.set(userId, readJson(todoFile(userId), []));
  return todoCache.get(userId);
}
function saveTodos(userId) { writeJsonAtomic(todoFile(userId), getTodos(userId)); }

module.exports = {
  DATA_DIR, ensureDirs,
  findUserByName, findUserById, createUser, verifyPassword, setPassword, setName, setAdmin, deleteUser, loadUsers, reloadUsers,
  createSession, getSession, destroySession, removeSessionsForUser, flushSessions,
  getTodos, saveTodos
};
