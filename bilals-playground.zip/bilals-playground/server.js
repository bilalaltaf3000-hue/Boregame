'use strict';
// Bilal's Playground - an offline draw-and-guess game for the office LAN.
// Node.js + Socket.io. No internet needed. AI (port 8001) is used only to generate words.

const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { Server } = require('socket.io');
const words = require('./words');

const PORT = parseInt(process.env.PORT || '3000', 10);
const HOST = process.env.HOST || '0.0.0.0';
const PUBLIC_DIR = path.join(__dirname, 'public');

const MAX_PLAYERS = 12;
const CHOOSE_SECONDS = 15;
const TURN_END_SECONDS = 6;
const RECONNECT_GRACE_MS = 30000;
const EMPTY_ROOM_TTL_MS = 10 * 60 * 1000;
const MAX_STROKES = 3000;
const MAX_POINTS_PER_STROKE = 4000;
const COLORS_ALLOWED = /^#[0-9a-fA-F]{6}$/;
const SIZES_ALLOWED = [4, 10, 22, 40];
const AVATAR_COLORS = ['#FF7A1A', '#2F5BFF', '#FFC93C', '#7A3FD1', '#D7263D', '#0E9F8A', '#8A4B2A', '#E85D9E', '#4B8BBE', '#6B8E23', '#C2410C', '#334155'];
const DIFF_MULT = { easy: 1, medium: 1.5, hard: 2 };

function log() {
  const args = Array.prototype.slice.call(arguments);
  console.log.apply(console, ['[' + new Date().toISOString() + ']'].concat(args));
}

// ---------------------------------------------------------------- static files
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.woff2': 'font/woff2', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.ico': 'image/x-icon', '.json': 'application/json'
};

const server = http.createServer((req, res) => {
  let urlPath;
  try { urlPath = decodeURIComponent(new URL(req.url, 'http://x').pathname); } catch (e) { res.writeHead(400); return res.end(); }

  if (urlPath === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' });
    return res.end(JSON.stringify({ ok: true, rooms: rooms.size, players: countPlayers(), ai: words.getAiStatus(), aiUrl: words.AI_URL }));
  }

  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405); return res.end(); }
  if (urlPath === '/') urlPath = '/index.html';
  const filePath = path.normalize(path.join(PUBLIC_DIR, urlPath));
  if (filePath.indexOf(PUBLIC_DIR + path.sep) !== 0) { res.writeHead(403); return res.end(); }

  fs.stat(filePath, (err, st) => {
    if (err || !st.isFile()) { res.writeHead(404, { 'Content-Type': 'text/plain' }); return res.end('Not found'); }
    const ext = path.extname(filePath).toLowerCase();
    res.writeHead(200, {
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': ext === '.woff2' ? 'public, max-age=604800' : 'no-cache',
      'X-Content-Type-Options': 'nosniff'
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(filePath).pipe(res);
  });
});

const io = new Server(server, { maxHttpBufferSize: 1e6, pingInterval: 20000, pingTimeout: 20000 });

// ---------------------------------------------------------------- helpers
const rooms = new Map();

function countPlayers() {
  let n = 0;
  rooms.forEach((r) => { r.players.forEach((p) => { if (p.connected) n++; }); });
  return n;
}

function norm(s) { return String(s || '').toLowerCase().replace(/[^a-z]/g, ''); }

function levenshtein(a, b) {
  if (Math.abs(a.length - b.length) > 2) return 99;
  const dp = [];
  for (let i = 0; i <= a.length; i++) { dp[i] = [i]; }
  for (let j = 0; j <= b.length; j++) { dp[0][j] = j; }
  for (let i = 1; i <= a.length; i++) {
    for (let j = 1; j <= b.length; j++) {
      dp[i][j] = Math.min(dp[i - 1][j] + 1, dp[i][j - 1] + 1, dp[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    }
  }
  return dp[a.length][b.length];
}

function cleanName(n) {
  return String(n || '').replace(/[\u0000-\u001f<>]/g, '').replace(/\s+/g, ' ').trim().slice(0, 16);
}

function cleanRoomCode(c) {
  return String(c || '').toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
}

function shuffle(a) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const t = a[i]; a[i] = a[j]; a[j] = t;
  }
  return a;
}

function connectedPlayers(room) {
  const list = [];
  room.order.forEach((id) => { const p = room.players.get(id); if (p && p.connected) list.push(p); });
  return list;
}

function getRoom(code) {
  let room = rooms.get(code);
  if (!room) {
    room = {
      code,
      hostId: null,
      players: new Map(),
      order: [],
      settings: { rounds: 3, drawTime: 80, theme: 'Office life + Pakistani food', lang: 'english' },
      state: 'lobby',
      round: 0,
      drawerQueue: [],
      drawerId: null,
      choices: null,
      word: null,
      difficulty: null,
      endsAt: 0,
      timers: [],
      strokes: [],
      revealed: [],
      turnScores: {},
      guessedOrder: [],
      usedWords: new Set(),
      pack: null,
      packKey: null,
      packPromise: null,
      lastResult: null,
      finalRanking: null,
      notice: '',
      emptySince: null
    };
    rooms.set(code, room);
    log('room created', code);
  }
  return room;
}

function clearTimers(room) {
  room.timers.forEach((t) => { clearTimeout(t); clearInterval(t); });
  room.timers = [];
}

function hintFor(room, forDrawer) {
  if (!room.word) return null;
  return room.word.split('').map((ch, i) => {
    if (ch === ' ') return ' ';
    if (forDrawer || room.revealed.indexOf(i) !== -1) return ch;
    return '_';
  });
}

// ---------------------------------------------------------------- state broadcast
function publicPlayers(room) {
  return connectedPlayers(room).map((p) => ({
    id: p.id, name: p.name, score: p.score, color: p.color,
    guessed: room.guessedOrder.indexOf(p.id) !== -1,
    isHost: p.id === room.hostId, isDrawer: p.id === room.drawerId
  }));
}

function snapshotFor(room, playerId) {
  const isDrawer = playerId === room.drawerId;
  const drawer = room.players.get(room.drawerId);
  return {
    code: room.code,
    you: playerId,
    hostId: room.hostId,
    state: room.state,
    settings: room.settings,
    round: room.round,
    players: publicPlayers(room),
    drawerId: room.drawerId,
    drawerName: drawer ? drawer.name : '',
    choices: isDrawer && room.state === 'choosing' ? room.choices : null,
    hint: room.state === 'drawing' ? hintFor(room, isDrawer || room.guessedOrder.indexOf(playerId) !== -1) : null,
    difficulty: room.state === 'drawing' ? room.difficulty : null,
    endsAt: room.endsAt,
    serverNow: Date.now(),
    result: room.state === 'turnEnd' ? room.lastResult : null,
    final: room.state === 'gameOver' ? room.finalRanking : null,
    notice: room.notice
  };
}

function broadcastState(room) {
  room.players.forEach((p) => {
    if (p.connected && p.socketId) io.to(p.socketId).emit('state', snapshotFor(room, p.id));
  });
}

function sysMsg(room, text, kind) {
  io.to(room.code).emit('msg', { type: kind || 'system', text });
}

// ---------------------------------------------------------------- word packs
function packKeyOf(room) { return room.settings.theme.toLowerCase().trim() + '|' + room.settings.lang; }

function ensurePack(room) {
  const key = packKeyOf(room);
  if (room.pack && room.packKey === key) return Promise.resolve(room.pack);
  if (room.packPromise && room.packPromiseKey === key) return room.packPromise;
  room.packPromiseKey = key;
  room.packPromise = words.generatePack(room.settings.theme, room.settings.lang).then((pack) => {
    if (packKeyOf(room) === key) { room.pack = pack; room.packKey = key; room.usedWords = new Set(); }
    room.packPromise = null;
    return pack;
  });
  return room.packPromise;
}

function pickFrom(room, list) {
  const fresh = list.filter((w) => !room.usedWords.has(w));
  const pool = fresh.length ? fresh : list;
  return pool[Math.floor(Math.random() * pool.length)];
}

function makeChoices(room) {
  const pack = room.pack || words.fallbackPack(room.settings.lang);
  const out = [];
  ['easy', 'medium', 'hard'].forEach((d) => {
    let w = pickFrom(room, pack[d]);
    let guard = 0;
    while (out.some((c) => c.word === w) && guard++ < 10) w = pickFrom(room, pack[d]);
    out.push({ word: w, difficulty: d });
  });
  return out;
}

// ---------------------------------------------------------------- game flow
function startGame(room) {
  if (connectedPlayers(room).length < 2) { room.notice = 'Need at least 2 players to start.'; broadcastState(room); return; }
  room.state = 'loading';
  room.notice = 'Getting fresh words from the AI…';
  broadcastState(room);
  ensurePack(room).then((pack) => {
    if (room.state !== 'loading') return;
    connectedPlayers(room).forEach((p) => { p.score = 0; });
    room.round = 1;
    room.notice = pack.source === 'ai' ? '' : 'AI not reachable – using built-in words.';
    room.drawerQueue = connectedPlayers(room).map((p) => p.id);
    sysMsg(room, 'Game started! ' + room.settings.rounds + ' rounds, ' + room.settings.drawTime + 's per drawing.');
    nextTurn(room);
  });
}

function nextTurn(room) {
  clearTimers(room);
  if (connectedPlayers(room).length < 2) { return backToLobby(room, 'Not enough players left – back to the lobby.'); }

  // find next drawer still connected
  let nextId = null;
  while (room.drawerQueue.length) {
    const id = room.drawerQueue.shift();
    const p = room.players.get(id);
    if (p && p.connected) { nextId = id; break; }
  }
  if (!nextId) {
    room.round++;
    if (room.round > room.settings.rounds) return endGame(room);
    room.drawerQueue = connectedPlayers(room).map((p) => p.id);
    sysMsg(room, 'Round ' + room.round + ' of ' + room.settings.rounds);
    return nextTurn(room);
  }

  room.drawerId = nextId;
  room.state = 'choosing';
  room.choices = makeChoices(room);
  room.word = null;
  room.difficulty = null;
  room.strokes = [];
  room.revealed = [];
  room.turnScores = {};
  room.guessedOrder = [];
  room.endsAt = Date.now() + CHOOSE_SECONDS * 1000;
  io.to(room.code).emit('clear');
  broadcastState(room);
  room.timers.push(setTimeout(() => {
    if (room.state === 'choosing') chooseWord(room, Math.floor(Math.random() * room.choices.length));
  }, CHOOSE_SECONDS * 1000));
}

function chooseWord(room, index) {
  if (room.state !== 'choosing' || !room.choices) return;
  const c = room.choices[index] || room.choices[0];
  clearTimers(room);
  room.word = c.word;
  room.difficulty = c.difficulty;
  room.usedWords.add(c.word);
  room.state = 'drawing';
  room.choices = null;
  const drawMs = room.settings.drawTime * 1000;
  room.turnStartedAt = Date.now();
  room.endsAt = Date.now() + drawMs;

  // letter hints: reveal up to 40% of letters, starting after 35% of the time
  const letterIdx = [];
  room.word.split('').forEach((ch, i) => { if (ch !== ' ') letterIdx.push(i); });
  const toReveal = shuffle(letterIdx).slice(0, Math.floor(letterIdx.length * 0.4));
  toReveal.forEach((idx, k) => {
    const at = drawMs * (0.35 + 0.55 * (k + 1) / (toReveal.length + 1));
    room.timers.push(setTimeout(() => {
      if (room.state !== 'drawing') return;
      room.revealed.push(idx);
      broadcastState(room);
    }, at));
  });
  room.timers.push(setTimeout(() => endTurn(room, 'time'), drawMs));
  broadcastState(room);
}

function endTurn(room, reason) {
  if (room.state !== 'drawing' && room.state !== 'choosing') return;
  clearTimers(room);
  const drawer = room.players.get(room.drawerId);
  const word = room.word || (room.choices && room.choices[0] && room.choices[0].word) || '';

  // drawer score: share of guessers' points
  if (drawer && room.word && room.guessedOrder.length) {
    const mult = DIFF_MULT[room.difficulty] || 1;
    const gain = Math.min(Math.round(50 * mult * room.guessedOrder.length), Math.round(250 * mult));
    drawer.score += gain;
    room.turnScores[drawer.id] = gain;
  }

  const rows = connectedPlayers(room).map((p) => ({
    id: p.id, name: p.name, color: p.color, delta: room.turnScores[p.id] || 0, total: p.score,
    isDrawer: p.id === room.drawerId, guessed: room.guessedOrder.indexOf(p.id) !== -1
  })).sort((a, b) => b.delta - a.delta || b.total - a.total);

  room.lastResult = {
    word, reason, drawerName: drawer ? drawer.name : '',
    guessedCount: room.guessedOrder.length,
    possible: Math.max(0, connectedPlayers(room).length - 1),
    rows
  };
  room.state = 'turnEnd';
  room.endsAt = Date.now() + TURN_END_SECONDS * 1000;
  room.word = null;
  broadcastState(room);
  room.timers.push(setTimeout(() => nextTurn(room), TURN_END_SECONDS * 1000));
}

function endGame(room) {
  clearTimers(room);
  room.state = 'gameOver';
  room.drawerId = null;
  room.finalRanking = connectedPlayers(room)
    .map((p) => ({ id: p.id, name: p.name, color: p.color, score: p.score }))
    .sort((a, b) => b.score - a.score);
  room.endsAt = 0;
  broadcastState(room);
  const w = room.finalRanking[0];
  if (w) sysMsg(room, w.name + ' wins with ' + w.score + ' points!');
}

function backToLobby(room, notice) {
  clearTimers(room);
  room.state = 'lobby';
  room.round = 0;
  room.drawerId = null;
  room.word = null;
  room.choices = null;
  room.strokes = [];
  room.guessedOrder = [];
  room.notice = notice || '';
  connectedPlayers(room).forEach((p) => { p.score = 0; });
  io.to(room.code).emit('clear');
  broadcastState(room);
}

function handleGuess(room, player, text) {
  const isDrawing = room.state === 'drawing';
  const isDrawer = player.id === room.drawerId;
  const alreadyGuessed = room.guessedOrder.indexOf(player.id) !== -1;

  if (isDrawing && !isDrawer && !alreadyGuessed) {
    const g = norm(text);
    const w = norm(room.word);
    if (g && g === w) {
      const timeLeft = Math.max(0, room.endsAt - Date.now()) / (room.settings.drawTime * 1000);
      const mult = DIFF_MULT[room.difficulty] || 1;
      const firstBonus = room.guessedOrder.length === 0 ? 30 : 0;
      const gain = Math.round((100 + 200 * timeLeft) * mult) + firstBonus;
      player.score += gain;
      room.turnScores[player.id] = gain;
      room.guessedOrder.push(player.id);
      sysMsg(room, player.name + ' guessed the word!', 'correct');
      broadcastState(room);
      const guessers = connectedPlayers(room).filter((p) => p.id !== room.drawerId);
      if (guessers.every((p) => room.guessedOrder.indexOf(p.id) !== -1)) {
        room.timers.push(setTimeout(() => endTurn(room, 'all'), 800));
      }
      return;
    }
    if (g && w.length >= 3 && levenshtein(g, w) <= (w.length <= 5 ? 1 : 2)) {
      io.to(player.socketId).emit('msg', { type: 'close', text: '"' + text + '" is very close!' });
      io.to(room.code).emit('msg', { type: 'chat', name: player.name, color: player.color, text });
      return;
    }
  }

  // drawer / players who already guessed: only visible to drawer + guessed players, and never leak the word
  if (isDrawing && (isDrawer || alreadyGuessed)) {
    if (room.word && norm(text).indexOf(norm(room.word)) !== -1) {
      io.to(player.socketId).emit('msg', { type: 'system', text: 'Shh! Don\'t give away the word.' });
      return;
    }
    const msg = { type: 'chat-secret', name: player.name, color: player.color, text };
    connectedPlayers(room).forEach((p) => {
      if (p.id === room.drawerId || room.guessedOrder.indexOf(p.id) !== -1) io.to(p.socketId).emit('msg', msg);
    });
    return;
  }

  io.to(room.code).emit('msg', { type: 'chat', name: player.name, color: player.color, text });
}

// ---------------------------------------------------------------- sockets
io.on('connection', (socket) => {
  let room = null;
  let player = null;
  let msgTimes = [];

  socket.on('join', (data, ack) => {
    const reply = typeof ack === 'function' ? ack : function () {};
    if (room) return reply({ ok: false, error: 'Already joined' });
    data = data || {};
    const name = cleanName(data.name);
    const code = cleanRoomCode(data.room) || 'OFFICE';
    const clientId = String(data.clientId || '').replace(/[^a-zA-Z0-9-]/g, '').slice(0, 40) || crypto.randomUUID();
    if (!name) return reply({ ok: false, error: 'Please enter your name.' });

    const r = getRoom(code);
    let p = r.players.get(clientId);
    if (!p) {
      if (connectedPlayers(r).length >= MAX_PLAYERS) return reply({ ok: false, error: 'Room is full (max ' + MAX_PLAYERS + ').' });
      const taken = connectedPlayers(r).some((x) => x.name.toLowerCase() === name.toLowerCase());
      if (taken) return reply({ ok: false, error: 'Someone in this room is already called "' + name + '".' });
      const usedColors = connectedPlayers(r).map((x) => x.color);
      const color = AVATAR_COLORS.find((c) => usedColors.indexOf(c) === -1) || AVATAR_COLORS[r.order.length % AVATAR_COLORS.length];
      p = { id: clientId, name, score: 0, color, connected: true, socketId: socket.id, leaveTimer: null };
      r.players.set(clientId, p);
      r.order.push(clientId);
      sysMsg(r, name + ' joined.', 'join');
      // a late joiner during a game draws in the following rounds
    } else {
      if (p.leaveTimer) { clearTimeout(p.leaveTimer); p.leaveTimer = null; }
      const wasConnected = p.connected;
      if (wasConnected && p.socketId && p.socketId !== socket.id) {
        const old = io.sockets.sockets.get(p.socketId);
        if (old) old.disconnect(true);
      }
      p.connected = true;
      p.socketId = socket.id;
      p.name = name;
      if (!wasConnected) sysMsg(r, name + ' is back.', 'join');
    }
    if (!r.hostId || !r.players.get(r.hostId) || !r.players.get(r.hostId).connected) r.hostId = p.id;
    r.emptySince = null;

    room = r; player = p;
    socket.join(r.code);
    reply({ ok: true, room: r.code, clientId });
    log('join', r.code, name);
    socket.emit('canvas', { strokes: r.strokes });
    broadcastState(r);
  });

  function isHost() { return room && player && room.hostId === player.id; }
  function isDrawerNow() { return room && player && room.state === 'drawing' && room.drawerId === player.id; }

  socket.on('settings', (s) => {
    if (!isHost() || room.state !== 'lobby' || !s) return;
    const st = room.settings;
    if ([2, 3, 5].indexOf(+s.rounds) !== -1) st.rounds = +s.rounds;
    if ([60, 80, 120].indexOf(+s.drawTime) !== -1) st.drawTime = +s.drawTime;
    if (typeof s.theme === 'string') st.theme = s.theme.replace(/[\u0000-\u001f<>]/g, '').slice(0, 60);
    if (['english', 'urdu', 'mix'].indexOf(s.lang) !== -1) st.lang = s.lang;
    room.notice = '';
    broadcastState(room);
  });

  socket.on('preview-words', () => {
    if (!isHost() || room.state !== 'lobby') return;
    io.to(room.code).emit('preview', { loading: true });
    const r = room;
    ensurePack(r).then((pack) => {
      const sample = shuffle(pack.easy.slice(0, 20)).slice(0, 3)
        .concat(shuffle(pack.medium.slice(0, 20)).slice(0, 3))
        .concat(shuffle(pack.hard.slice(0, 20)).slice(0, 2));
      io.to(r.code).emit('preview', { loading: false, words: sample, source: pack.source });
    });
  });

  socket.on('start', () => {
    if (!isHost() || room.state !== 'lobby') return;
    startGame(room);
  });

  socket.on('choose', (i) => {
    if (!room || !player || room.state !== 'choosing' || room.drawerId !== player.id) return;
    const idx = parseInt(i, 10);
    if (!(idx >= 0 && idx < 3)) return;
    chooseWord(room, idx);
  });

  socket.on('draw', (op) => {
    if (!isDrawerNow() || !op || typeof op !== 'object') return;
    const pts = Array.isArray(op.p) ? op.p : [];
    const clean = [];
    for (let i = 0; i < pts.length && i < 400; i++) {
      const x = +pts[i][0], y = +pts[i][1];
      if (isFinite(x) && isFinite(y)) clean.push([Math.max(0, Math.min(1000, Math.round(x))), Math.max(0, Math.min(750, Math.round(y)))]);
    }
    const id = String(op.id || '').slice(0, 24);
    if (!id) return;
    if (op.t === 's') {
      if (room.strokes.length >= MAX_STROKES) return;
      const color = COLORS_ALLOWED.test(op.c) ? op.c : '#16181D';
      const size = SIZES_ALLOWED.indexOf(+op.w) !== -1 ? +op.w : 10;
      const stroke = { id, c: color, w: size, p: clean };
      room.strokes.push(stroke);
      socket.to(room.code).emit('draw', { t: 's', id, c: color, w: size, p: clean });
    } else if (op.t === 'a') {
      const s = room.strokes.length && room.strokes[room.strokes.length - 1];
      if (!s || s.id !== id || s.p.length + clean.length > MAX_POINTS_PER_STROKE) return;
      Array.prototype.push.apply(s.p, clean);
      socket.to(room.code).emit('draw', { t: 'a', id, p: clean });
    }
  });

  socket.on('undo', () => {
    if (!isDrawerNow() || !room.strokes.length) return;
    const s = room.strokes.pop();
    socket.to(room.code).emit('undo', { id: s.id });
  });

  socket.on('clear', () => {
    if (!isDrawerNow()) return;
    room.strokes = [];
    socket.to(room.code).emit('clear');
  });

  socket.on('guess', (text) => {
    if (!room || !player) return;
    text = String(text || '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 100);
    if (!text) return;
    const now = Date.now();
    msgTimes = msgTimes.filter((t) => now - t < 4000);
    if (msgTimes.length >= 6) return socket.emit('msg', { type: 'system', text: 'Slow down a little!' });
    msgTimes.push(now);
    handleGuess(room, player, text);
  });

  socket.on('skip-turn', () => {
    if (!room || !player || room.drawerId !== player.id) return;
    if (room.state === 'drawing' || room.state === 'choosing') { sysMsg(room, player.name + ' skipped their turn.'); endTurn(room, 'skip'); }
  });

  socket.on('end-game', () => {
    if (!isHost() || room.state === 'lobby') return;
    backToLobby(room, 'The host ended the game.');
  });

  socket.on('back-to-lobby', () => {
    if (!isHost() || room.state !== 'gameOver') return;
    backToLobby(room, '');
  });

  socket.on('disconnect', () => {
    if (!room || !player || player.socketId !== socket.id) return;
    const r = room, p = player;
    p.connected = false;
    log('leave', r.code, p.name);
    sysMsg(r, p.name + ' left.', 'leave');

    if (r.hostId === p.id) {
      const next = connectedPlayers(r)[0];
      r.hostId = next ? next.id : null;
      if (next) sysMsg(r, next.name + ' is now the host.');
    }
    if (r.drawerId === p.id && (r.state === 'drawing' || r.state === 'choosing')) {
      sysMsg(r, 'The drawer left – skipping turn.');
      endTurn(r, 'left');
    } else if (r.state === 'drawing') {
      const guessers = connectedPlayers(r).filter((x) => x.id !== r.drawerId);
      if (guessers.length && guessers.every((x) => r.guessedOrder.indexOf(x.id) !== -1)) endTurn(r, 'all');
    }
    if (r.state !== 'lobby' && r.state !== 'gameOver' && connectedPlayers(r).length < 2) {
      backToLobby(r, 'Not enough players left – back to the lobby.');
    }
    broadcastState(r);

    p.leaveTimer = setTimeout(() => {
      if (p.connected) return;
      r.players.delete(p.id);
      r.order = r.order.filter((id) => id !== p.id);
      if (!connectedPlayers(r).length) r.emptySince = Date.now();
    }, RECONNECT_GRACE_MS);
    if (!connectedPlayers(r).length) r.emptySince = Date.now();
  });
});

// clean up empty rooms
setInterval(() => {
  const now = Date.now();
  rooms.forEach((r, code) => {
    if (!connectedPlayers(r).length && r.emptySince && now - r.emptySince > EMPTY_ROOM_TTL_MS) {
      clearTimers(r);
      rooms.delete(code);
      log('room removed', code);
    }
  });
}, 60000).unref();

server.listen(PORT, HOST, () => {
  log("Bilal's Playground running on http://" + HOST + ':' + PORT + '  (AI: ' + words.AI_URL + ')');
});

function shutdown(sig) {
  log('received ' + sig + ', shutting down');
  io.close();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
