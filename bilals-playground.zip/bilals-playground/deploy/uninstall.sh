#!/usr/bin/env bash
# Removes the Bilal's Playground service (keeps the app folder; delete it yourself if wanted).
# Usage: sudo bash deploy/uninstall.sh
set -uo pipefail
SERVICE=bilals-playground
if [ "$(id -u)" -ne 0 ]; then echo "Please run with sudo"; exit 1; fi

PORT="$(grep -E '^PORT=' /etc/${SERVICE}.env 2>/dev/null | tail -1 | cut -d= -f2)"; PORT="${PORT:-3000}"
systemctl disable --now "$SERVICE" 2>/dev/null
rm -f /etc/systemd/system/${SERVICE}.service
systemctl daemon-reload
if systemctl is-active --quiet firewalld; then
  firewall-cmd --permanent --remove-port="${PORT}/tcp" >/dev/null 2>&1 && firewall-cmd --reload >/dev/null 2>&1
fi
echo "Service removed. Settings file kept at /etc/${SERVICE}.env (delete it if you like)."
echo "App folder was not deleted."
