# Bilal's Playground

An office draw-and-guess game that runs entirely on your own VM.
No internet needed: the dependencies and fonts are already inside this folder.
Your local AI (port 8001) is used **only** to generate the word lists. If the AI
is down or slow, the game automatically falls back to a built-in word list.

- Game: `http://<VM-IP>:3000`
- Runs as a **systemd service**, so it keeps running after PuTTY disconnects and starts again after a reboot.
- Installs to: `/data/bilals-playground`

---

## 1. Requirements (already on your VM)

- RHEL 8/9 with systemd
- Node.js 14 or newer (`node -v`)
- `sudo` rights
- Your AI server on `http://127.0.0.1:8001` with an OpenAI-compatible API
  (vLLM, Ollama, llama.cpp server, LM Studio, etc.)

---

## 2. Copy the zip to the VM

From your Windows PC, use **WinSCP** (or `scp` in PowerShell) to upload
`bilals-playground.zip` to `/tmp` on the VM:

```powershell
scp bilals-playground.zip youruser@VM-IP:/tmp/
```

---

## 3. Install (about 1 minute)

Log in with PuTTY and run these commands. The PuTTY 15-minute timeout doesn't
matter: once installed, the game runs under systemd.

```bash
# 1. Create /data if needed and extract the zip there
sudo mkdir -p /data
sudo python3 -m zipfile -e /tmp/bilals-playground.zip /data/
#   (or, if unzip is installed:  sudo unzip -o /tmp/bilals-playground.zip -d /data/)

# 2. Run the installer
sudo bash /data/bilals-playground/deploy/install.sh
```

The installer:

1. Checks Node.js.
2. Creates a locked-down system user `bpgame` to run the game.
3. Writes the settings file `/etc/bilals-playground.env`.
4. Creates and starts the systemd service `bilals-playground`.
5. Opens port **3000/tcp** in firewalld.
6. Prints the link to share, e.g. `http://10.0.0.25:3000`.

---

## 4. Check the AI connection

```bash
curl -s http://127.0.0.1:3000/health
```

After someone clicks **Preview words** or starts a game, `"ai": {"ok": true, ...}`
means words are coming from your AI. If it says `"ok": false`, the `detail`
field explains why.

Common fixes, made in `/etc/bilals-playground.env`:

| Problem | Fix |
|---|---|
| Your AI's URL is different | Set `AI_URL=http://127.0.0.1:8001/v1/chat/completions` (adjust the path) |
| "Could not detect model name" | Set `AI_MODEL=` to the exact model name your server uses (`curl -s http://127.0.0.1:8001/v1/models`) |
| AI needs an API key | Set `AI_API_KEY=...` |
| AI is slow on first call | Raise `AI_TIMEOUT_MS=90000` |

After any edit:

```bash
sudo systemctl restart bilals-playground
```

---

## 5. Everyday commands

```bash
sudo systemctl status bilals-playground      # is it running?
sudo systemctl restart bilals-playground     # restart
sudo systemctl stop bilals-playground        # stop for now
sudo systemctl start bilals-playground       # start again
sudo journalctl -u bilals-playground -f      # live logs (Ctrl+C to exit)
sudo journalctl -u bilals-playground -n 100  # last 100 log lines
```

To turn it off permanently: `sudo bash /data/bilals-playground/deploy/uninstall.sh`

### Updating to a new version

Extract the new zip over the old folder, then run the installer again. Your settings file is kept.

```bash
sudo python3 -m zipfile -e /tmp/bilals-playground.zip /data/
sudo bash /data/bilals-playground/deploy/install.sh
```

---

## 6. Troubleshooting

**Colleagues can't open the page, but `curl http://127.0.0.1:3000/health` works on the VM**

- Check firewalld: `sudo firewall-cmd --list-ports` should show `3000/tcp`.
- There may also be a network firewall between the office LAN and the VM. Ask IT to allow TCP 3000 to this VM.

**Service won't start**

- Run `sudo journalctl -u bilals-playground -n 50 --no-pager` and read the last lines.
- If you see `EADDRINUSE`, something else already uses port 3000. Change `PORT=` in `/etc/bilals-playground.env`, then run the installer again (it opens the new port).
- SELinux denials: `sudo ausearch -m avc -ts recent`. The installer only relabels files; it never changes SELinux policy.

**"Permission denied" on /data**

The installer checks that the `bpgame` user can read the folder. If it can't
(for example, because `/data` is locked down), it falls back to running as your
own user and tells you so.

---

## 7. How to play

1. Everyone opens `http://<VM-IP>:3000`, enters a name and the **same room code** (default `OFFICE`). You can also use **Copy invite link** in the lobby.
2. The first person in the room is the **host**. The host picks the rounds, draw time, a **theme** for the AI word pack (e.g. "Office life + Pakistani food", "Cricket"), and the language: English, Roman Urdu or Mix.
3. **Preview words** shows a sample from the AI before you start.
4. Each round, every player draws once. The drawer picks one of three words: easy (1×), medium (1.5×) or hard (2×).
5. Everyone else types guesses in the chat. Spelling, capitals and spaces are forgiven ("Doodh Patti" = "doodhpatti"), and near-misses show **"very close!"** privately.
6. Letters are revealed slowly as hints. Faster correct guesses score more. The drawer earns a bonus for each person who guesses.
7. Players who already guessed (and the drawer) can chat privately so they don't spoil the word.

Up to 12 players per room. You can run several rooms at once with different room codes.

---

## 8. What's inside

```
bilals-playground/
├── server.js           game server (rooms, turns, scoring, hints)
├── words.js            AI word generation + built-in fallback words
├── public/             the web page (HTML, CSS, JS, offline fonts)
├── node_modules/       socket.io (pure JavaScript, already installed)
├── deploy/install.sh   installer: systemd + firewalld
└── deploy/uninstall.sh removes the service
```

Fonts: Baloo 2 and Inter, both under the SIL Open Font License (see `public/fonts/`).
