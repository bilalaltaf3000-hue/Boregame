/* Bilal's Playground - browser client */
(function () {
  'use strict';

  var $ = function (id) { return document.getElementById(id); };
  var socket = io({ autoConnect: false, reconnectionDelayMax: 4000 });

  // ------------------------------------------------------------ storage helpers
  function store(kind, key, val) {
    try {
      var s = kind === 'local' ? window.localStorage : window.sessionStorage;
      if (val === undefined) return s.getItem(key);
      s.setItem(key, val);
    } catch (e) { return null; }
  }
  function uid() {
    return (Date.now().toString(36) + Math.random().toString(36).slice(2, 10)).slice(0, 20);
  }
  // sessionStorage: refreshing keeps you as the same player, a second tab is a new player
  var clientId = store('session', 'bp-client') || uid();
  store('session', 'bp-client', clientId);

  // ------------------------------------------------------------ state
  var S = null;           // latest room snapshot
  var joined = null;      // { name, room }
  var clockOffset = 0;
  var strokes = [];
  var tool = { color: '#16181D', size: 10, eraser: false };
  var drawing = null;     // current local stroke
  var pending = [];
  var lastPreviewKey = '';

  var COLORS = ['#16181D', '#FFFFFF', '#8A919E', '#D7263D', '#FF7A1A', '#FFC93C', '#1F9D55', '#0E9F8A', '#2F5BFF', '#7A3FD1', '#E85D9E', '#8A4B2A'];

  // ------------------------------------------------------------ home / join
  var params = new URLSearchParams(location.search);
  $('nameInput').value = store('local', 'bp-name') || '';
  $('roomInput').value = (params.get('room') || store('local', 'bp-room') || 'OFFICE').toUpperCase();

  $('joinForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var name = $('nameInput').value.trim();
    var room = $('roomInput').value.trim().toUpperCase().replace(/[^A-Z0-9]/g, '') || 'OFFICE';
    if (!name) { $('joinError').textContent = 'Please enter your name.'; return; }
    store('local', 'bp-name', name);
    store('local', 'bp-room', room);
    joined = { name: name, room: room };
    $('joinError').textContent = '';
    if (socket.connected) doJoin(); else socket.connect();
  });

  function doJoin() {
    if (!joined) return;
    socket.emit('join', { name: joined.name, room: joined.room, clientId: clientId }, function (res) {
      if (!res || !res.ok) {
        $('joinError').textContent = (res && res.error) || 'Could not join.';
        joined = null;
        socket.disconnect();
        showScreen('home');
        return;
      }
      history.replaceState(null, '', '/?room=' + encodeURIComponent(res.room));
    });
  }

  socket.on('connect', function () { $('connBanner').hidden = true; doJoin(); });
  socket.on('disconnect', function () { if (joined) $('connBanner').hidden = false; });

  // ------------------------------------------------------------ screens
  function showScreen(id) {
    ['home', 'lobby', 'game', 'final'].forEach(function (s) { $(s).hidden = s !== id; });
    if (id === 'game') resizeCanvas();
  }

  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = text;
    return n;
  }
  function avatar(p, small) {
    var a = el('div', 'avatar' + (small ? ' sm' : ''), (p.name || '?').charAt(0).toUpperCase());
    a.style.background = p.color;
    a.style.color = isDark(p.color) ? '#FFFFFF' : '#16181D';
    a.setAttribute('aria-hidden', 'true');
    return a;
  }
  function isDark(hex) {
    var r = parseInt(hex.substr(1, 2), 16), g = parseInt(hex.substr(3, 2), 16), b = parseInt(hex.substr(5, 2), 16);
    return (0.299 * r + 0.587 * g + 0.114 * b) < 150;
  }
  function me() { return S && S.players.filter(function (p) { return p.id === S.you; })[0]; }
  function amHost() { return S && S.hostId === S.you; }
  function amDrawer() { return S && S.drawerId === S.you; }

  // ------------------------------------------------------------ incoming state
  socket.on('state', function (s) {
    var prev = S;
    S = s;
    clockOffset = s.serverNow - Date.now();
    if (s.state === 'lobby' || s.state === 'loading') { renderLobby(); showScreen('lobby'); }
    else if (s.state === 'gameOver') { renderFinal(); showScreen('final'); }
    else { renderGame(prev); showScreen('game'); }
  });

  // ------------------------------------------------------------ lobby
  function renderLobby() {
    $('roomCode').textContent = S.code;
    $('playerCount').textContent = S.players.length + ' of 12';
    var tiles = $('lobbyPlayers');
    tiles.innerHTML = '';
    S.players.forEach(function (p) {
      var t = el('div', 'tile' + (p.id === S.you ? ' me' : ''));
      t.appendChild(avatar(p));
      t.appendChild(el('div', 'name', p.name));
      t.appendChild(el('div', 'tag', p.isHost ? 'Host' : (p.id === S.you ? 'You' : 'Ready')));
      tiles.appendChild(t);
    });
    if (S.players.length < 12) tiles.appendChild(el('div', 'tile empty', S.players.length < 2 ? 'Invite at least 1 more…' : 'Waiting for more…'));

    var host = amHost();
    var loading = S.state === 'loading';
    document.querySelectorAll('.seg').forEach(function (seg) {
      var key = seg.getAttribute('data-setting');
      seg.querySelectorAll('button').forEach(function (b) {
        b.setAttribute('aria-pressed', String(String(S.settings[key]) === b.getAttribute('data-value')));
        b.disabled = !host || loading;
      });
    });
    var ti = $('themeInput');
    if (document.activeElement !== ti || !host) ti.value = S.settings.theme;
    ti.disabled = !host || loading;
    $('previewBtn').hidden = !host;
    $('hostOnly').textContent = host ? 'You are the host' : 'Only the host can change these';
    $('startBtn').hidden = !host;
    $('waitHost').hidden = host;
    $('startBtn').disabled = loading || S.players.length < 2;
    $('startBtn').textContent = loading ? 'Getting words…' : 'Start game';
    $('lobbyNotice').hidden = !S.notice;
    $('lobbyNotice').textContent = S.notice || '';

    var key = S.settings.theme + '|' + S.settings.lang;
    if (lastPreviewKey && key !== lastPreviewKey) { $('previewWords').innerHTML = ''; $('previewNote').textContent = ''; lastPreviewKey = ''; }
  }

  document.querySelectorAll('.seg').forEach(function (seg) {
    seg.addEventListener('click', function (e) {
      var b = e.target.closest('button');
      if (!b || !amHost()) return;
      var upd = {};
      upd[seg.getAttribute('data-setting')] = b.getAttribute('data-value');
      socket.emit('settings', upd);
    });
  });
  var themeTimer = null;
  $('themeInput').addEventListener('input', function () {
    clearTimeout(themeTimer);
    var v = this.value;
    themeTimer = setTimeout(function () { socket.emit('settings', { theme: v }); }, 400);
  });
  $('previewBtn').addEventListener('click', function () {
    clearTimeout(themeTimer);
    socket.emit('settings', { theme: $('themeInput').value });
    socket.emit('preview-words');
  });
  socket.on('preview', function (d) {
    var box = $('previewWords');
    box.innerHTML = '';
    if (d.loading) { $('previewNote').textContent = 'Asking the AI for words… (can take a few seconds)'; $('previewBtn').disabled = true; return; }
    $('previewBtn').disabled = false;
    (d.words || []).forEach(function (w) { box.appendChild(el('span', null, w)); });
    $('previewNote').textContent = d.source === 'ai' ? 'Fresh words from your AI. Each game uses a new mix.' : 'AI not reachable – showing built-in words.';
    lastPreviewKey = S ? S.settings.theme + '|' + S.settings.lang : '';
  });
  $('startBtn').addEventListener('click', function () { socket.emit('start'); });

  $('copyLink').addEventListener('click', function () {
    var link = location.origin + '/?room=' + encodeURIComponent(S ? S.code : '');
    var done = function () { $('copyLink').textContent = 'Copied!'; setTimeout(function () { $('copyLink').textContent = 'Copy invite link'; }, 1500); };
    var fallback = function () {
      var ta = document.createElement('textarea');
      ta.value = link; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) { ok = false; }
      document.body.removeChild(ta);
      if (ok) done(); else { $('copyFallback').hidden = false; $('copyFallback').textContent = 'Share this link: ' + link; }
    };
    if (navigator.clipboard && window.isSecureContext) navigator.clipboard.writeText(link).then(done, fallback);
    else fallback();
  });

  // ------------------------------------------------------------ game
  function renderGame(prev) {
    $('roundLabel').textContent = 'Round ' + Math.max(1, S.round) + ' of ' + S.settings.rounds;
    renderHint();
    renderGamePlayers();
    $('endGameBtn').hidden = !amHost();

    var drawerNow = amDrawer() && S.state === 'drawing';
    $('toolbar').hidden = !drawerNow;
    $('watchBar').hidden = drawerNow;
    $('canvas').classList.toggle('can-draw', drawerNow);
    if (!drawerNow) {
      var gotIt = me() && me().guessed;
      $('watchBar').textContent = S.state === 'drawing'
        ? (gotIt ? 'You got it! Waiting for the others…' : S.drawerName + ' is drawing – type your guesses in the chat!')
        : S.state === 'choosing' ? (amDrawer() ? 'Pick a word to start drawing' : S.drawerName + ' is picking a word…')
        : 'Next turn coming up…';
    }

    var gi = $('guessInput');
    var guessed = me() && me().guessed;
    if (drawerNow) { gi.disabled = false; gi.placeholder = 'Chat with players who guessed'; }
    else if (guessed && S.state === 'drawing') { gi.disabled = false; gi.placeholder = 'Chat with players who guessed'; }
    else { gi.disabled = false; gi.placeholder = 'Type your guess…'; }

    renderOverlay(prev);
    if (prev && prev.state !== 'drawing' && S.state === 'drawing' && drawerNow) beep(660, 0.08);
  }

  function renderHint() {
    var h = $('hint');
    h.innerHTML = '';
    h.classList.remove('reveal');
    if (S.state === 'drawing' && S.hint) {
      var full = S.hint.indexOf('_') === -1;
      var letters = S.hint.filter(function (c) { return c !== ' '; }).length;
      var parts = S.hint.join('').split(' ').map(function (w) { return w.length; });
      $('hintLabel').textContent = amDrawer() ? 'Draw this · ' + S.difficulty : (full ? 'You guessed it!' : 'Guess the word · ' + (parts.length > 1 ? parts.join(' + ') : letters) + ' letters');
      if (full) h.classList.add('reveal');
      S.hint.forEach(function (c) { h.appendChild(c === ' ' ? el('span', 'gap') : el('span', null, c)); });
    } else if (S.state === 'choosing') {
      $('hintLabel').textContent = amDrawer() ? 'Your turn' : S.drawerName + ' is choosing';
      h.textContent = '…';
    } else if (S.state === 'turnEnd' && S.result) {
      $('hintLabel').textContent = 'The word was';
      h.classList.add('reveal');
      h.textContent = S.result.word;
    } else {
      $('hintLabel').innerHTML = '&nbsp;';
    }
  }

  function renderGamePlayers() {
    var list = $('gamePlayers');
    list.innerHTML = '';
    S.players.slice().sort(function (a, b) { return b.score - a.score; }).forEach(function (p) {
      var cls = 'gp';
      var status = 'Thinking…';
      if (p.isDrawer && (S.state === 'drawing' || S.state === 'choosing')) { cls += ' drawing'; status = S.state === 'choosing' ? 'Picking a word' : 'Drawing now'; }
      else if (p.guessed && S.state === 'drawing') { cls += ' guessed'; status = 'Guessed it'; }
      else if (S.state !== 'drawing') status = p.isHost ? 'Host' : ' ';
      var li = el('li', cls);
      li.appendChild(avatar(p, true));
      var who = el('div', 'who');
      who.appendChild(el('div', 'nm', p.name + (p.id === S.you ? ' (you)' : '')));
      who.appendChild(el('div', 'st', status));
      li.appendChild(who);
      li.appendChild(el('div', 'pts', String(p.score)));
      list.appendChild(li);
    });
  }

  function renderOverlay(prev) {
    var ov = $('overlay'), card = $('overlayCard');
    card.innerHTML = '';
    if (S.state === 'choosing' && amDrawer() && S.choices) {
      var head = el('div', 'row-between');
      var t = el('div');
      t.appendChild(el('h2', null, 'Your turn to draw!'));
      t.appendChild(el('p', 'muted', 'Pick one word. Harder words score more.'));
      head.appendChild(t);
      card.appendChild(head);
      var grid = el('div', 'choices');
      S.choices.forEach(function (c, i) {
        var b = el('button', 'choice');
        b.type = 'button';
        var mult = { easy: '1×', medium: '1.5×', hard: '2×' }[c.difficulty];
        b.appendChild(el('span', 'diff ' + c.difficulty, c.difficulty + ' · ' + mult));
        b.appendChild(el('span', 'word', c.word));
        b.addEventListener('click', function () { socket.emit('choose', i); });
        grid.appendChild(b);
      });
      card.appendChild(grid);
      ov.hidden = false;
    } else if (S.state === 'choosing') {
      card.appendChild(el('div', 'spinner'));
      card.appendChild(el('h2', 'center', S.drawerName + ' is picking a word…'));
      ov.hidden = false;
    } else if (S.state === 'turnEnd' && S.result) {
      var r = S.result;
      var why = r.reason === 'all' ? 'Everyone guessed it!' : r.reason === 'left' ? 'The drawer left.' : r.reason === 'skip' ? 'Turn skipped.' : 'Time\'s up!';
      card.appendChild(el('p', 'eyebrow center', why + ' The word was'));
      card.appendChild(el('div', 'big-word', r.word));
      card.appendChild(el('p', 'muted center', r.guessedCount + ' of ' + r.possible + ' guessed it · drawn by ' + r.drawerName));
      var rows = el('div', 'result-rows');
      r.rows.forEach(function (row) {
        var d = el('div', 'result-row');
        d.appendChild(avatar(row, true));
        d.appendChild(el('span', 'nm', row.name));
        var cls = 'delta' + (row.delta > 0 ? (row.isDrawer ? ' drawer' : ' plus') : '');
        d.appendChild(el('span', cls, row.delta > 0 ? '+' + row.delta + (row.isDrawer ? ' drawer bonus' : '') : '+0'));
        d.appendChild(el('span', 'pts strong', String(row.total)));
        rows.appendChild(d);
      });
      card.appendChild(rows);
      ov.hidden = false;
    } else {
      ov.hidden = true;
    }
  }

  // timer tick
  setInterval(function () {
    if (!S || !S.endsAt || (S.state !== 'drawing' && S.state !== 'choosing' && S.state !== 'turnEnd')) { $('timerText').textContent = '--'; $('timer').classList.remove('urgent'); return; }
    var left = Math.max(0, Math.ceil((S.endsAt - (Date.now() + clockOffset)) / 1000));
    $('timerText').textContent = left + 's';
    $('timer').classList.toggle('urgent', S.state === 'drawing' && left <= 10);
  }, 250);

  $('skipBtn').addEventListener('click', function () { if (confirm('Skip your turn?')) socket.emit('skip-turn'); });
  $('endGameBtn').addEventListener('click', function () { if (confirm('End the game for everyone and go back to the lobby?')) socket.emit('end-game'); });

  // ------------------------------------------------------------ chat
  $('guessForm').addEventListener('submit', function (e) {
    e.preventDefault();
    var v = $('guessInput').value.trim();
    if (!v) return;
    socket.emit('guess', v);
    $('guessInput').value = '';
  });

  socket.on('msg', function (m) {
    var box = $('messages');
    var atBottom = box.scrollHeight - box.scrollTop - box.clientHeight < 40;
    var d = el('div', 'm ' + m.type);
    if (m.type === 'chat' || m.type === 'chat-secret') {
      var b = el('b', null, m.name + ': ');
      d.appendChild(b);
      d.appendChild(document.createTextNode(m.text));
    } else {
      d.textContent = m.text;
    }
    box.appendChild(d);
    while (box.children.length > 200) box.removeChild(box.firstChild);
    if (atBottom) box.scrollTop = box.scrollHeight;
    if (m.type === 'correct') beep(880, 0.12);
  });

  // ------------------------------------------------------------ final
  function renderFinal() {
    var f = S.final || [];
    $('winnerName').textContent = f[0] ? f[0].name : '–';
    var pod = $('podium');
    pod.innerHTML = '';
    var order = [1, 0, 2];
    var heights = [150, 110, 80];
    order.forEach(function (i) {
      var p = f[i];
      if (!p) return;
      var d = el('div', 'pod' + (i === 0 ? ' first' : ''));
      if (i === 0) {
        d.insertAdjacentHTML('beforeend', '<svg class="crown" viewBox="0 0 32 24" role="img" aria-label="Winner"><path d="M2 22 4 6l8 8 4-12 4 12 8-8 2 16Z" fill="#FFC93C" stroke="#16181D" stroke-width="2"/></svg>');
      }
      d.appendChild(avatar(p));
      d.appendChild(el('div', 'nm', p.name));
      var blk = el('div', 'block');
      blk.style.height = heights[i] + 'px';
      blk.appendChild(el('span', 'place', String(i + 1)));
      blk.appendChild(el('span', null, p.score + ' pts'));
      d.appendChild(blk);
      pod.appendChild(d);
    });
    var list = $('finalList');
    list.innerHTML = '';
    f.forEach(function (p, i) {
      var li = el('li');
      li.appendChild(el('span', 'rk', String(i + 1)));
      li.appendChild(avatar(p, true));
      li.appendChild(el('span', 'nm', p.name));
      li.appendChild(el('span', 'strong', p.score + ' pts'));
      list.appendChild(li);
    });
    $('lobbyBtn').hidden = !amHost();
    $('finalWait').textContent = amHost() ? 'Play again with the same group?' : 'Waiting for the host…';
  }
  $('lobbyBtn').addEventListener('click', function () { socket.emit('back-to-lobby'); });

  // ------------------------------------------------------------ canvas
  var canvas = $('canvas');
  var ctx = canvas.getContext('2d');
  var W = 1000, H = 750;

  function scale() { return canvas.width / W; }

  function resizeCanvas() {
    var r = canvas.getBoundingClientRect();
    if (!r.width) return;
    var dpr = Math.min(window.devicePixelRatio || 1, 2);
    var w = Math.round(r.width * dpr), h = Math.round(r.width * 0.75 * dpr);
    if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; }
    redraw();
  }
  if (window.ResizeObserver) new ResizeObserver(resizeCanvas).observe($('canvasWrap'));
  window.addEventListener('resize', resizeCanvas);

  function redraw() {
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    strokes.forEach(function (s) { drawSegment(s, 0); });
  }

  function drawSegment(s, from) {
    var k = scale();
    var p = s.p;
    if (!p.length) return;
    ctx.strokeStyle = s.c;
    ctx.fillStyle = s.c;
    ctx.lineWidth = s.w * k;
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    if (p.length === 1 && from === 0) {
      ctx.beginPath();
      ctx.arc(p[0][0] * k, p[0][1] * k, (s.w * k) / 2, 0, Math.PI * 2);
      ctx.fill();
      return;
    }
    var start = Math.max(0, from - 1);
    ctx.beginPath();
    ctx.moveTo(p[start][0] * k, p[start][1] * k);
    for (var i = start + 1; i < p.length; i++) ctx.lineTo(p[i][0] * k, p[i][1] * k);
    ctx.stroke();
  }

  function findStroke(id) {
    for (var i = strokes.length - 1; i >= 0; i--) if (strokes[i].id === id) return strokes[i];
    return null;
  }

  socket.on('canvas', function (d) { strokes = (d && d.strokes) || []; redraw(); });
  socket.on('clear', function () { strokes = []; redraw(); });
  socket.on('undo', function (d) { strokes = strokes.filter(function (s) { return s.id !== d.id; }); redraw(); });
  socket.on('draw', function (op) {
    if (op.t === 's') { var s = { id: op.id, c: op.c, w: op.w, p: op.p.slice() }; strokes.push(s); drawSegment(s, 0); }
    else if (op.t === 'a') { var st = findStroke(op.id); if (!st) return; var from = st.p.length; Array.prototype.push.apply(st.p, op.p); drawSegment(st, from); }
  });

  function toLogical(e) {
    var r = canvas.getBoundingClientRect();
    return [Math.round((e.clientX - r.left) / r.width * W), Math.round((e.clientY - r.top) / r.height * H)];
  }
  function canDraw() { return S && S.state === 'drawing' && amDrawer(); }

  canvas.addEventListener('pointerdown', function (e) {
    if (!canDraw() || (e.button !== undefined && e.button > 0)) return;
    e.preventDefault();
    canvas.setPointerCapture(e.pointerId);
    var pt = toLogical(e);
    drawing = { id: uid(), c: tool.eraser ? '#FFFFFF' : tool.color, w: tool.eraser ? Math.max(tool.size, 22) : tool.size, p: [pt] };
    strokes.push(drawing);
    drawSegment(drawing, 0);
    socket.emit('draw', { t: 's', id: drawing.id, c: drawing.c, w: drawing.w, p: [pt] });
  });
  canvas.addEventListener('pointermove', function (e) {
    if (!drawing) return;
    var evs = e.getCoalescedEvents ? e.getCoalescedEvents() : [e];
    if (!evs.length) evs = [e];
    var from = drawing.p.length;
    evs.forEach(function (ev) {
      var pt = toLogical(ev);
      var last = drawing.p[drawing.p.length - 1];
      if (Math.abs(pt[0] - last[0]) + Math.abs(pt[1] - last[1]) < 2) return;
      drawing.p.push(pt);
      pending.push(pt);
    });
    if (drawing.p.length > from) drawSegment(drawing, from);
  });
  function endStroke() { if (!drawing) return; flush(); drawing = null; }
  canvas.addEventListener('pointerup', endStroke);
  canvas.addEventListener('pointercancel', endStroke);
  canvas.addEventListener('lostpointercapture', endStroke);

  function flush() {
    if (drawing && pending.length) { socket.emit('draw', { t: 'a', id: drawing.id, p: pending }); pending = []; }
  }
  setInterval(flush, 40);

  // toolbar
  var colorBox = $('colors');
  COLORS.forEach(function (c) {
    var b = el('button', 'swatch');
    b.type = 'button';
    b.style.background = c;
    b.setAttribute('aria-label', 'Color ' + c);
    b.setAttribute('data-color', c);
    b.addEventListener('click', function () { tool.color = c; tool.eraser = false; syncTools(); });
    colorBox.appendChild(b);
  });
  document.querySelectorAll('.tool.size').forEach(function (b) {
    b.addEventListener('click', function () { tool.size = parseInt(b.getAttribute('data-size'), 10); syncTools(); });
  });
  $('eraserBtn').addEventListener('click', function () { tool.eraser = !tool.eraser; syncTools(); });
  function undo() {
    if (!canDraw()) return;
    for (var i = strokes.length - 1; i >= 0; i--) {
      strokes.splice(i, 1);
      break;
    }
    redraw();
    socket.emit('undo');
  }
  $('undoBtn').addEventListener('click', undo);
  $('clearBtn').addEventListener('click', function () { if (!canDraw()) return; strokes = []; redraw(); socket.emit('clear'); });
  document.addEventListener('keydown', function (e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'z' && canDraw() && document.activeElement !== $('guessInput')) { e.preventDefault(); undo(); }
  });
  function syncTools() {
    colorBox.querySelectorAll('.swatch').forEach(function (b) { b.setAttribute('aria-pressed', String(!tool.eraser && b.getAttribute('data-color') === tool.color)); });
    document.querySelectorAll('.tool.size').forEach(function (b) { b.setAttribute('aria-pressed', String(parseInt(b.getAttribute('data-size'), 10) === tool.size)); });
    $('eraserBtn').setAttribute('aria-pressed', String(tool.eraser));
  }
  syncTools();

  // ------------------------------------------------------------ tiny sounds (offline, no files)
  var audioCtx = null;
  function beep(freq, dur) {
    try {
      audioCtx = audioCtx || new (window.AudioContext || window.webkitAudioContext)();
      var o = audioCtx.createOscillator(), g = audioCtx.createGain();
      o.frequency.value = freq; o.type = 'sine';
      g.gain.setValueAtTime(0.06, audioCtx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + dur);
      o.connect(g); g.connect(audioCtx.destination);
      o.start(); o.stop(audioCtx.currentTime + dur);
    } catch (e) { /* sound is optional */ }
  }

  showScreen('home');
})();
