'use strict';
// Word generation for Bilal's Playground.
// Calls the local AI (OpenAI-compatible API, e.g. vLLM / Ollama / llama.cpp server)
// and falls back to a built-in list if the AI is slow, down, or returns junk.

const http = require('http');
const https = require('https');

const AI_URL = process.env.AI_URL || 'http://127.0.0.1:8001/v1/chat/completions';
const AI_MODEL = process.env.AI_MODEL || ''; // empty = auto-detect from /v1/models
const AI_TIMEOUT_MS = parseInt(process.env.AI_TIMEOUT_MS || '90000', 10);
const AI_API_KEY = process.env.AI_API_KEY || '';

let detectedModel = null;
let lastAiStatus = { ok: null, at: null, detail: 'not used yet' };

// ---------------------------------------------------------------- fallback lists
const FALLBACK = {
  english: {
    easy: ['cup', 'chair', 'sun', 'tree', 'house', 'car', 'cat', 'fish', 'book', 'phone', 'clock', 'key',
      'pen', 'door', 'apple', 'star', 'moon', 'shoe', 'bed', 'ball', 'egg', 'hat', 'bus', 'kite', 'tea',
      'fan', 'bag', 'cake', 'bird', 'rain'],
    medium: ['laptop', 'stapler', 'printer', 'umbrella', 'elevator', 'calendar', 'keyboard', 'sandwich',
      'bicycle', 'airplane', 'coffee mug', 'water bottle', 'headphones', 'backpack', 'toothbrush',
      'parking lot', 'traffic light', 'cricket bat', 'paper plane', 'lunch box', 'id card', 'whiteboard',
      'sunglasses', 'microwave', 'escalator', 'calculator', 'office chair', 'notebook', 'mouse pad', 'charger'],
    hard: ['deadline', 'meeting', 'promotion', 'overtime', 'printer jam', 'wifi signal', 'password',
      'coffee break', 'team lunch', 'salary day', 'monday morning', 'traffic jam', 'power outage',
      'video call', 'out of office', 'brainstorm', 'teamwork', 'presentation', 'weekend', 'monsoon',
      'load shedding', 'fire drill', 'appraisal', 'birthday party', 'lost and found', 'reply all',
      'spreadsheet', 'firewall', 'error message', 'hide and seek']
  },
  urdu: {
    easy: ['chai', 'roti', 'kursi', 'pankha', 'chappal', 'kitaab', 'ghar', 'gari', 'billi', 'machli',
      'aam', 'kela', 'chand', 'suraj', 'phool', 'darwaza', 'paani', 'doodh', 'anda', 'topi', 'chabi',
      'chaata', 'patang', 'samosa', 'pakora', 'biryani', 'naan', 'daal', 'gulab', 'jhoola'],
    medium: ['rickshaw', 'tandoor', 'jalebi', 'gol gappay', 'chaat', 'lassi', 'haleem', 'nihari',
      'karahi', 'paratha', 'chanay', 'kabab', 'qulfi', 'dupatta', 'chaarpai', 'lota', 'gharra',
      'minar', 'baraat', 'mehndi', 'ghari', 'chimta', 'handi', 'tawa', 'dhaba', 'darzi', 'naai',
      'chowkidar', 'surahi', 'dastarkhwan'],
    hard: ['doodh patti', 'load shedding', 'shaadi', 'chand raat', 'cricket match', 'sehri',
      'iftari', 'chai ka waqfa', 'traffic jam', 'barish', 'bijli', 'imtihaan', 'chutti', 'tankhwah',
      'mehman', 'gappay', 'thanda paani', 'garmi', 'sardi', 'naya saal', 'jashan', 'mela', 'safar',
      'bazaar', 'qatar', 'intezar', 'dawat', 'kahani', 'khwab', 'dosti']
  }
};

function fallbackPack(lang) {
  const pick = (k) => {
    if (lang === 'urdu') return FALLBACK.urdu[k].slice();
    if (lang === 'mix') return FALLBACK.english[k].concat(FALLBACK.urdu[k]);
    return FALLBACK.english[k].slice();
  };
  return { easy: pick('easy'), medium: pick('medium'), hard: pick('hard'), source: 'builtin' };
}

// ---------------------------------------------------------------- HTTP helper
function requestJson(method, urlStr, body, timeoutMs) {
  return new Promise((resolve, reject) => {
    let u;
    try { u = new URL(urlStr); } catch (e) { return reject(new Error('Bad AI_URL: ' + urlStr)); }
    const lib = u.protocol === 'https:' ? https : http;
    const payload = body ? JSON.stringify(body) : null;
    const headers = { 'Accept': 'application/json' };
    if (payload) {
      headers['Content-Type'] = 'application/json';
      headers['Content-Length'] = Buffer.byteLength(payload);
    }
    if (AI_API_KEY) headers['Authorization'] = 'Bearer ' + AI_API_KEY;
    const req = lib.request({
      method, hostname: u.hostname, port: u.port, path: u.pathname + u.search, headers
    }, (res) => {
      let data = '';
      res.setEncoding('utf8');
      res.on('data', (c) => { data += c; if (data.length > 2e6) req.destroy(new Error('Response too large')); });
      res.on('end', () => {
        if (res.statusCode < 200 || res.statusCode >= 300) {
          return reject(new Error('HTTP ' + res.statusCode + ': ' + data.slice(0, 200)));
        }
        try { resolve(JSON.parse(data)); } catch (e) { reject(new Error('Invalid JSON from AI server')); }
      });
    });
    req.setTimeout(timeoutMs, () => req.destroy(new Error('AI request timed out after ' + timeoutMs + 'ms')));
    req.on('error', reject);
    if (payload) req.write(payload);
    req.end();
  });
}

async function getModel() {
  if (AI_MODEL) return AI_MODEL;
  if (detectedModel) return detectedModel;
  const modelsUrl = AI_URL.replace(/\/chat\/completions\/?$/, '/models');
  const res = await requestJson('GET', modelsUrl, null, 8000);
  const first = res && res.data && res.data[0] && res.data[0].id;
  if (!first) throw new Error('Could not detect model name from ' + modelsUrl + ' (set AI_MODEL)');
  detectedModel = first;
  return first;
}

// ---------------------------------------------------------------- cleaning
const WORD_RE = /^[a-z][a-z' -]{0,26}[a-z]$/;

// filler words a model sometimes tacks on ("sunrise view", "drawing tree")
const FILLER_RE = /\b(view|scene|scenery|drawing|picture|image|shape|sketch|icon|symbol|shaking)\b/;

function cleanList(list, seen) {
  if (!Array.isArray(list)) return [];
  const out = [];
  seen = seen || new Set();
  for (let w of list) {
    if (typeof w !== 'string' || /[0-9]/.test(w)) continue;
    w = w.toLowerCase().replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim();
    w = w.replace(/^[^a-z]+|[^a-z]+$/g, '');
    if (!WORD_RE.test(w)) continue;
    if (FILLER_RE.test(w)) continue;
    if (w.split(' ').length > 3) continue;
    if (seen.has(w)) continue;
    seen.add(w);
    out.push(w);
  }
  return out;
}

function extractJson(text) {
  if (!text) return null;
  const t = String(text).replace(/```(?:json)?/gi, '');
  const start = t.indexOf('{');
  const end = t.lastIndexOf('}');
  if (start === -1 || end <= start) return null;
  try { return JSON.parse(t.slice(start, end + 1)); } catch (e) { return null; }
}

function buildPrompt(theme, lang) {
  const langLine = lang === 'urdu'
    ? 'Write every word in Roman Urdu (Urdu written with English letters, e.g. "chai", "chaarpai", "doodh patti"). Use common spellings.'
    : lang === 'mix'
      ? 'Use a mix: about half simple English words and half Roman Urdu words (Urdu written with English letters, e.g. "chai", "chaarpai").'
      : 'Write every word in simple English.';
  const parts = theme.split(/\s*(?:\+|,|&|\band\b)\s*/i).map((s) => s.trim()).filter(Boolean);
  const partsLine = parts.length > 1
    ? 'The theme has ' + parts.length + ' parts: ' + parts.map((p) => '"' + p + '"').join(', ') +
      '. Every entry must be a specific example of ONE of these parts. Spread entries evenly across all parts in every difficulty level.'
    : 'Every entry must be a specific example of "' + theme + '".';
  return [
    'You create word lists for a Pictionary-style drawing game played by office colleagues in Pakistan.',
    'Theme: "' + theme + '".',
    partsLine,
    'STRICT: do not include anything outside the theme. No general scenes, weather, nature, space or actions unless the theme asks for them.',
    'Each entry is the plain name of the thing: 1 to 3 words, letters and spaces only. Never add words like "view", "scene", "drawing", "picture", "image" or "shape".',
    'No real people, brands, or anything offensive, political, religious-sensitive or adult.',
    langLine,
    'Difficulty means how hard it is to DRAW and GUESS, always inside the theme:',
    '- easy: very well known, simple to draw (e.g. fruits: apple, banana; countries: Pakistan, Japan)',
    '- medium: well known but needs more detail (e.g. fruits: pineapple, pomegranate; cities: Paris, Lahore)',
    '- hard: less common or tricky to draw (e.g. fruits: lychee, dragon fruit; countries: Switzerland, Egypt)',
    'Use each entry only once across all three lists.',
    'Return ONLY JSON, no explanation, exactly in this shape:',
    '{"easy": [40 entries], "medium": [40 entries], "hard": [40 entries]}'
  ].join('\n');
}

// ---------------------------------------------------------------- main entry
async function generatePack(theme, lang) {
  theme = String(theme || '').slice(0, 80).trim() || 'everyday things';
  const started = Date.now();
  try {
    const model = await getModel();
    const res = await requestJson('POST', AI_URL, {
      model,
      messages: [
        { role: 'system', content: 'You are a helpful assistant that only answers with valid JSON.' },
        { role: 'user', content: buildPrompt(theme, lang) }
      ],
      temperature: 0.6,
      max_tokens: 2500
    }, AI_TIMEOUT_MS);
    const content = res && res.choices && res.choices[0] && res.choices[0].message && res.choices[0].message.content;
    const parsed = extractJson(content);
    if (!parsed) throw new Error('AI did not return usable JSON');
    const seen = new Set(); // no word in two difficulty levels
    const pack = {
      easy: cleanList(parsed.easy, seen),
      medium: cleanList(parsed.medium, seen),
      hard: cleanList(parsed.hard, seen),
      source: 'ai'
    };
    // Top up thin buckets from the built-in list so the game never runs dry.
    const fb = fallbackPack(lang);
    let toppedUp = false;
    for (const k of ['easy', 'medium', 'hard']) {
      if (pack[k].length < 8) {
        toppedUp = true;
        for (const w of fb[k]) { if (pack[k].indexOf(w) === -1) pack[k].push(w); }
      }
    }
    const total = pack.easy.length + pack.medium.length + pack.hard.length;
    lastAiStatus = { ok: true, at: new Date().toISOString(), detail: 'model ' + model + ', ' + total + ' words in ' + (Date.now() - started) + 'ms' + (toppedUp ? ' (topped up)' : '') };
    console.log('[words] AI pack for "' + theme + '" (' + lang + '): ' + lastAiStatus.detail);
    return pack;
  } catch (err) {
    lastAiStatus = { ok: false, at: new Date().toISOString(), detail: err.message };
    console.warn('[words] AI unavailable, using built-in words: ' + err.message);
    return fallbackPack(lang);
  }
}

module.exports = { generatePack, fallbackPack, getAiStatus: () => lastAiStatus, AI_URL };
