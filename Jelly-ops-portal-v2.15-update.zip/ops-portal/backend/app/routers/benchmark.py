"""Grade benchmark: figures for the dashboard and organogram, the Excel of exceptions, and the admin settings."""
import io
from datetime import datetime
from typing import Dict, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from .. import benchmark as bm
from .. import models
from ..db import get_db
from ..security import audit, current_user, require_dashboard, sees_everything, view_ids

SUPER = "admin"   # the one login that owns the grade benchmark


def require_bm(user=Depends(require_dashboard)):
    """The grade benchmark is hidden from everyone, admins included, unless the "admin" login ticked it for them."""
    if user.username != SUPER and not user.can_benchmark:
        raise HTTPException(403, "The grade benchmark is not available for this login.")
    return user


def require_super(user=Depends(current_user)):
    """Changing the benchmark: the "admin" login, and administrators it gave the right to (with the benchmark ticked)."""
    if user.role != "admin" or not (user.username == SUPER or (user.can_benchmark and user.can_bm_edit)):
        raise HTTPException(403, "Only the admin login, or an administrator it allowed, can change the grade benchmark.")
    return user

router = APIRouter(prefix="/api/bm")


def _scope(user, db, functions: str = ""):
    allowed = {f.id for f in db.query(models.Function.id)} if sees_everything(user) else view_ids(user, db)
    want = {int(x) for x in (functions or "").split(",") if x.strip().isdigit()}
    return (want & allowed) if want else allowed


def _people(db, codes):
    return {e.code: e for e in db.query(models.Employee).filter(models.Employee.code.in_(list(codes) or ["-"]))}


def _fn_out(f, ladder, cfg):
    mx = cfg[f["band"]]
    return {**{k: f[k] for k in ("id", "name", "type", "permanent", "headcount", "band", "above", "at", "room", "assessed", "beyond", "extra", "counts", "band_set", "auto_band")},
            "maxes": {lv: ladder.get(v, str(v)) for lv, v in mx.items()}}


@router.get("/framework")
def framework(user=Depends(current_user), db: Session = Depends(get_db)):
    """The benchmark grid only (levels and grade bands, no one's grades), for the View Benchmark button."""
    if not (user.username == SUPER or user.can_bm_view or user.can_benchmark or user.can_chro):   # also the HR Dashboard (Position Benchmark)
        raise HTTPException(403, "The benchmark is not available for this login.")
    return {"settings": bm.settings(db), "ladder": bm.grade_ladder(db)}


@router.get("/people")
def people(user=Depends(require_bm), db: Session = Depends(get_db)):
    """Per person, for the organogram: level, tier, max grade, gap, layer beyond the model."""
    d = bm.compute(db)
    fids = _scope(user, db)
    out = {}
    for c, p in d["people"].items():
        if p["fid"] not in fids:
            continue
        r = {"l": p["level"], "a": 1 if p["auto"] else 0, "y": p["layer"], "bw": p.get("below")}
        if p.get("tier"):
            r.update(t=p["tier"], mx=p["max_name"], mn=p.get("min_name", ""), g=p["gap"], bl=p["bench_level"])
        if p.get("beyond"):
            r["b"] = 1
        out[c] = r
    return {"people": out, "threshold": d["settings"]["threshold"],
            "functions": {str(f["id"]): {"type": f["type"], "band": f["band"], "permanent": f["permanent"]}
                          for f in d["functions"].values() if f["id"] in fids}}


@router.get("/overview")
def overview(functions: str = Query(""), user=Depends(require_bm), db: Session = Depends(get_db)):
    d = bm.compute(db)
    fids = _scope(user, db, functions)
    fr = [f for f in d["functions"].values() if f["id"] in fids]
    tagged = [f for f in fr if f["type"]]
    rows = [p | {"code": c} for c, p in d["people"].items() if p["fid"] in fids]
    above = [r for r in rows if r.get("tier") == "above"]
    at = [r for r in rows if r.get("tier") == "at"]
    room = [r for r in rows if r.get("tier") == "room"]
    extra = [r for r in rows if r.get("gate")]
    beyond = [r for r in rows if r.get("beyond")]
    E = _people(db, [r["code"] for r in above + at + room + extra])
    fname = {f["id"]: f["name"] for f in fr}

    def who(r):
        e = E[r["code"]]
        return {"code": r["code"], "name": e.name, "position": e.position or "", "grade": e.grade or "", "function": fname[r["fid"]], "fid": r["fid"],
                "level": r["level"], "layer": r["layer"]}
    kids: Dict[str, int] = {}
    if extra:
        mgr = {e.code: e.manager_code for e in db.query(models.Employee.code, models.Employee.manager_code).filter(models.Employee.resigned == False)}  # noqa: E712
        ch: Dict[str, list] = {}
        for c, m in mgr.items():
            ch.setdefault(m, []).append(c)
        for r in extra:
            stack, n, seen = list(ch.get(r["code"], [])), 0, set()
            while stack:
                x = stack.pop()
                if x in seen:
                    continue
                seen.add(x)
                n += 1
                stack.extend(ch.get(x, []))
            kids[r["code"]] = n
    return {"kpis": {"assessed": sum(f["assessed"] for f in tagged), "above": sum(f["above"] for f in tagged), "at": sum(f["at"] for f in tagged),
                     "room": sum(f["room"] for f in tagged), "untagged": sum(1 for f in fr if not f["type"]), "beyond": len(beyond),
                     "beyond_functions": len({r["fid"] for r in beyond}), "extra": len(extra)},
            "functions": sorted([_fn_out(f, d["ladder"], d["settings"]) for f in fr], key=lambda f: (not f["type"], -f["permanent"], f["name"])),
            "above": sorted([who(r) | {"max": r["max_name"], "min": r.get("min_name", ""), "gap": r["gap"], "bench_level": r["bench_level"]} for r in above],
                            key=lambda x: (-x["gap"], x["function"], x["name"])),
            "at": sorted([who(r) | {"max": r["max_name"], "min": r.get("min_name", ""), "bench_level": r["bench_level"]} for r in at], key=lambda x: (x["function"], x["layer"] or 9, x["name"])),
            "room": sorted([who(r) | {"max": r["max_name"], "min": r.get("min_name", ""), "bench_level": r["bench_level"]} for r in room], key=lambda x: (x["function"], x["layer"] or 9, x["name"])),
            "extra": sorted([who(r) | {"below": kids.get(r["code"], 0)} for r in extra], key=lambda x: (-x["below"], x["function"], x["name"])),
            "settings": d["settings"], "ladder": d["ladder"]}


@router.get("/export")
def export(functions: str = Query(""), user=Depends(require_bm), db: Session = Depends(get_db)):
    if user.role != "admin" and not user.can_export:
        raise HTTPException(403, "Downloading is not allowed for this login")
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill
    d = bm.compute(db)
    fids = _scope(user, db, functions)
    fr = {f["id"]: f for f in d["functions"].values() if f["id"] in fids}
    rows = [(c, p) for c, p in d["people"].items() if p["fid"] in fids]
    E = _people(db, [c for c, _ in rows])
    L = bm.LEVEL_NAME
    tier = {"above": "Above max grade", "at": "At max grade", "room": "Opportunity to grow"}
    wb = Workbook()
    ws = wb.active
    ws.title = "By function"
    ws.append(["Function", "Type", "Permanent headcount", "Band", "Assessed", "Above max grade", "At max grade", "Opportunity to grow", "Teams members with permanent reports",
               "Permanent staff in an extra layer"])
    for f in sorted(fr.values(), key=lambda f: f["name"]):
        ws.append([f["name"], (f["type"] or "Not tagged").title(), f["permanent"], "50 or more" if f["band"] == "large" else "Under 50",
                   f["assessed"], f["above"], f["at"], f["room"], f["extra"], f["beyond"]])
    hd = ["Function", "Employee No", "Name", "Position", "Grade", "Level", "Level set by", "Layer", "Band", "Max grade", "Result", "Notches above max", "Extra layer"]
    an = wb.create_sheet("Above max grade")
    al = wb.create_sheet("Everyone assessed")
    ex = wb.create_sheet("Extra layers")
    an.append(hd)
    al.append(hd)
    ex.append(["Function", "Employee No", "Name", "Position", "Grade", "Level", "Level set by"])
    rows.sort(key=lambda x: (fr[x[1]["fid"]]["name"], x[1]["layer"] or 0, E[x[0]].name))
    for c, p in rows:
        e = E[c]
        if not fr[p["fid"]]["type"]:
            continue
        line = [fr[p["fid"]]["name"], c, e.name, e.position or "", e.grade or "", L.get(p["level"], ""), "Portal" if p["auto"] else "Admin", p["layer"] or (6 if p["level"] == "others" else ""), f"{p.get('min_name', '')} / {p.get('max_name', '')}" if p.get("tier") else "",
                p.get("max_name", ""), tier.get(p.get("tier"), "Not assessed (" + p.get("why", "") + ")"), p.get("gap") or "", "Yes" if p.get("beyond") else ""]
        al.append(line)
        if p.get("tier") == "above":
            an.append(line)
        if p.get("gate"):
            ex.append([fr[p["fid"]]["name"], c, e.name, e.position or "", e.grade or "", L.get(p["level"], ""), "Portal" if p["auto"] else "Admin"])
    st = wb.create_sheet("Benchmark")
    st.append(["Level", "Max grade, function under %d permanent" % d["settings"]["threshold"], "Max grade, %d permanent or more" % d["settings"]["threshold"]])
    for lv in bm.LEVELS:
        st.append([L[lv], d["ladder"].get(d["settings"]["small"][lv], ""), d["ladder"].get(d["settings"]["large"][lv], "")])
    for sh in wb.worksheets:
        for cell in sh[1]:
            cell.font, cell.fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="00796B")
        for col in sh.columns:
            sh.column_dimensions[col[0].column_letter].width = min(48, max(10, max(len(str(x.value or "")) for x in col) + 2))
        sh.freeze_panes = "A2"
    buf = io.BytesIO()
    wb.save(buf)
    buf.seek(0)
    return StreamingResponse(buf, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                             headers={"Content-Disposition": f'attachment; filename="grade_benchmark_{datetime.now():%Y%m%d}.xlsx"'})


# ---------------------------------------------------------------- admin
@router.get("/admin")
def admin_get(user=Depends(require_super), db: Session = Depends(get_db)):
    d = bm.compute(db)
    return {"functions": sorted([_fn_out(f, d["ladder"], d["settings"]) for f in d["functions"].values()], key=lambda f: f["name"]),
            "settings": d["settings"], "ladder": [{"rank": r, "name": n} for r, n in d["ladder"].items() if r >= 40],
            "levels": [{"k": k, "name": bm.LEVEL_NAME[k]} for k in bm.LEVELS], "check": bm.check(db)}


class TypeIn(BaseModel):
    type: Optional[str] = None
    band: Optional[str] = None   # "small" / "large" / "" (from the permanent headcount)


@router.put("/function/{fid}")
def set_type(fid: int, body: TypeIn, user=Depends(require_super), db: Session = Depends(get_db)):
    f = db.get(models.Function, fid)
    if not f:
        raise HTTPException(404, "Function not found")
    sent = body.model_dump(exclude_unset=True)
    if "type" in sent:
        t = (body.type or "").lower() or None
        if t and t not in bm.ORG_TYPES:
            raise HTTPException(400, "The type is Division, Department or Unit")
        f.org_type = t
        audit(db, user, "bm_function_type", f"{f.name}: {t or 'not tagged'}")
    if "band" in sent:
        b = (body.band or "").lower() or None
        if b and b not in ("small", "large"):
            raise HTTPException(400, "The band is under 50 or 50 or more")
        f.bm_band = b
        audit(db, user, "bm_function_band", f"{f.name}: {b or 'from headcount'}")
    db.commit()
    return {"ok": True}


class SettingsIn(BaseModel):
    threshold: Optional[int] = None
    size_words: Optional[bool] = None
    dc_permanent: Optional[bool] = None
    max_layers: Optional[int] = None
    small: Optional[Dict[str, int]] = None
    large: Optional[Dict[str, int]] = None


@router.put("/settings")
def put_settings(body: SettingsIn, user=Depends(require_super), db: Session = Depends(get_db)):
    s = bm.save_settings(db, body.model_dump(exclude_unset=True))
    audit(db, user, "bm_settings", str(s))
    db.commit()
    return s


class LevelIn(BaseModel):
    code: str
    level: Optional[str] = None
    below: Optional[str] = None   # what their direct reports are: "team", "others" or "" (by position)


def require_layer_edit(user=Depends(current_user)):
    """Setting a level: those who may change the benchmark, and logins given "Edit in Layer Panel" by an admin."""
    if user.username == SUPER or (user.role == "admin" and user.can_benchmark and user.can_bm_edit):
        return user
    if (user.role == "admin" or user.can_layers) and user.can_layer_edit:
        return user
    raise HTTPException(403, "This login cannot change levels.")


@router.get("/level/{code}")
def get_level(code: str, user=Depends(require_layer_edit), db: Session = Depends(get_db)):
    """One person's level (for the layer panel's edit mode)."""
    p = bm.compute(db)["people"].get(code)
    if not p:
        raise HTTPException(404, "Not in a tagged function.")
    return {"level": p["level"], "auto": p["auto"], "below": p.get("below")}


@router.put("/level")
def set_level(body: LevelIn, user=Depends(require_layer_edit), db: Session = Depends(get_db)):
    e = db.get(models.Employee, body.code)
    if not e:
        raise HTTPException(404, "Employee not found")
    sent = body.model_dump(exclude_unset=True)
    if "level" in sent:
        lv = (body.level or "").lower() or None
        if lv and lv not in bm.LEVELS + ["extra"]:
            raise HTTPException(400, "Unknown level")
        e.bm_level = lv
        audit(db, user, "bm_level", f"{e.code} {e.name}: {lv or 'from the reporting line'}")
    if "below" in sent:
        b = (body.below or "").lower() or None
        if b and b not in ("team", "others"):
            raise HTTPException(400, "Their team is Team Leader or Others")
        e.bm_below = b
        audit(db, user, "bm_below", f"{e.code} {e.name}: direct reports {b or 'by position'}")
    db.commit()
    return {"ok": True}


class FnTypeIn(BaseModel):
    type: Optional[str] = None


@router.put("/layer-function/{fid}")
def set_type_from_panel(fid: int, body: FnTypeIn, user=Depends(require_layer_edit), db: Session = Depends(get_db)):
    """Tag a function as Division, Department or Unit from the layer panel's edit mode."""
    f = db.get(models.Function, fid)
    if not f:
        raise HTTPException(404, "Function not found")
    t = (body.type or "").lower() or None
    if t and t not in bm.ORG_TYPES:
        raise HTTPException(400, "The type is Division, Department or Unit")
    f.org_type = t
    audit(db, user, "bm_function_type", f"{f.name}: {t or 'not tagged'} (layer panel)")
    db.commit()
    return {"ok": True}


@router.get("/check")
def check(user=Depends(require_super), db: Session = Depends(get_db)):
    return bm.check(db)


@router.get("/function/{fid}/people")
def function_people(fid: int, user=Depends(require_super), db: Session = Depends(get_db)):
    """Everyone in a function with their level, for the admin's Edit list."""
    d = bm.compute(db)
    rows = [(c, p) for c, p in d["people"].items() if p["fid"] == fid]
    E = _people(db, [c for c, _ in rows])
    nk: Dict[str, int] = {}
    for (m,) in db.query(models.Employee.manager_code).filter(models.Employee.resigned == False):  # noqa: E712
        nk[m] = nk.get(m, 0) + 1
    out = [{"code": c, "name": E[c].name, "position": E[c].position or "", "grade": E[c].grade or "", "level": p["level"], "auto": p["auto"],
            "layer": p["layer"], "reports": nk.get(c, 0), "tier": p.get("tier"), "max": p.get("max_name", ""), "below": p.get("below")}
           for c, p in rows]
    out.sort(key=lambda x: (x["layer"] or 9, x["name"]))
    return {"people": out}
