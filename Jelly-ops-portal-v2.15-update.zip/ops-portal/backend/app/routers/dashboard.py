"""Dashboard figures from the recorded activities: service and support, handling, automation and categories,
for the functions selected in the dashboard filter (limited to what the user may see)."""
from typing import Dict, List, Optional, Set

from fastapi import APIRouter, Depends, Query
from sqlalchemy import select
from sqlalchemy.orm import Session

from .. import models
from ..db import get_db
from ..logic import HANDLING, VOL_FILE, Calc, function_fields, missing_fields, shown_grade
from .catreview import NO_THEME, theme_list, theme_map, theme_of
from ..security import current_user as require_login_any, in_units, merge_units, require_dashboard, sees_everything, unit_scope, view_ids
from ..cache import cached_json

router = APIRouter(prefix="/api/dashboard")


def require_dashboard_or_hr(hr: bool = Query(False), user=Depends(require_login_any)):
    """The HR Dashboard's Activities section (hr=true): also for logins that have only the HR Dashboard."""
    if hr and (user.username == "admin" or user.can_chro):
        return user
    return require_dashboard(user)


def hr_scope_ids(user, db, functions: str) -> Set[int]:
    """The functions the HR Dashboard shows this login (Admin -> Users -> HR Dashboard shows)."""
    from .chro import scope_of
    sc = scope_of(user, db)
    allowed = {f.id for f in db.query(models.Function) if sc is None or f.name in sc or (f.hr_name or "") in sc}
    want = {int(x) for x in (functions or "").split(",") if x.strip().isdigit()}
    return (want & allowed) if want else allowed


def scope_ids(user, db, functions: str) -> Set[int]:
    allowed = {f.id for f in db.query(models.Function.id)} if sees_everything(user) else view_ids(user, db)
    want = {int(x) for x in (functions or "").split(",") if x.strip().isdigit()}
    return (want & allowed) if want else allowed


def load(db, fids: Set[int], include_flagged: bool, emp_type: str = "", role: str = "", units=None):
    """units: {function id: {unit names}} (the login's units and the unit filter), None = whole functions."""
    from ..logic import snapshot
    all_emps, all_items = snapshot(db)   # read once, shared until the data changes
    emps = {c: e for c, e in all_emps.items() if e.function_id in fids and not e.resigned and in_units(e, units)}
    if emp_type in ("FTE", "FTC"):
        emps = {k: e for k, e in emps.items() if e.emp_type == emp_type}
    if role in ("Service", "Support"):
        emps = {k: e for k, e in emps.items() if e.service_role == role}
    elif role == "none":
        emps = {k: e for k, e in emps.items() if not e.service_role}
    if not include_flagged:
        emps = {k: e for k, e in emps.items() if not e.exclude}
    items = [w for w in all_items if w.employee_code in emps]
    return emps, items


def shown_fields(db, fids: Set[int], items, fn_of: Dict[str, int]) -> List[str]:
    """Activity fields worth showing: filled in for at least one activity of a function where the field is
    not hidden. A field hidden in a function is ignored for that function's activities, so a field hidden
    everywhere it is used never shows, even when some functions still have older values in it."""
    cfg = {f: function_fields(db, f) for f in (fids or set())}
    val = {"handling": lambda w: w.handling, "automation": lambda w: w.automation, "category": lambda w: (w.category or "").strip(),
           "process": lambda w: (w.process or "").strip(), "product": lambda w: (w.product or "").strip(), "channel": lambda w: (w.channel or "").strip(),
           "volume": lambda w: w.volume is not None, "description": lambda w: (w.description or "").strip(), "frequency": lambda w: True,
           "minutes": lambda w: w.minutes is not None, "peak": lambda w: w.peak_som is not None or w.peak_eom is not None}
    out = []
    for f, get in val.items():
        if any(cfg.get(fn_of.get(w.employee_code), {}).get(f) != "hidden" and get(w) for w in items):
            out.append(f)
    return out


def work_summary(db: Session, fids: Set[int], include_flagged: bool = True, emp_type: str = "", role: str = "", units=None) -> dict:
    c = Calc(db)
    emps, items = load(db, fids, include_flagged, emp_type, role, units)
    fnames = {f.id: f.name for f in db.query(models.Function)}
    by_emp: Dict[str, List[models.WorkItem]] = {}
    for w in items:
        by_emp.setdefault(w.employee_code, []).append(w)
    h = lambda ws: sum(c.daily_hours(w) for w in ws)
    total_h = h(items)

    def block(ws):
        hh = h(ws)
        return {"activities": len(ws), "hours": round(hh, 2), "fte": round(hh / c.ph, 2) if c.ph else 0,
                "staff": len({w.employee_code for w in ws})}

    # service or support is the employee's type of work (set in data capture step 1)
    role = {code: (e.service_role or "") for code, e in emps.items()}
    types = {t: block([w for w in items if role[w.employee_code] == t]) for t in ("Service", "Support")}
    for t in ("Service", "Support"):
        types[t]["staff_classified"] = sum(1 for v in role.values() if v == t)
    handling = [dict(name=n, **block([w for w in items if w.handling == n])) for n in HANDLING]
    auto = [w for w in items if w.automation == "Yes"]
    auto_by_handling = [dict(name=n, **block([w for w in auto if w.handling == n])) for n in HANDLING]

    cats: Dict[str, List[models.WorkItem]] = {}
    for w in items:
        cats.setdefault((w.category or "").strip() or "Not categorised", []).append(w)
    categories = []
    for name, ws in cats.items():
        b = block(ws)
        b.update({"name": name,
                  "processes": len({(w.process or "").strip().lower() for w in ws if (w.process or "").strip()}),
                  "automation": sum(1 for w in ws if w.automation == "Yes"),
                  "manual": sum(1 for w in ws if HANDLING and w.handling == HANDLING[0])})
        categories.append(b)
    categories.sort(key=lambda x: (x["name"] == "Not categorised", -x["staff"], -x["hours"], x["name"].lower()))
    vday = lambda w: (w.volume or 0) / (c.days.get(w.frequency or "Daily", 1.0) or 1.0)
    # activity themes: each category belongs to one theme (set by the admin); the rest are "No Theme"
    tm = theme_map(db)
    for x in categories:
        x["theme"] = theme_of(x["name"], tm) if x["name"] != "Not categorised" else ""
    th_items: Dict[str, List[models.WorkItem]] = {}
    for w in items:
        if (w.category or "").strip():
            th_items.setdefault(theme_of(w.category, tm) or NO_THEME, []).append(w)
    order = theme_list(db) + [NO_THEME]
    themes = []
    for t in order:
        ws = th_items.get(t)
        if not ws:
            continue
        b = block(ws)
        cs: Dict[str, List[models.WorkItem]] = {}
        for w in ws:
            cs.setdefault(" ".join(w.category.split()), []).append(w)
        tstaff = {w.employee_code for w in ws}
        b.update({"functions": len({emps[c].function_id for c in tstaff}), "fte_staff": sum(1 for c in tstaff if emps[c].emp_type == "FTE"),
                  "ftc_staff": sum(1 for c in tstaff if emps[c].emp_type != "FTE"),
                  "per_day": round(sum(vday(w) for w in ws if w.volume and w.volume > 0), 1),
                  "file_per_day": round(sum(vday(w) for w in ws if w.volume and w.volume > 0 and w.volume_type == VOL_FILE), 1)})
        b.update({"name": t, "categories": sorted([{"name": k, "activities": len(v), "staff": len({w.employee_code for w in v})} for k, v in cs.items()],
                                                  key=lambda r: (-r["staff"], -r["activities"], r["name"].lower()))})
        themes.append(b)
    themes.sort(key=lambda x: (x["name"] == NO_THEME, -x["staff"], -x["activities"]))
    # volume per day (each activity's average volume divided by the working days of its frequency)
    vday = lambda w: (w.volume or 0) / (c.days.get(w.frequency or "Daily", 1.0) or 1.0)
    vit = [w for w in items if w.volume and w.volume > 0]

    def vgroup(key, label_extra=None):
        g: Dict[str, List[models.WorkItem]] = {}
        for w in vit:
            k = key(w)
            if k:
                g.setdefault(k, []).append(w)
        out = []
        for k, ws in g.items():
            r = {"name": k, "per_day": round(sum(vday(w) for w in ws), 1), "activities": len(ws), "staff": len({w.employee_code for w in ws}),
                 "file_per_day": round(sum(vday(w) for w in ws if w.volume_type == VOL_FILE), 1)}
            if label_extra:
                r.update(label_extra(ws))
            out.append(r)
        return sorted(out, key=lambda r: -r["per_day"])
    fit = [w for w in vit if w.volume_type == VOL_FILE]
    volume = {"activities": len(vit), "per_day": round(sum(vday(w) for w in vit), 1),
              "file_activities": len(fit), "file_per_day": round(sum(vday(w) for w in fit), 1),
              "by_function": vgroup(lambda w: fnames.get(emps[w.employee_code].function_id, ""), lambda ws: {"id": emps[ws[0].employee_code].function_id}),
              "by_unit": vgroup(lambda w: emps[w.employee_code].unit_name or "", lambda ws: {"function": fnames.get(emps[ws[0].employee_code].function_id, "")}),
              "by_category": vgroup(lambda w: " ".join((w.category or "").split()) or "Not categorised"),
              "by_theme": vgroup(lambda w: (theme_of(w.category, tm) or NO_THEME) if (w.category or "").strip() else "")}

    by_function = []
    fn_of = {code: e.function_id for code, e in emps.items()}
    ws_of: Dict[int, list] = {}
    for w in items:   # each function's activities, sorted out once
        ws_of.setdefault(fn_of[w.employee_code], []).append(w)
    es_of: Dict[int, list] = {}
    for e in emps.values():
        es_of.setdefault(e.function_id, []).append(e)
    for fid in sorted(fids, key=lambda i: fnames.get(i, "").lower()):
        ws = ws_of.get(fid, [])
        fe = es_of.get(fid, [])
        hc = len(fe)
        hh = h(ws)
        by_function.append({"id": fid, "name": fnames.get(fid, ""), "headcount": hc,
                            "service_staff": sum(1 for e in fe if e.service_role == "Service"),
                            "support_staff": sum(1 for e in fe if e.service_role == "Support"),
                            "service_activities": sum(1 for w in ws if role[w.employee_code] == "Service"),
                            "support_activities": sum(1 for w in ws if role[w.employee_code] == "Support"),
                            "automation_activities": sum(1 for w in ws if w.automation == "Yes"),
                            "staff_with_work": len({w.employee_code for w in ws}), "activities": len(ws),
                            "hours": round(hh, 2), "fte": round(hh / c.ph, 2) if c.ph else 0,
                            "service_hours": round(h([w for w in ws if role[w.employee_code] == "Service"]), 2),
                            "support_hours": round(h([w for w in ws if role[w.employee_code] == "Support"]), 2),
                            "automation_hours": round(h([w for w in ws if w.automation == "Yes"]), 2),
                            "handling": {n: sum(1 for w in ws if w.handling == n) for n in HANDLING}})

    peak_som = sum(c.peak_hours(w, "som") for w in items)
    peak_eom = sum(c.peak_hours(w, "eom") for w in items)
    with_work = len(by_emp)
    return {
        "settings": c.settings(), "fields": shown_fields(db, fids, items, {k: e.function_id for k, e in emps.items()}),
        "units": any(e.unit_name for e in emps.values()),
        "headcount": len(emps), "staff_with_work": with_work,
        "coverage": round(with_work / len(emps) * 100, 1) if emps else 0,
        "activities": len(items), "incomplete": sum(1 for w in items if missing_fields(w, emps[w.employee_code].function_id)),
        "hours": round(total_h, 2), "fte": round(total_h / c.ph, 2) if c.ph else 0,
        "peak_som_hours": round(peak_som, 2), "peak_eom_hours": round(peak_eom, 2),
        "peak_som_fte": round(peak_som / c.ph, 2) if c.ph else 0, "peak_eom_fte": round(peak_eom / c.ph, 2) if c.ph else 0,
        "types": types, "unclassified": sum(1 for v in role.values() if not v), "handling": handling,
        "frequency": sorted([dict(name=f, **block([w for w in items if (w.frequency or "") == f])) for f in {w.frequency or "" for w in items} if f],
                            key=lambda x: (-x["activities"], x["name"])),
        "automation": dict(block(auto), by_handling=auto_by_handling),
        "categories": categories, "by_function": by_function, "themes": themes, "volume": volume,
    }


@router.get("/work")
@cached_json
def work(functions: str = Query(""), include_flagged: bool = Query(True), emp_type: str = Query(""), role: str = Query(""),
         units: List[str] = Query([]), user=Depends(require_dashboard), db: Session = Depends(get_db)):
    fids = scope_ids(user, db, functions)
    return work_summary(db, fids, include_flagged, emp_type, role, merge_units(unit_scope(user), units, fids))


@router.get("/activities")
@cached_json
def activities(functions: str = Query(""), category: Optional[str] = None, service_type: Optional[str] = None,
               handling: Optional[str] = None, automation: Optional[str] = None, code: Optional[str] = None, frequency: Optional[str] = None, include_flagged: bool = Query(True),
               emp_type: str = Query(""), role: str = Query(""), units: List[str] = Query([]), theme: Optional[str] = None,
               volume: bool = Query(False), novolume: bool = Query(False), groups: bool = Query(False), q: str = Query(""), limit: int = Query(1000),
               vtype: str = Query(""), hr: bool = Query(False), user=Depends(require_dashboard_or_hr), db: Session = Depends(get_db)):
    """The activities behind a dashboard figure, for the drill-down. novolume: only activities without a volume.
    groups: also the activities grouped by theme and category (all of them, not only the rows returned)."""
    c = Calc(db)
    fids = hr_scope_ids(user, db, functions) if hr else scope_ids(user, db, functions)
    emps, items = load(db, fids, include_flagged, emp_type, role, None if hr else merge_units(unit_scope(user), units, fids))
    shown = shown_fields(db, fids, items, {k: e.function_id for k, e in emps.items()})
    fnames = {f.id: f.name for f in db.query(models.Function)}
    if code:
        items = [w for w in items if w.employee_code == code]
    if category is not None:
        items = [w for w in items if (" ".join((w.category or "").split()) or "Not categorised") == " ".join(category.split())]
    if service_type:
        items = [w for w in items if (emps[w.employee_code].service_role or "") == service_type]
    if handling:
        items = [w for w in items if w.handling == handling]
    if automation:
        items = [w for w in items if w.automation == automation]
    if frequency:
        items = [w for w in items if (w.frequency or "") == frequency]
    if theme is not None:
        tm = theme_map(db)
        items = [w for w in items if (w.category or "").strip() and (theme_of(w.category, tm) or NO_THEME) == theme]
    if volume:
        items = [w for w in items if w.volume and w.volume > 0]
    if novolume:
        items = [w for w in items if not (w.volume and w.volume > 0)]
    if vtype in ("file", "txn"):   # file based or activity based volume
        items = [w for w in items if w.volume and w.volume > 0 and (w.volume_type == VOL_FILE) == (vtype == "file")]
    tm2 = theme_map(db)
    cat_of = lambda w: " ".join((w.category or "").split()) or "Not categorised"
    th_of = lambda w: (theme_of(w.category, tm2) or NO_THEME) if (w.category or "").strip() else NO_THEME
    words = [x for x in (q or "").lower().split() if x]
    if words:   # search: every word must appear in the employee, the activity text, its category or its theme
        def text(w):
            e = emps[w.employee_code]
            return " ".join([e.name or "", e.code or "", e.position or "", e.unit_name or "", e.region or "", fnames.get(e.function_id, ""),
                             w.description or "", w.process or "", w.product or "", w.channel or "", w.category or "", th_of(w)]).lower()
        items = [w for w in items if all(x in text(w) for x in words)]
    grouped = None
    if groups:
        tg: Dict[str, Dict[str, list]] = {}
        for w in items:
            tg.setdefault(th_of(w), {}).setdefault(cat_of(w), []).append(w)
        vday = lambda w: (w.volume or 0) / (c.days.get(w.frequency or "Daily", 1.0) or 1.0) if w.volume and w.volume > 0 else 0
        def cat_rows(d):
            return sorted([{"name": k, "activities": len(v), "staff": len({w.employee_code for w in v}), "functions": len({emps[w.employee_code].function_id for w in v}),
                            "fte_staff": len({w.employee_code for w in v if emps[w.employee_code].emp_type == "FTE"}), "ftc_staff": len({w.employee_code for w in v if emps[w.employee_code].emp_type != "FTE"}),
                            "per_day": round(sum(vday(w) for w in v), 1), "file_per_day": round(sum(vday(w) for w in v if w.volume_type == VOL_FILE), 1)} for k, v in d.items()],
                          key=lambda r: (r["name"] == "Not categorised", -r["activities"], r["name"].lower()))
        th_rows = []
        for t, d in tg.items():
            allw = [w for v in d.values() for w in v]
            ts = {w.employee_code for w in allw}
            th_rows.append({"name": t, "activities": len(allw), "staff": len(ts), "functions": len({emps[x].function_id for x in ts}),
                            "fte_staff": sum(1 for x in ts if emps[x].emp_type == "FTE"), "ftc_staff": sum(1 for x in ts if emps[x].emp_type != "FTE"),
                            "per_day": round(sum(vday(w) for w in allw), 1), "file_per_day": round(sum(vday(w) for w in allw if w.volume_type == VOL_FILE), 1),
                            "categories": cat_rows(d)})
        th_rows.sort(key=lambda r: (r["name"] == NO_THEME, -r["activities"], r["name"].lower()))
        allc: Dict[str, list] = {}
        for w in items:
            allc.setdefault(cat_of(w), []).append(w)
        fc: Dict[int, int] = {}
        uc: Dict[str, int] = {}
        for w in items:
            e = emps[w.employee_code]
            fc[e.function_id] = fc.get(e.function_id, 0) + 1
            if e.unit_name:
                uc[e.unit_name] = uc.get(e.unit_name, 0) + 1
        grouped = {"themes": th_rows, "categories": cat_rows(allc), "staff": len({w.employee_code for w in items}),
                   "functions": sorted([{"id": k, "name": fnames.get(k, ""), "activities": v} for k, v in fc.items() if k], key=lambda r: r["name"]),
                   "units": sorted([{"name": k, "activities": v} for k, v in uc.items()], key=lambda r: r["name"].lower()),
                   "per_day": round(sum(vday(w) for w in items), 1), "file_per_day": round(sum(vday(w) for w in items if w.volume_type == VOL_FILE), 1)}
    items.sort(key=lambda w: -c.daily_hours(w))
    out = []
    for w in items[:max(0, min(limit, 1000))]:   # limit=0: only the totals and the groups
        e = emps[w.employee_code]
        out.append({"id": w.id, "code": e.code, "name": e.name, "grade": shown_grade(e), "emp_type": e.emp_type, "function_id": e.function_id,
                    "function": fnames.get(e.function_id, ""), "region": e.region or "",
                    "unit": e.unit_name or w.unit or "", "product": w.product or "", "process": w.process or "", "channel": w.channel or "",
                    "category": w.category or "", "theme": th_of(w) if (w.category or "").strip() else "", "description": w.description or "", "service_type": e.service_role or "",
                    "frequency": w.frequency, "minutes": w.minutes, "handling": w.handling or "",
                    "volume": round(w.volume, 2) if w.volume is not None else None, "volume_type": w.volume_type or "",
                    "per_day": round((w.volume or 0) / (c.days.get(w.frequency or "Daily", 1.0) or 1.0), 1) if w.volume else None,
                    "automation": w.automation or "", "total_minutes": round(c.total_minutes(w), 1),
                    "daily_hours": round(c.daily_hours(w), 3)})
    return {"total": len(items), "rows": out, "fields": shown, "groups": grouped}


@router.get("/employees")
@cached_json
def top_employees(functions: str = Query(""), include_flagged: bool = Query(True), limit: int = Query(300),
                  emp_type: str = Query(""), role: str = Query(""), units: List[str] = Query([]), user=Depends(require_dashboard), db: Session = Depends(get_db)):
    """Employees ranked by the number of activities they perform, with their categories."""
    fids = scope_ids(user, db, functions)
    emps, items = load(db, fids, include_flagged, emp_type, role, merge_units(unit_scope(user), units, fids))
    fnames = {f.id: f.name for f in db.query(models.Function)}
    by: Dict[str, List[models.WorkItem]] = {}
    for w in items:
        by.setdefault(w.employee_code, []).append(w)
    rows = []
    for code, ws in by.items():
        e = emps[code]
        cats = {}
        for w in ws:
            k = (w.category or "").strip() or "Not categorised"
            cats[k] = cats.get(k, 0) + 1
        rows.append({"code": code, "name": e.name, "grade": shown_grade(e), "grade_rank": e.grade_rank or 0, "emp_type": e.emp_type,
                     "position": e.position or "", "function": fnames.get(e.function_id, ""), "unit": e.unit_name or "",
                     "region": e.region or "", "activities": len(ws), "categories": len(cats),
                     "automation": sum(1 for w in ws if w.automation == "Yes"), "service_type": e.service_role or ""})
    rows.sort(key=lambda r: (-r["activities"], -r["categories"], -r["grade_rank"], r["name"]))
    return {"total": len(rows), "rows": rows[:max(1, min(limit, 2000))]}
