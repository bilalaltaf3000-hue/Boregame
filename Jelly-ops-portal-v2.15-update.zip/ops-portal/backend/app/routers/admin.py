import csv
import io
import re
import secrets
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import StreamingResponse
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from pydantic import BaseModel
from sqlalchemy import func
from sqlalchemy.orm import Session

from .. import models
from ..db import get_db
from ..importer import import_workbook
from ..security import (audit, get_setting, hash_password, require_admin, require_dashboard,
                        set_setting)

router = APIRouter(prefix="/api/admin")


# ---------- import ----------
@router.post("/import")
async def import_sheet(file: UploadFile = File(...), user=Depends(require_admin), db: Session = Depends(get_db)):
    if not file.filename.lower().endswith((".xlsx", ".xlsm")):
        raise HTTPException(400, "Please upload the employee sheet as .xlsx")
    content = await file.read()
    try:
        report = import_workbook(db, content, user.username)
    except ValueError as e:
        db.rollback()
        raise HTTPException(400, str(e))
    from ..logic import reassign_resigned_teams
    db.flush()
    report["resigned_teams_moved"] = reassign_resigned_teams(db)   # people the sheet puts under a resigned manager
    audit(db, user, "import", f"{file.filename}: {report['rows']} rows")
    db.commit()
    return report


@router.get("/import-report")
def import_report(user=Depends(require_admin), db: Session = Depends(get_db)):
    return get_setting(db, "last_import") or {}


# ---------- settings ----------
class SettingsIn(BaseModel):
    productive_hours: Optional[float] = None
    root_code: Optional[str] = None
    senior_rank: Optional[int] = None
    large_team: Optional[int] = None
    working_days_week: Optional[float] = None
    working_days_month: Optional[float] = None
    group_label: Optional[str] = None
    capture_fields: Optional[dict] = None
    show_time: Optional[bool] = None
    show_top_grade: Optional[bool] = None
    hide_resigned: Optional[bool] = None
    show_themes: Optional[bool] = None
    show_categories: Optional[bool] = None
    labels: Optional[dict] = None


SETTING_KEYS = ("productive_hours", "root_code", "senior_rank", "large_team", "working_days_week", "working_days_month", "group_label", "capture_fields", "show_time", "show_top_grade", "hide_resigned", "show_themes", "show_categories", "labels")


@router.get("/settings")
def get_settings(user=Depends(require_admin), db: Session = Depends(get_db)):
    from ..logic import field_config
    out = {k: get_setting(db, k) for k in SETTING_KEYS}
    out["capture_fields"] = field_config(db)
    out["show_top_grade"] = bool(out.get("show_top_grade"))
    out["hide_resigned"] = out.get("hide_resigned") is not False   # on unless the admin turned it off
    out["show_themes"] = bool(out.get("show_themes"))              # off until the admin has set the themes up
    out["show_categories"] = out.get("show_categories") is not False   # on unless the admin turned it off
    out["labels"] = out.get("labels") or {}
    return out


@router.put("/settings")
def put_settings(body: SettingsIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    vals = body.model_dump(exclude_none=True)
    if "productive_hours" in vals and not (1 <= vals["productive_hours"] <= 16):
        raise HTTPException(400, "Productive hours per day must be between 1 and 16.")
    if "working_days_week" in vals and not (1 <= vals["working_days_week"] <= 7):
        raise HTTPException(400, "Working days per week must be between 1 and 7.")
    if "working_days_month" in vals and not (1 <= vals["working_days_month"] <= 31):
        raise HTTPException(400, "Working days per month must be between 1 and 31.")
    if "group_label" in vals:
        vals["group_label"] = vals["group_label"].strip()[:30] or "COSO"
    if "root_code" in vals:
        vals["root_code"] = vals["root_code"].strip()
        if vals["root_code"] and not db.get(models.Employee, vals["root_code"]):
            raise HTTPException(400, "No employee has that code.")
    if "capture_fields" in vals:
        from ..logic import FIELD_DEFAULTS
        vals["capture_fields"] = {k: v for k, v in vals["capture_fields"].items() if k in FIELD_DEFAULTS and v in ("required", "optional", "hidden")}
    if "labels" in vals:   # the admin's names for dashboard labels; a blank one goes back to the default
        vals["labels"] = {str(k)[:60]: " ".join(str(v).split())[:(400 if str(k).startswith("sum.") else 80)] for k, v in vals["labels"].items()
                          if isinstance(k, str) and v is not None and str(v).strip()}
    for k, v in vals.items():
        set_setting(db, k, v)
    if "capture_fields" in vals or "show_top_grade" in vals or "root_code" in vals or "hide_resigned" in vals or "labels" in vals:
        from ..logic import load_required
        db.flush()
        load_required(db)
    audit(db, user, "settings", str(body.model_dump(exclude_none=True)))
    db.commit()
    return get_settings(user, db)


# ---------- users ----------
class UserIn(BaseModel):
    username: str
    full_name: str = ""
    is_admin: bool = False
    input_functions: List[int] = []
    view_mode: str = "none"
    view_functions: List[int] = []
    view_units: List[str] = []
    can_export: bool = False
    can_decisions: bool = False
    can_emp_changes: bool = False
    can_role_overlap: bool = False
    can_benchmark: bool = False
    can_summary: bool = False
    can_bm_edit: bool = False
    can_layers: bool = False
    can_layer_edit: bool = False
    can_bm_view: bool = False
    can_chro: bool = False
    can_hr_bm: bool = False
    chro_mode: str = "view"
    chro_functions: List[int] = []
    password: Optional[str] = None


class UserEdit(BaseModel):
    full_name: Optional[str] = None
    is_admin: Optional[bool] = None
    input_functions: Optional[List[int]] = None
    view_mode: Optional[str] = None
    view_functions: Optional[List[int]] = None
    view_units: Optional[List[str]] = None
    can_export: Optional[bool] = None
    can_decisions: Optional[bool] = None
    can_emp_changes: Optional[bool] = None
    can_role_overlap: Optional[bool] = None
    can_benchmark: Optional[bool] = None
    can_summary: Optional[bool] = None
    can_bm_edit: Optional[bool] = None
    can_layers: Optional[bool] = None
    can_layer_edit: Optional[bool] = None
    can_bm_view: Optional[bool] = None
    can_chro: Optional[bool] = None
    can_hr_bm: Optional[bool] = None
    chro_mode: Optional[str] = None
    chro_functions: Optional[List[int]] = None
    active: Optional[bool] = None
    reset_password: Optional[bool] = None


VIEW_MODES = ("none", "input", "selected", "all")
CHRO_MODES = ("view", "all", "selected")


def _uout(u, fnames):
    return {"id": u.id, "username": u.username, "full_name": u.full_name, "is_admin": u.role == "admin",
            "input_functions": [i for i in (u.input_functions or []) if i in fnames],
            "view_mode": u.view_mode or "none", "view_functions": [i for i in (u.view_functions or []) if i in fnames],
            "view_units": list(u.view_units or []),
            "can_export": bool(u.can_export), "can_decisions": bool(u.can_decisions), "can_emp_changes": bool(u.can_emp_changes), "can_role_overlap": bool(u.can_role_overlap), "can_benchmark": u.username == "admin" or bool(u.can_benchmark), "can_summary": bool(u.can_summary), "can_bm_edit": u.username == "admin" or bool(u.can_bm_edit), "can_layers": bool(u.can_layers), "can_layer_edit": bool(u.can_layer_edit), "can_bm_view": u.username == "admin" or bool(u.can_bm_view), "can_chro": u.username == "admin" or bool(u.can_chro), "can_hr_bm": u.username == "admin" or bool(u.can_hr_bm),
            "chro_mode": u.chro_mode or "view", "chro_functions": [i for i in (u.chro_functions or []) if i in fnames], "active": u.active,
            "created_at": u.created_at.isoformat(timespec="minutes") if u.created_at else ""}


def _clean_units(units, fids):
    """Keep "function id|unit" entries of the login's dashboard functions."""
    out = []
    for x in units or []:
        f, _, un = str(x).partition("|")
        if f.isdigit() and int(f) in set(fids or []) and un.strip():
            out.append(f"{int(f)}|{un.strip()}")
    return sorted(set(out))


@router.get("/function-units")
def function_units(user=Depends(require_admin), db: Session = Depends(get_db)):
    """The units used in each function (from step 1 of data capture), for unit logins."""
    out = {}
    for fid, un in db.query(models.Employee.function_id, models.Employee.unit_name).distinct():
        if fid and un and un.strip():
            out.setdefault(fid, set()).add(un.strip())
    return {str(k): sorted(v) for k, v in out.items()}


def _clean_ids(db, ids):
    valid = {f.id for f in db.query(models.Function.id)}
    return sorted({int(i) for i in ids if int(i) in valid})


@router.get("/users")
def users(user=Depends(require_admin), db: Session = Depends(get_db)):
    fnames = {f.id: f.name for f in db.query(models.Function)}
    return [_uout(u, fnames) for u in db.query(models.User).order_by(models.User.role, models.User.username)]


@router.post("/users")
def add_user(body: UserIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    un = body.username.strip().lower()
    if not re.match(r"^[a-z0-9._-]{3,60}$", un):
        raise HTTPException(400, "Username: 3-60 characters, letters, numbers, dot, dash or underscore.")
    if db.query(models.User).filter(models.User.username == un).first():
        raise HTTPException(409, "Username already exists.")
    if body.view_mode not in VIEW_MODES:
        raise HTTPException(400, "Unknown dashboard setting.")
    if not body.is_admin and not body.input_functions and body.view_mode in ("none", "input") and not body.can_decisions and not body.can_emp_changes and not body.can_role_overlap and not body.can_chro:
        raise HTTPException(400, "Give this user input rights for a function, dashboard rights, or both.")
    pw = body.password or secrets.token_urlsafe(8)
    db.add(models.User(username=un, full_name=body.full_name, role="admin" if body.is_admin else "user",
                       input_functions=_clean_ids(db, body.input_functions), view_mode=body.view_mode,
                       view_functions=_clean_ids(db, body.view_functions),
                       view_units=_clean_units(body.view_units, _clean_ids(db, body.view_functions)) if body.view_mode == "selected" else [],
                       can_export=body.can_export or body.is_admin, can_decisions=body.can_decisions, can_emp_changes=body.can_emp_changes, can_role_overlap=body.can_role_overlap,
                       can_benchmark=bool(body.can_benchmark) and user.username == "admin", can_summary=body.can_summary,
                       can_bm_edit=bool(body.can_bm_edit) and user.username == "admin", can_layers=body.can_layers, can_layer_edit=body.can_layer_edit, can_bm_view=body.can_bm_view, can_chro=bool(body.can_chro), can_hr_bm=bool(body.can_hr_bm),
                       chro_mode=body.chro_mode if body.chro_mode in CHRO_MODES else "view", chro_functions=_clean_ids(db, body.chro_functions),
                       password_hash=hash_password(pw)))
    audit(db, user, "user_add", f"{un}")
    db.commit()
    return {"username": un, "password": pw}


@router.patch("/users/{uid}")
def edit_user(uid: int, body: UserEdit, user=Depends(require_admin), db: Session = Depends(get_db)):
    u = db.get(models.User, uid)
    if not u:
        raise HTTPException(404, "User not found.")
    out = {}
    if body.full_name is not None:
        u.full_name = body.full_name
    if body.is_admin is not None:
        if u.id == user.id and not body.is_admin:
            raise HTTPException(400, "You cannot remove your own admin rights.")
        u.role = "admin" if body.is_admin else "user"
    if body.input_functions is not None:
        u.input_functions = _clean_ids(db, body.input_functions)
    if body.view_mode is not None:
        if body.view_mode not in VIEW_MODES:
            raise HTTPException(400, "Unknown dashboard setting.")
        u.view_mode = body.view_mode
    if body.view_functions is not None:
        u.view_functions = _clean_ids(db, body.view_functions)
    if body.view_units is not None or body.view_functions is not None:
        u.view_units = _clean_units(body.view_units if body.view_units is not None else (u.view_units or []), u.view_functions or [])
    if body.can_export is not None:
        u.can_export = body.can_export
    if body.can_decisions is not None:
        u.can_decisions = body.can_decisions
    if body.can_emp_changes is not None:
        u.can_emp_changes = body.can_emp_changes
    if body.can_role_overlap is not None:
        u.can_role_overlap = body.can_role_overlap
    if body.can_summary is not None:
        u.can_summary = body.can_summary
    if body.can_layers is not None:
        u.can_layers = body.can_layers
    if body.can_layer_edit is not None:
        u.can_layer_edit = body.can_layer_edit
    if body.can_bm_view is not None:
        u.can_bm_view = body.can_bm_view
    if body.can_chro is not None:   # any administrator can give the HR dashboard
        u.can_chro = body.can_chro
    if body.can_hr_bm is not None:
        u.can_hr_bm = body.can_hr_bm
    if body.chro_mode is not None:   # which functions the HR Dashboard shows this login
        if body.chro_mode not in CHRO_MODES:
            raise HTTPException(400, "Unknown HR Dashboard setting.")
        u.chro_mode = body.chro_mode
    if body.chro_functions is not None:
        u.chro_functions = _clean_ids(db, body.chro_functions)
    if body.can_benchmark is not None and user.username == "admin":   # only the "admin" login gives or takes the grade benchmark
        u.can_benchmark = body.can_benchmark
    if body.can_bm_edit is not None and user.username == "admin":   # only the "admin" login lets others change the benchmark
        u.can_bm_edit = body.can_bm_edit
    if body.active is not None:
        if u.id == user.id and not body.active:
            raise HTTPException(400, "You cannot deactivate your own account.")
        u.active = body.active
    if body.reset_password:
        pw = secrets.token_urlsafe(8)
        u.password_hash = hash_password(pw)
        out["password"] = pw
    audit(db, user, "user_edit", u.username)
    db.commit()
    return out


@router.post("/users/bulk-poc")
def bulk_poc(user=Depends(require_admin), db: Session = Depends(get_db)):
    """Create one input login per function that has none yet (dashboards for their own function). CSV of credentials."""
    buf = io.StringIO()
    w = csv.writer(buf)
    w.writerow(["Function", "Username", "Password"])
    covered = set()
    for u in db.query(models.User).filter(models.User.role != "admin"):
        covered |= set(u.input_functions or [])
    for f in db.query(models.Function).order_by(models.Function.name):
        if f.id in covered:
            continue
        base = "poc." + re.sub(r"[^a-z0-9]+", "", f.name.lower())[:30]
        un, i = base, 2
        while db.query(models.User).filter(models.User.username == un).first():
            un, i = f"{base}{i}", i + 1
        pw = secrets.token_urlsafe(8)
        db.add(models.User(username=un, full_name=f"{f.name} POC", role="user", input_functions=[f.id], view_mode="input",
                           view_functions=[], can_export=False, password_hash=hash_password(pw)))
        w.writerow([f.name, un, pw])
    audit(db, user, "bulk_poc")
    db.commit()
    return StreamingResponse(io.BytesIO(buf.getvalue().encode("utf-8-sig")), media_type="text/csv",
                             headers={"Content-Disposition": "attachment; filename=poc_logins.csv"})


# ---------- lookups ----------
class NameIn(BaseModel):
    name: str


@router.post("/categories")
def add_category(body: NameIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    n = body.name.strip()
    if n and not db.query(models.Category).filter(models.Category.name == n).first():
        db.add(models.Category(name=n, sort=99))
        db.commit()
    return {"ok": True}


@router.delete("/categories/{name}")
def del_category(name: str, user=Depends(require_admin), db: Session = Depends(get_db)):
    # standard categories are suggestions only; activities keep their text when one is removed
    db.query(models.Category).filter(models.Category.name == name).delete()
    db.commit()
    return {"ok": True}


# ---------- nature of work (the options for each activity, and the heading) ----------
class NatureIn(BaseModel):
    name: Optional[str] = None
    new_name: Optional[str] = None
    move_to: Optional[str] = None
    label: Optional[str] = None


def _nature_state(db):
    from ..logic import HANDLING, nature_label
    counts = dict(db.query(models.WorkItem.handling, func.count(models.WorkItem.id)).group_by(models.WorkItem.handling).all())
    return {"label": nature_label(), "options": [{"name": n, "activities": counts.get(n, 0)} for n in HANDLING],
            "not_recorded": counts.get("", 0) + counts.get(None, 0)}


def _nature_remember(db, label=None, alias=None):
    """Keep earlier headings and option names, so that templates downloaded before a rename still import."""
    h = get_setting(db, "nature_history") or {}
    labels, aliases = list(h.get("labels") or []), dict(h.get("aliases") or {})
    if label and label.lower() not in [x.lower() for x in labels]:
        labels.append(label)
    if alias:
        old, new = alias
        aliases = {k: (new if v == old else v) for k, v in aliases.items()}
        if new:
            aliases[old.lower()] = new
        else:
            aliases.pop(old.lower(), None)
        aliases.pop(new.lower(), None) if new else None
    set_setting(db, "nature_history", {"labels": labels, "aliases": aliases})


def _nature_save(db, opts=None, label=None):
    from ..logic import load_required
    if opts is not None:
        set_setting(db, "nature_options", opts)
    if label is not None:
        set_setting(db, "nature_label", label)
    db.commit()
    load_required(db)


@router.get("/nature")
def nature_get(user=Depends(require_admin), db: Session = Depends(get_db)):
    return _nature_state(db)


@router.post("/nature")
def nature_add(body: NatureIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    from ..logic import HANDLING
    n = " ".join((body.name or "").split())[:60]
    if not n:
        raise HTTPException(400, "Type the name of the option.")
    if n.lower() in [x.lower() for x in HANDLING]:
        raise HTTPException(409, "This option already exists.")
    audit(db, user, "nature_add", n)
    _nature_save(db, opts=list(HANDLING) + [n])
    return _nature_state(db)


@router.patch("/nature")
def nature_rename(body: NatureIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    """Rename an option (every activity using it follows) or the heading."""
    from ..logic import HANDLING
    if body.label is not None:
        lab = " ".join(body.label.split())[:40]
        if not lab:
            raise HTTPException(400, "The heading cannot be empty.")
        from ..logic import nature_label
        audit(db, user, "nature_label", lab)
        _nature_remember(db, label=nature_label())
        _nature_save(db, label=lab)
        return _nature_state(db)
    old, new = (body.name or "").strip(), " ".join((body.new_name or "").split())[:60]
    if old not in HANDLING:
        raise HTTPException(404, "Unknown option.")
    if not new:
        raise HTTPException(400, "Type the new name.")
    if new != old and new.lower() in [x.lower() for x in HANDLING if x != old]:
        raise HTTPException(409, "Another option already has this name.")
    n = db.query(models.WorkItem).filter(models.WorkItem.handling == old).update({"handling": new}, synchronize_session=False)
    audit(db, user, "nature_rename", f"{old} -> {new} ({n} activities)")
    if new != old:
        _nature_remember(db, alias=(old, new))
    _nature_save(db, opts=[new if x == old else x for x in HANDLING])
    return _nature_state(db)


@router.delete("/nature")
def nature_remove(body: NatureIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    """Remove an option. Activities that use it are moved to another option (move_to), or left blank."""
    from ..logic import HANDLING
    name = (body.name or "").strip()
    if name not in HANDLING:
        raise HTTPException(404, "Unknown option.")
    if len(HANDLING) <= 1:
        raise HTTPException(400, "Keep at least one option.")
    used = db.query(models.WorkItem).filter(models.WorkItem.handling == name).count()
    to = (body.move_to or "").strip()
    if used and to and (to not in HANDLING or to == name):
        raise HTTPException(400, "Choose another option to move the activities to.")
    if used:
        db.query(models.WorkItem).filter(models.WorkItem.handling == name).update({"handling": to}, synchronize_session=False)
    audit(db, user, "nature_remove", f"{name}: {used} activities moved to {to or 'not recorded'}")
    if to:
        _nature_remember(db, alias=(name, to))
    _nature_save(db, opts=[x for x in HANDLING if x != name])
    return _nature_state(db)


@router.post("/regions")
def add_region(body: NameIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    n = body.name.strip()
    if n and not db.query(models.Region).filter(models.Region.name == n).first():
        db.add(models.Region(name=n, sort=99))
        db.commit()
    return {"ok": True}


@router.delete("/regions/{name}")
def del_region(name: str, user=Depends(require_admin), db: Session = Depends(get_db)):
    if db.query(models.Employee).filter(models.Employee.region == name).count():
        raise HTTPException(400, "Employees are tagged to this region; it cannot be removed.")
    db.query(models.Region).filter(models.Region.name == name).delete()
    db.commit()
    return {"ok": True}


# ---------- frequencies ----------
class FreqIn(BaseModel):
    name: Optional[str] = None
    days: Optional[float] = None


def _reload(db):
    from ..logic import load_required
    db.flush()
    load_required(db)


@router.get("/frequencies")
def list_freqs(user=Depends(require_admin), db: Session = Depends(get_db)):
    from sqlalchemy import func
    used = dict(db.query(models.WorkItem.frequency, func.count(models.WorkItem.id)).group_by(models.WorkItem.frequency))
    return [{"id": f.id, "name": f.name, "days": f.days, "used": used.get(f.name, 0)}
            for f in db.query(models.Frequency).order_by(models.Frequency.sort, models.Frequency.id)]


@router.post("/frequencies")
def add_freq(body: FreqIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    n = " ".join((body.name or "").split())[:40]
    if not n:
        raise HTTPException(400, "Enter a name for the frequency.")
    if db.query(models.Frequency).filter(models.Frequency.name.ilike(n)).first():
        raise HTTPException(409, "That frequency already exists.")
    d = body.days if body.days and body.days > 0 else 1
    db.add(models.Frequency(name=n, days=d, sort=db.query(models.Frequency).count() + 1))
    audit(db, user, "frequency_add", f"{n} ({d:g} days)")
    _reload(db)
    db.commit()
    return list_freqs(user, db)


@router.patch("/frequencies/{fid}")
def edit_freq(fid: int, body: FreqIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    f = db.get(models.Frequency, fid)
    if not f:
        raise HTTPException(404, "Frequency not found.")
    if body.days is not None:
        if body.days <= 0:
            raise HTTPException(400, "Working days must be more than 0.")
        f.days = body.days
    if body.name is not None and body.name.strip() and body.name.strip() != f.name:
        n = " ".join(body.name.split())[:40]
        if db.query(models.Frequency).filter(models.Frequency.name.ilike(n), models.Frequency.id != fid).first():
            raise HTTPException(409, "That frequency already exists.")
        db.query(models.WorkItem).filter(models.WorkItem.frequency == f.name).update({"frequency": n})
        f.name = n
    audit(db, user, "frequency_edit", f"{f.name}: {f.days:g} days")
    _reload(db)
    db.commit()
    return list_freqs(user, db)


@router.delete("/frequencies/{fid}")
def del_freq(fid: int, user=Depends(require_admin), db: Session = Depends(get_db)):
    f = db.get(models.Frequency, fid)
    if not f:
        raise HTTPException(404, "Frequency not found.")
    n = db.query(models.WorkItem).filter(models.WorkItem.frequency == f.name).count()
    if n:
        raise HTTPException(400, f"{n} activities use {f.name}; it cannot be removed. Rename it instead, or change those activities first.")
    if db.query(models.Frequency).count() <= 1:
        raise HTTPException(400, "Keep at least one frequency.")
    db.delete(f)
    audit(db, user, "frequency_delete", f.name)
    _reload(db)
    db.commit()
    return list_freqs(user, db)


# ---------- data capture fields, for all functions or one function ----------
class FieldsIn(BaseModel):
    function_id: Optional[int] = None
    fields: Optional[dict] = None     # None with a function id = use the default again


@router.get("/capture-fields")
def get_fields(function_id: Optional[int] = None, user=Depends(require_admin), db: Session = Depends(get_db)):
    from ..logic import field_config, function_fields, has_own_fields
    own = {f.id for f in db.query(models.Function) if has_own_fields(db, f.id)}
    return {"fields": function_fields(db, function_id) if function_id else field_config(db), "default": field_config(db),
            "own": bool(function_id and function_id in own), "functions_with_own": sorted(own)}


@router.put("/capture-fields")
def put_fields(body: FieldsIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    from ..logic import FIELD_DEFAULTS
    clean = {k: v for k, v in (body.fields or {}).items() if k in FIELD_DEFAULTS and v in ("required", "optional", "hidden")}
    if body.function_id:
        fn = db.get(models.Function, body.function_id)
        if not fn:
            raise HTTPException(404, "Function not found.")
        set_setting(db, f"capture_fields:{fn.id}", clean if body.fields is not None else None)
        audit(db, user, "capture_fields", f"{fn.name}: {clean if body.fields is not None else 'default'}")
    else:
        set_setting(db, "capture_fields", clean)
        audit(db, user, "capture_fields", f"default: {clean}")
    _reload(db)
    db.commit()
    return get_fields(body.function_id, user, db)


# ---------- people flags ----------
class FlagIn(BaseModel):
    external: Optional[bool] = None
    exclude: Optional[bool] = None
    reason: Optional[str] = None
    verified: Optional[bool] = None


@router.get("/people")
def people(q: str = "", flagged: bool = False, user=Depends(require_admin), db: Session = Depends(get_db)):
    fnames = {f.id: f.name for f in db.query(models.Function)}
    qry = db.query(models.Employee)
    if flagged:
        qry = qry.filter((models.Employee.external == True) | (models.Employee.exclude == True) | (models.Employee.verified == False))  # noqa
    if q:
        qry = qry.filter((models.Employee.name.ilike(f"%{q}%")) | (models.Employee.code.ilike(f"%{q}%")))
    out = []
    for e in qry.order_by(models.Employee.grade_rank.desc()).limit(200):
        out.append({"code": e.code, "name": e.name, "grade": e.grade, "position": e.position, "function": fnames.get(e.function_id),
                    "external": e.external, "exclude": e.exclude, "reason": e.flag_reason, "verified": e.verified, "source": e.source,
                    "added_by": e.added_by})
    return out


@router.patch("/people/{code}")
def flag_person(code: str, body: FlagIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    e = db.get(models.Employee, code)
    if not e:
        raise HTTPException(404, "Employee not found.")
    if body.external is not None:
        e.external = body.external
    if body.exclude is not None:
        e.exclude = body.exclude
    if body.reason is not None:
        e.flag_reason = body.reason[:300]
    if body.verified is not None:
        e.verified = body.verified
    audit(db, user, "flag", f"{code}: {body.model_dump(exclude_none=True)}")
    db.commit()
    return {"ok": True}


# ---------- re-tagging ----------
@router.get("/retag-requests")
def retag_requests(user=Depends(require_admin), db: Session = Depends(get_db)):
    fnames = {f.id: f.name for f in db.query(models.Function)}
    out = []
    for r in db.query(models.RetagRequest).order_by(models.RetagRequest.status.desc(), models.RetagRequest.created_at.desc()).limit(300):
        e = db.get(models.Employee, r.code)
        names = lambda c: (db.get(models.Employee, c).name if c and db.get(models.Employee, c) else (c or "-"))
        man = (r.kind or "function") == "manager"
        out.append({"id": r.id, "kind": "Reporting line" if man else "Function", "code": r.code, "name": e.name if e else r.code, "grade": e.grade if e else "",
                    "function": fnames.get(e.function_id) if e else "",
                    "from": names(r.from_manager) if man else fnames.get(r.from_function_id), "to": names(r.to_manager) if man else fnames.get(r.to_function_id),
                    "by": r.requested_by, "note": r.note, "status": r.status, "at": r.created_at.isoformat(timespec="minutes")})
    return out


@router.post("/retag-requests/{rid}/{action}")
def resolve_retag(rid: int, action: str, user=Depends(require_admin), db: Session = Depends(get_db)):
    r = db.get(models.RetagRequest, rid)
    if not r or r.status != "Pending":
        raise HTTPException(404, "Pending request not found.")
    if action == "approve":
        e = db.get(models.Employee, r.code)
        if e and (r.kind or "function") == "manager":
            from .staffadmin import _would_loop
            if not db.get(models.Employee, r.to_manager) or _would_loop(db, e.code, r.to_manager):
                raise HTTPException(400, "The new manager no longer exists or the change would create a circular reporting line. Reject the request.")
            e.manager_code = r.to_manager
            e.overrides = sorted(set(e.overrides or []) | {"manager"})   # kept at the next master sheet import
        elif e:
            e.function_id = r.to_function_id   # region and recorded activities move with the person
            e.unit_id = None
        r.status = "Approved"
    elif action == "reject":
        r.status = "Rejected"
    else:
        raise HTTPException(400, "Action must be approve or reject.")
    r.resolved_by, r.resolved_at = user.username, datetime.utcnow()
    audit(db, user, f"retag_{action}", r.code)
    db.commit()
    return {"ok": True}


# ---------- function name ----------
class FnRename(BaseModel):
    name: str


@router.patch("/functions/{fid}")
def rename_function(fid: int, body: FnRename, user=Depends(require_admin), db: Session = Depends(get_db)):
    """Rename a function here. The HR master sheet's name is kept, so the next import still finds it."""
    fn = db.get(models.Function, fid)
    if not fn:
        raise HTTPException(404, "Function not found.")
    name = " ".join((body.name or "").split())[:200]
    if len(name) < 2:
        raise HTTPException(400, "Type the new name.")
    for f in db.query(models.Function).filter(models.Function.id != fid):
        if name.lower() in (f.name.lower(), (f.hr_name or "").lower()):
            raise HTTPException(409, f"Another function is already called {f.name if name.lower() == f.name.lower() else f.name + ' (HR: ' + f.hr_name + ')'}.")
    old = fn.name
    if not fn.hr_name:
        fn.hr_name = old
    fn.name = name
    # the Current State (As Is) carries function names as text: the renamed function follows there too
    for x in db.query(models.AsIsEmp).filter(models.AsIsEmp.function == old):
        x.function = name
    for x in db.query(models.AsIsEmp).filter(models.AsIsEmp.orig_function == old):
        x.orig_function = name
    audit(db, user, "function_rename", f"{old} -> {name}")
    db.commit()
    return {"id": fn.id, "name": fn.name, "hr_name": fn.hr_name}


# ---------- function status ----------
@router.post("/functions/{fid}/reopen")
def reopen(fid: int, user=Depends(require_admin), db: Session = Depends(get_db)):
    fn = db.get(models.Function, fid)
    if not fn:
        raise HTTPException(404, "Function not found.")
    fn.status = "In progress"
    audit(db, user, "reopen", fn.name)
    db.commit()
    return {"ok": True}


@router.get("/audit")
def audit_log(user=Depends(require_admin), db: Session = Depends(get_db)):
    return [{"at": a.at.isoformat(timespec="seconds"), "user": a.username, "action": a.action, "detail": a.detail}
            for a in db.query(models.AuditLog).order_by(models.AuditLog.id.desc()).limit(300)]


