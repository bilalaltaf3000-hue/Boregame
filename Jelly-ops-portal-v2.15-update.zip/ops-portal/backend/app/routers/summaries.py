"""Work summaries in the organogram: who has one, the pop-up, and the admin's background run."""
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import func
from sqlalchemy.orm import Session

from .. import empsum, models, roleai
from ..db import get_db
from ..security import audit, require_admin, require_dashboard, sees_everything, view_ids
from .roleoverlap import _run_out

router = APIRouter(prefix="/api/sum")


def require_sum(user=Depends(require_dashboard)):
    if user.role != "admin" and not user.can_summary:
        raise HTTPException(403, "Work summaries are not available for this login.")
    return user


def _fids(user, db):
    return {f.id for f in db.query(models.Function.id)} if sees_everything(user) else view_ids(user, db)


@router.get("/codes")
def codes(user=Depends(require_sum), db: Session = Depends(get_db)):
    """Employees with recorded activities (the organogram shows the button only for them)."""
    fids = _fids(user, db)
    n = dict(db.query(models.WorkItem.employee_code, func.count(models.WorkItem.id)).group_by(models.WorkItem.employee_code))
    emps = db.query(models.Employee.code, models.Employee.function_id).filter(models.Employee.code.in_(list(n) or ["-"]))
    return {"codes": [c for c, f in emps if f in fids]}


@router.get("/person/{code}")
def person(code: str, user=Depends(require_sum), db: Session = Depends(get_db)):
    e = db.get(models.Employee, code)
    if not e or e.function_id not in _fids(user, db):
        raise HTTPException(404, "Employee not found.")
    from ..logic import Calc
    days = Calc(db).days
    acts = empsum.acts_of(db, [code]).get(code, [])
    s = db.get(models.EmpSummary, code)
    txt = {x["id"]: x["text"] for x in ((s.items or []) if s else [])}
    rows = []
    for a in acts:
        d = days.get(a["freq"] or "Daily", 1.0) or 1.0
        rows.append({"id": a["id"], "text": txt.get(a["id"]) or a["desc"], "desc": a["desc"], "cat": a["cat"], "freq": a["freq"],
                     "volume": a["volume"], "vday": round(a["volume"] / d, 1) if a["volume"] else 0})
    vol = sorted([r for r in rows if r["volume"] > 0], key=lambda r: -r["vday"])
    non = [r for r in rows if not r["volume"] > 0]
    fn = db.get(models.Function, e.function_id) if e.function_id else None
    team = db.query(func.count(models.Employee.code)).filter(models.Employee.manager_code == code, models.Employee.resigned == False).scalar()  # noqa: E712
    return {"code": code, "name": e.name, "position": e.position or "", "grade": e.grade or "", "region": e.region or "", "function": fn.name if fn else "",
            "team": team, "activities": len(rows), "volume_based": len(vol), "non_volume": len(non), "items_day": round(sum(r["vday"] for r in vol)),
            "volume": vol, "non": non, "few": len(rows) < empsum.MIN_ACTS,
            "summary": (s.summary if s else "") or "", "at": s.at.isoformat(timespec="minutes") if s and s.at else None,
            "stale": bool(s) and s.acts_hash != empsum.acts_hash(acts), "written": bool(s), "can_write": user.role == "admin"}


@router.post("/person/{code}/write")
def write_now(code: str, user=Depends(require_admin), db: Session = Depends(get_db)):
    e = db.get(models.Employee, code)
    if not e:
        raise HTTPException(404, "Employee not found.")
    if roleai.busy(db):
        raise HTTPException(409, "The AI is busy with a run. Try again when it finishes.")
    acts = empsum.acts_of(db, [code]).get(code, [])
    if not acts:
        raise HTTPException(400, "No activities recorded for this employee.")
    try:
        empsum.write_one(db, roleai.settings(db), e, acts)
    except roleai.AiError as ex:
        raise HTTPException(400, str(ex))
    db.commit()
    return {"ok": True}


# ---------------------------------------------------------------- the admin's run
@router.get("/status")
def status(user=Depends(require_admin), db: Session = Depends(get_db)):
    acts = empsum.acts_of(db, [c for (c,) in db.query(models.WorkItem.employee_code).distinct()])
    live = {c for (c,) in db.query(models.Employee.code).filter(models.Employee.resigned == False)}  # noqa: E712
    have = {s.code: s.acts_hash for s in db.query(models.EmpSummary)}
    withacts = [c for c, a in acts.items() if a and c in live]
    written = [c for c in withacts if c in have]
    stale = [c for c in written if have[c] != empsum.acts_hash(acts[c])]
    last = db.query(models.RoRun).filter(models.RoRun.kind == "summary").order_by(models.RoRun.id.desc()).first()
    return {"with_activities": len(withacts), "written": len(written) - len(stale), "stale": len(stale), "missing": len(withacts) - len(written),
            "run": _run_out(last)}


class RunIn(BaseModel):
    function_id: Optional[int] = None
    only_changed: bool = True


@router.post("/run")
def run(body: RunIn, user=Depends(require_admin), db: Session = Depends(get_db)):
    try:
        roleai.models_list(roleai.settings(db))
        r = empsum.start(db, body.function_id, body.only_changed, user)
    except roleai.AiError as e:
        raise HTTPException(400, str(e))
    audit(db, user, "sum_run", f"function {body.function_id or 'all'} {'changed only' if body.only_changed else 'all'}")
    db.commit()
    return _run_out(r)


@router.post("/run/stop")
def stop(user=Depends(require_admin), db: Session = Depends(get_db)):
    r = db.query(models.RoRun).filter(models.RoRun.kind == "summary", models.RoRun.status.in_(["queued", "running"])).first()
    if not r:
        raise HTTPException(400, "No work-summary run is going.")
    roleai.cancel(r.id)
    return {"ok": True}
