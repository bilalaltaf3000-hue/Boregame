#!/bin/bash
# Checks the on-premise AI for Role Overlap: the GPU, the vLLM server and one test answer.
# Usage: bash /data/opt/ops-portal/deploy/check_ai.sh            (vLLM on 127.0.0.1:8000, model "qwen")
#        bash /data/opt/ops-portal/deploy/check_ai.sh http://127.0.0.1:8000 qwen
URL="${1:-http://127.0.0.1:8000}"
MODEL="${2:-qwen}"
echo "== GPU"
if command -v nvidia-smi >/dev/null; then
  nvidia-smi --query-gpu=name,memory.used,memory.total,utilization.gpu --format=csv
else
  echo "nvidia-smi not found (the GPU driver tools are not on the PATH)"
fi
echo
echo "== vLLM models at $URL"
curl -s --max-time 10 "$URL/v1/models" || echo "No answer: vLLM is not running, or not on this address."
echo
echo
echo "== Test answer from \"$MODEL\" (can take up to a minute the first time)"
START=$(date +%s)
curl -s --max-time 180 "$URL/v1/chat/completions" -H 'Content-Type: application/json' \
  -d "{\"model\":\"$MODEL\",\"temperature\":0,\"max_tokens\":60,\"messages\":[{\"role\":\"user\",\"content\":\"Are these the same work? A: Reconcile the nostro account daily. B: Match nostro ledger entries every day. Answer JSON: {\\\"same\\\": \\\"yes or no\\\", \\\"reason\\\": \\\"a few words\\\"}\"}]}" \
  | python3 -c "import sys,json; d=json.load(sys.stdin); print(d['choices'][0]['message']['content'])" 2>/dev/null \
  || echo "No valid answer. Check: sudo journalctl -u vllm-qwen -n 50 --no-pager"
echo "($(( $(date +%s) - START )) s)"
