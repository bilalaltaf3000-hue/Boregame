#!/usr/bin/env bash
# Nightly SQLite backup. Add to cron:  0 1 * * * /data/opt/ops-portal/deploy/backup_db.sh
set -e
SRC=/data/opt/ops-portal/backend/data/portal.db
DEST=/data/opt/ops-portal/backups
mkdir -p "$DEST"
python3 - "$SRC" "$DEST/portal_$(date +%Y%m%d_%H%M).db" <<'PY'
import sqlite3, sys
src = sqlite3.connect(sys.argv[1]); dst = sqlite3.connect(sys.argv[2])
src.backup(dst); dst.close(); src.close()
PY
find "$DEST" -name 'portal_*.db' -mtime +30 -delete
