import React, { useMemo, useState } from 'react'
import { fmt, pct, PAL, TYPE_COL, pcs } from '../org.js'
import { PeopleModal, ChartBox, css, Modal, Kpi, Ring } from '../ui.jsx'
import { TypeFilter } from './Dashboard.jsx'
import { L } from '../prefs.js'

// Geographical spread: where the workforce sits, its mix by region and how each function is spread.
const NOT_SET = 'Region not set'

export default function Regions({ org, theme, showLine, go }) {
  const [et, setEt] = useState('')
  const [role, setRole] = useState('')
  const [modal, setModal] = useState(null)
  const [allRegions, setAllRegions] = useState(false)
  const [cardsAll, setCardsAll] = useState(false)
  const { F } = org
  const C = useMemo(() => org.C.filter(p => (!et || (et === 'FTE' ? p.fte : !p.fte)) && (!role || (p.st || '') === role)), [org, et, role])
  const regions = useMemo(() => {
    const m = new Map()
    C.forEach(p => { const k = p.rg || ''; if (!m.has(k)) m.set(k, []); m.get(k).push(p) })
    return [...m.entries()].map(([k, ps]) => ({ k, label: k || NOT_SET, ps, fte: ps.filter(p => p.fte).length }))
      .sort((a, b) => (!a.k) - (!b.k) || b.ps.length - a.ps.length)
  }, [C])
  const set = regions.filter(r => r.k)
  const col = {}; set.forEach((r, i) => { col[r.k] = PAL[i % PAL.length] }); col[''] = css('--none') || '#C6D3D1'
  const total = C.length
  const top10 = regions.slice(0, 10)
  const top = set[0]
  const top3 = set.slice(0, 3).reduce((a, r) => a + r.ps.length, 0)
  const ftc = C.filter(p => !p.fte).length
  const unset = regions.find(r => !r.k)
  const people = (title, list) => setModal({ title, list })
  const openP = p => { if (showLine) showLine(p.id); else go('org', p.i) }
  const scope = [et, role && `${role} Employees`].filter(Boolean).join(', ')
  const fns = useMemo(() => {
    const ids = [...new Set(C.map(p => p.f))]
    return ids.map(f => ({ f, name: F[f], ps: C.filter(p => p.f === f) })).sort((a, b) => a.name.localeCompare(b.name))
  }, [C])

  // doughnut: the largest regions, the rest grouped
  const MAXD = 7
  const dn = set.length > MAXD + 1 ? [...set.slice(0, MAXD), { k: '__other', label: 'Other Regions', ps: set.slice(MAXD).flatMap(r => r.ps) }] : set
  const dcol = r => r.k === '__other' ? css('--ink-3') : col[r.k]

  return <section className="view on regview">
    <header className="pghead">
      <h1>{L('reg.title')}</h1>
      <div className="pg-side">
        <TypeFilter value={et} onChange={setEt} />
        <span className="seg sm" role="group" aria-label="Service or support">
          {[['Service', 'Service'], ['Support', 'Support'], ['', 'All']].map(([v, l]) => <button key={v} type="button" aria-pressed={role === v} onClick={() => setRole(v)}>{l}</button>)}</span>
      </div>
    </header>

    {!total ? <div className="empty">No employees match this selection.</div> : <>
      <div className="kpis">
        <Kpi icon="people" label={L('reg.employees')} value={fmt(total)} sub={scope || 'In All Regions'} onClick={() => people('Employees', C)} />
        <Kpi icon="pin" label={L('reg.regions')} value={fmt(set.length)} sub={unset ? `${fmt(unset.ps.length)} Without a Region` : 'All Employees Placed'} />
        <Kpi icon="ftc" tone="ftc" label={L('reg.ftc')} value={pcs(ftc, total)} sub={`${fmt(ftc)} FTC Employees`} viz={<Ring value={pct(ftc, total)} color="var(--ftc-ink)" track="color-mix(in srgb, var(--ftc) 30%, var(--surface))" />} onClick={() => people('FTC Employees', C.filter(p => !p.fte))} />
      </div>

      <div className="grid rv-grid" style={{ marginTop: 14 }}>
        <div className="panel">
          <div className="rhead"><div><h3>{L('reg.byregion')}</h3></div>
            <span className="legend"><span><i style={{ background: 'var(--fte)' }} />FTE</span><span><i style={{ background: 'var(--ftc)' }} />FTC</span></span></div>
          <RegionBars regions={top10} theme={theme} C={C} people={people} />
          {regions.length > 10 && <div className="pfoot"><span className="formula">Top 10 of {fmt(regions.length)} regions</span><button className="linkbtn" onClick={() => setAllRegions(true)}>View All Regions ›</button></div>}
        </div>
        <div className="panel">
          <h3>{L('reg.share')}</h3>
          <div className="rv-donut">
            <div className="rv-ring">
              <ChartBox deps={[C, theme]} config={() => ({ type: 'doughnut', data: { labels: dn.map(r => r.label), datasets: [{ data: dn.map(r => r.ps.length), backgroundColor: dn.map(dcol), borderColor: css('--surface'), borderWidth: 2 }] },
                options: { cutout: '68%', onClick: (e, el) => { if (el.length) { const r = dn[el[0].index]; people(`${r.label}: employees`, r.ps) } }, plugins: { legend: { display: false } } } })} />
              <div className="rv-center"><b>{fmt(set.reduce((a, r) => a + r.ps.length, 0))}</b><span>with a region</span></div>
            </div>
            <ul className="rv-legend">{dn.map(r => <li key={r.k}><button onClick={() => people(`${r.label}: employees`, r.ps)}>
              <i style={{ background: dcol(r) }} /><span>{r.label}</span><b>{pcs(r.ps.length, total)}</b></button></li>)}</ul>
          </div>
        </div>
      </div>

      <h2 className="rv-h2">{L('reg.glance')}</h2>
      <div className="regcards">{(cardsAll ? regions : regions.slice(0, 10)).map(r => {
        const n = r.ps.length, svc = r.ps.filter(p => p.st === 'Service').length, sup = r.ps.filter(p => p.st === 'Support').length
        const byF = new Map(); r.ps.forEach(p => byF.set(p.f, (byF.get(p.f) || 0) + 1))
        const topF = [...byF.entries()].sort((a, b) => b[1] - a[1]).slice(0, 3)
        return <article key={r.k} className={'regcard' + (r.k ? '' : ' unset')} style={{ '--rc': col[r.k] }}>
          <button className="rc-top" onClick={() => people(`${r.label}: employees`, r.ps)}>
            <span className="rc-name">{r.label}</span><b>{fmt(n)}</b><em>{pcs(n, total)} of employees</em></button>
          <div className="rc-row"><span>FTE / FTC</span>
            <div className="bar thin"><i style={{ width: pct(r.fte, n) + '%', background: 'var(--fte)' }} /><i style={{ width: pct(n - r.fte, n) + '%', background: 'var(--ftc)' }} /></div>
            <small><button className="linkbtn" onClick={() => people(`${r.label}: FTE`, r.ps.filter(p => p.fte))}>{fmt(r.fte)}</button> / <button className="linkbtn" onClick={() => people(`${r.label}: FTC`, r.ps.filter(p => !p.fte))}>{fmt(n - r.fte)}</button></small></div>
          <div className="rc-row"><span>Service / Support</span>
            {svc + sup ? <><div className="bar thin" title={`${svc} service, ${sup} support`}><i style={{ width: pct(svc, svc + sup) + '%', background: TYPE_COL.Service }} /><i style={{ width: pct(sup, svc + sup) + '%', background: TYPE_COL.Support }} /></div>
              <small>{fmt(svc)} / {fmt(sup)}</small></> : <em className="rc-na">Not yet marked in data capture</em>}</div>
          {fns.length > 1 && <ul className="rc-fns">{topF.map(([f, c]) => <li key={f}><span><i style={{ background: org.FCOL[f] }} />{F[f]}</span><b>{fmt(c)}</b></li>)}</ul>}
        </article> })}</div>

      {fns.length > 1 && set.length > 1 && <div className="panel" style={{ marginTop: 18 }}>
        <div className="rhead"><div><h3>{L('reg.across')}</h3></div></div>
        <div className="tw"><table className="heat rv-heat">
          <thead><tr><th>Function</th>{regions.map(r => <th key={r.k} className="num">{r.label}</th>)}<th className="num">Total</th></tr></thead>
          <tbody>{fns.map(fx => { const cells = regions.map(r => fx.ps.filter(p => (p.rg || '') === r.k)); const mx = Math.max(1, ...cells.map(c => c.length))
            return <tr key={fx.f}><td><span className="dot" style={{ background: org.FCOL[fx.f] }} />{fx.name}</td>
              {cells.map((c, i) => <td key={i} className={'num hc' + (c.length / mx > 0.6 ? ' dk' : '')} style={{ '--h': c.length ? 0.1 + 0.8 * c.length / mx : 0 }}>
                {c.length ? <button className="cellbtn" onClick={() => people(`${fx.name}: ${regions[i].label}`, c)}>{fmt(c.length)}</button> : ''}</td>)}
              <td className="num"><b>{fmt(fx.ps.length)}</b></td></tr> })}
            <tr className="tot"><td>Total</td>{regions.map(r => <td key={r.k} className="num">{fmt(r.ps.length)}</td>)}<td className="num">{fmt(total)}</td></tr></tbody></table></div>
      </div>}
    </>}

    {regions.length > 10 && <div style={{ textAlign: 'center', marginTop: 12 }}><button className="btn" onClick={() => setCardsAll(a => !a)}>{cardsAll ? 'Show Top 10 Regions' : `Show All ${fmt(regions.length)} Regions`}</button></div>}
    {allRegions && <Modal wide title={L('reg.byregion')} sub={`${fmt(regions.length)} regions`} onClose={() => setAllRegions(false)}>
      <RegionBars regions={regions} theme={theme} C={C} people={r => { setAllRegions(false); people(r) }} raw={people} />
    </Modal>}
    {modal && <PeopleModal title={modal.title} people={modal.list} F={F} heads={org.headIds} onPerson={openP} onClose={() => setModal(null)} />}
  </section>
}

// regions as stacked FTE / FTC bars (the top 10 on the page, all of them in the popup)
function RegionBars({ regions, theme, C, people, raw }) {
  const open = r => (raw || people)(`${r.label}: employees`, r.ps)
  return <div className="rv-bars" style={{ height: Math.max(220, regions.length * 34 + 40) }}>
    <ChartBox deps={[C, theme, regions.length]} config={() => ({ type: 'bar', data: { labels: regions.map(r => r.label), datasets: [
      { label: 'FTE', data: regions.map(r => r.fte), backgroundColor: css('--fte'), borderRadius: 3, barThickness: 18 },
      { label: 'FTC', data: regions.map(r => r.ps.length - r.fte), backgroundColor: css('--ftc'), borderRadius: 3, barThickness: 18 }] },
      options: { indexAxis: 'y', onClick: (e, el) => { if (el.length) open(regions[el[0].index]) },
        onHover: (e, el) => { e.native.target.style.cursor = el.length ? 'pointer' : 'default' },
        scales: { x: { stacked: true, grid: { color: css('--line') }, ticks: { precision: 0 } }, y: { stacked: true, grid: { display: false } } },
        plugins: { legend: { display: false }, tooltip: { callbacks: { footer: it => `Total ${fmt(regions[it[0].dataIndex].ps.length)}` } } } } })} />
  </div>
}
