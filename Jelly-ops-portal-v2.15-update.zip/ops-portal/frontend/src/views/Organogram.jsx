import React, { useEffect, useMemo, useRef, useState } from 'react'
import * as d3 from 'd3'
import { fmt, short, TYPE_COL } from '../org.js'
import { L, vacKindL } from '../prefs.js'
import { css, Dot, TypeTag, typeName, types } from '../ui.jsx'
import { api } from '../api.js'
import { LV_NAME, LV_TAG } from './Benchmark.jsx'
import { SummaryModal, useSumCodes } from './Summary.jsx'
import { canLayers, canSummary } from '../rights.js'
import LayerPanel from './LayerPanel.jsx'

function benchTip(b, p) {
  const lv = LV_NAME[b.l] || ''
  const t = !b.t ? 'Not assessed (only permanent staff in a tagged function are).' : b.t === 'above' ? `Above max grade: ${p.g} against max ${b.mx} for ${LV_NAME[b.bl] || lv} (${b.g} notch${b.g === 1 ? '' : 'es'} above).`
    : b.t === 'at' ? `At the max grade for ${LV_NAME[b.bl] || lv} (${b.mx}).` : `Opportunity to grow: the max for ${LV_NAME[b.bl] || lv} is ${b.mx}.`
  return `Level: ${lv}${b.a ? ' (from the reporting line)' : ' (set by the admin)'} · ${b.y ? 'Layer ' + b.y : 'Layer 6 · Teams'}${b.b ? ', an extra layer (reports to a Teams member)' : ''}${b.mn ? ` · band ${b.mn} / ${b.mx}` : ''}\n${t}`
}

const CAP = 12, W = 204, H = 74, GX = 16, GY = 44, VERT_AT = 4

function Tags({ p, org }) {
  return <div className="tags">
    <span className="tag">{org.F[p.f] || 'No function'}</span>{p.g && p.g !== '-' && <span className="tag">Grade {p.g}</span>}<span className="tag">Code {p.id}</span>
    <span className="tag">Layer {p.ly > 0 ? p.ly : '?'}</span>{!(p === org.ROOT || p.m < 0 || org.P[p.m] === org.ROOT) && <span className="tag"><TypeTag p={p} /></span>}
    {p.ext && <span className="pill p-warn">External</span>}{p.rs && <span className="pill p-bad">Resigned, not counted</span>}{p.xf && <span className="pill" style={{ background: 'var(--surface-2)', color: '#6B747C' }}>Cross Functional Transition (Outside COSO)</span>}{p.exc && <span className="pill p-warn">Excluded from counts</span>}{p.st && <span className="tpill" style={{ '--tc': TYPE_COL[p.st] }}>{p.st}</span>}{p.added && <span className="pill p-warn">Added by function</span>}{p.ctx && <span className="pill" style={{ background: 'var(--surface-2)', color: 'var(--ink-3)' }}>{org.empType && (org.empType === 'FTE') !== p.fte ? `Shown to connect the chart; not counted as ${org.empType}` : 'Shown for context, outside your access'}</span>}
  </div>
}

function PersonCard({ p, org, onOpen }) {
  const noTeam = !p.kids.length
  return <button className="card" style={{ '--fc': org.FCOL[p.f], opacity: p.ctx && org.empType ? 0.55 : 1 }} onClick={() => onOpen(p)}>
    <span className="nm">{p.n}{p.rs ? <span className="pill p-bad" style={{ marginLeft: 6 }}>Resigned</span> : p.exc && !org.includeFlagged ? <span className="pill p-warn" style={{ marginLeft: 6 }} title="Marked exclude from count">Excluded</span> : null}</span><span className="ps">{p.pos || '-'}</span>
    <span className="ft"><span><Dot fte={p.fte} dc={p.dc} dw={p.dw} />{p.g}</span>
      {!noTeam ? <span><span className="team">{fmt(p.nk)}</span> direct, {fmt(p.team)} total</span>
        : <span>No direct reports</span>}
    </span></button>
}

function PeopleView({ p, org, open, openClassic, largeTeam, showLine }) {
  const [showList, setShowList] = useState(false)
  const [q, setQ] = useState('')
  useEffect(() => { setShowList(false); setQ('') }, [p])
  const chain = []; let x = p, n = 0; while (x.m >= 0 && n++ < 300) { x = org.P[x.m]; chain.unshift(x) }
  const big = p.kids.length > largeTeam
  const cards = big ? p.kids.filter(k => k.kids.length || k.rk >= org.senior) : p.kids
  const rest = big ? p.kids.filter(k => !(k.kids.length || k.rk >= org.senior)) : []
  const restF = rest.filter(k => k.fte).length
  const ql = q.toLowerCase()
  const listRows = rest.filter(k => !ql || (k.n + ' ' + k.id + ' ' + k.pos).toLowerCase().includes(ql))
  return <>
    <div className="chain">{chain.map(c => <React.Fragment key={c.i}><button onClick={() => open(c)}>{c.n}</button><span>/</span></React.Fragment>)}</div>
    <div className="focus" style={{ '--fc': org.FCOL[p.f] }}>
      <div><h3>{p.n}</h3><div className="role">{p.pos || '-'}</div><Tags p={p} org={org} />
        <div className="row-actions" style={{ marginTop: 12 }}>{showLine && !p.ctx && <button className="btn pri" onClick={() => showLine(p.id)}>Reporting line chart</button>}
          {p.kids.length > 0 && <button className="btn" onClick={() => openClassic(p)}>View as classic chart</button>}</div></div>
      <div className="kv"><div><b>{fmt(p.nk)}</b><span>Direct reports</span></div><div><b>{fmt(p.team)}</b><span>Total team</span></div><div><b>{p.depthBelow}</b><span>Layers below</span></div></div>
    </div>
    {p.kids.length > 0 && <><div className="stem" /><div className="reports">
      <div className="rhead"><h4>Direct Reports ({fmt(p.kids.length)}), most senior first</h4><span className="legend"><span><span className="dot d-fte" />FTE</span><span><span className="dot d-ftc" />FTC</span></span></div>
      {cards.length > 0 && <div className="cards">{cards.map(k => <PersonCard key={k.i} p={k} org={org} onOpen={open} />)}</div>}
      {rest.length > 0 && <div className="ic" style={{ marginTop: cards.length ? 16 : 0 }}>
        <div className="icrow"><div><b>{fmt(rest.length)}</b> more direct reports with no team of their own, grouped &nbsp;
          <span className="legend" style={{ display: 'inline-flex' }}><span><span className="dot d-fte" />{fmt(restF)} FTE</span><span><span className="dot d-ftc" />{fmt(rest.length - restF)} FTC</span></span>
          <div className="bar" style={{ marginTop: 8, maxWidth: 360 }}><i style={{ width: restF / rest.length * 100 + '%', background: 'var(--fte)' }} /><i style={{ width: (rest.length - restF) / rest.length * 100 + '%', background: 'var(--ftc)' }} /></div></div>
          <button onClick={() => setShowList(s => !s)}>{showList ? 'Hide list' : 'Show list'}</button></div>
        {showList && <div className="iclist"><input value={q} onChange={e => setQ(e.target.value)} placeholder="Filter this team by name, code or position" />
          <div className="tw scroll"><table><thead><tr><th>Name</th><th>Code</th><th>Position</th><th>Grade</th><th>Type</th></tr></thead><tbody>
            {listRows.slice(0, 500).map(k => <tr key={k.i} className="click" onClick={() => open(k)}><td>{k.n}</td><td>{k.id}</td><td>{k.pos || '-'}</td><td>{k.g}</td><td><TypeTag p={k} /></td></tr>)}
            {listRows.length > 500 && <tr><td colSpan={5} style={{ color: 'var(--ink-3)' }}>Showing 500 of {fmt(listRows.length)}. Filter to narrow down.</td></tr>}
          </tbody></table></div></div>}
      </div>}
    </div></>}
  </>
}

// where each open vacant position sits on a chart: under the open position it reports to; if that one is filled,
// under the employee who filled it; otherwise under its manager (the top of the chart when the manager is not on show).
// Employees who report to an open vacant position show under it.
export function vacMapOf(vac, O, R1) {
  const byId = new Map(vac.map(v => [v.id, v])), byMgr = new Map(), byParent = new Map(), byVacEmp = new Map(), underVac = new Set()
  const add = (m, k, v) => m.set(k, [...(m.get(k) || []), v])
  if (!O || !R1) return { byMgr, byParent, byVacEmp, underVac }
  const open = vac.filter(v => v.open > 0)
  open.forEach(v => {
    let p = v, n = 0
    while (p.parent_id && byId.has(p.parent_id) && n++ < 30) {
      const pv = byId.get(p.parent_id)
      if (pv.open > 0) { add(byParent, pv.id, v); return }
      const who = [...(pv.filled_log || [])].reverse().find(x => x.code && O.byId.get(x.code))
      if (who) { add(byMgr, who.code, v); return }
      p = pv
    }
    add(byMgr, p.manager_code && O.byId.get(p.manager_code) ? p.manager_code : R1.id, v)
  })
  open.forEach(v => (v.reports || []).forEach(r => { const p = O.byId.get(r.code); if (p && O.counted(p)) { add(byVacEmp, v.id, p); underVac.add(p.id) } }))
  return { byMgr, byParent, byVacEmp, underVac }
}

export function Classic({ root: root0, org, onOpenList, onReroot, theme, largeTeam, compact, focus, onFocus, simple, vacancies, onVacancy, top, bench, sums, onSummary, onSelect, side, tools, marks, strip }) {   // strip: a layer strip shown above the chart in full screen   // marks: {code: {c: 'mv' | 'new' | 'gone', t: note}} (CHRO As Is / To Be)
   // tools: the page's chart buttons, repeated in full screen
   // side: the layer panel, also shown in full screen   // sums: employee codes with a work summary button   // bench: grade benchmark per employee code   // top: the chart does not go above this person
  // vacancies: { byMgr: employee code -> open vacant positions, byParent: vacancy id -> the vacant positions reporting
  // to it }, shown as dashed boxes in the manager's team (never counted as employees)
  const vacOf = n => (vacancies && vacancies.byMgr.get(n.id)) || []
  const vacKids = v => (vacancies && vacancies.byParent.get(v.id)) || []
  const vacEmps = v => (vacancies && vacancies.byVacEmp && vacancies.byVacEmp.get(v.id)) || []   // employees who report to the vacant position
  const underVac = (vacancies && vacancies.underVac) || null
  const kidsOf = n => underVac ? n.kids.filter(k => !underVac.has(k.id)) : n.kids
  const vacOpen = v => (v.open || 0) + vacKids(v).reduce((a, k) => a + vacOpen(k), 0)
  const vacBranch = v => vacKids(v).length || vacEmps(v).length
  const vKey = v => 'v' + v.id   // an open vacant position with a team: closed until clicked, like a manager
  const vacOpenNow = v => vacBranch(v) && expanded.has(vKey(v))
  const hasTeam = k => kidsOf(k).length || vacOf(k).length
  const buildVac = (v, force) => {   // a vacant position with other vacant positions (and employees) reporting to it
    const o = { vac: v, kids: [] }, ch = vacKids(v), es = vacEmps(v)
    if (!force && !expanded.has(vKey(v))) return o
    const eb = es.filter(e => hasTeam(e) && expanded.has(e.i))
    const leaves = [...es.filter(e => !eb.includes(e)).map(e => ({ p: e, kids: [] })), ...ch.filter(k => !vacOpenNow(k)).map(k => ({ vac: k, kids: [] }))], br = ch.filter(k => vacOpenNow(k))
    if (leaves.length) { if (!br.length && !eb.length && leaves.length <= 5) o.kids.push(...leaves); else o.kids.push({ col: true, items: leaves, kids: [] }) }
    o.kids.push(...eb.map(build))
    o.kids.push(...br.map(buildVac))
    return o
  }
  // simple: the dashboard chart. Clicking anyone shows the line from the top down to them and their own team, nothing else.
  // focus mode (reporting line): the chain from the top down to the focus person, who is highlighted,
  // with their own team below. Managers in the chain show only the next person on the line.
  const anc = useMemo(() => { if (!focus) return null; const a = []; let x = focus, n = 0; while (x !== top && x.m >= 0 && n++ < 300) { x = org.P[x.m]; a.unshift(x) } return a }, [focus, org, top])   // never above `top`
  const next = useMemo(() => { const m = new Map(); if (anc) { const ch = [...anc, focus]; for (let i = 0; i < ch.length - 1; i++) m.set(ch[i].i, ch[i + 1]) } return m }, [anc])
  const root = focus ? (anc[0] || focus) : root0
  // reporting line through vacant positions: where each open vacant position sits (its host employee, or the vacant
  // position above it) and which vacant position each employee reports to
  const vmap = useMemo(() => {
    const host = new Map(), par = new Map(), emp = new Map(), byId = new Map()
    if (vacancies) {
      vacancies.byMgr.forEach((vs, code) => vs.forEach(v => { host.set(v.id, code); byId.set(v.id, v) }))
      vacancies.byParent.forEach((vs, pid) => vs.forEach(v => { par.set(v.id, pid); byId.set(v.id, v) }))
      if (vacancies.byVacEmp) vacancies.byVacEmp.forEach((ps, vid) => ps.forEach(p => emp.set(p.id, vid)))
    }
    return { host, par, emp, byId }
  }, [vacancies])
  const vchainOf = vid => { const c = []; let x = vid, n = 0; while (x != null && vmap.byId.has(x) && n++ < 30) { c.unshift(vmap.byId.get(x)); x = vmap.par.get(x) } return c }
  const hostOf = vid => { const c = vchainOf(vid); return c.length ? org.byId.get(vmap.host.get(c[0].id)) : null }
  const [vfocus, setVfocus] = useState(null)   // reporting line mode: the vacant position clicked (its line from the top and its team)
  useEffect(() => { if (vfocus != null && (!vmap.byId.has(vfocus) || hostOf(vfocus) !== focus)) setVfocus(null) }, [focus, vmap])
  const vline = useMemo(() => {   // {host, chain, end: 'vac' | person}
    if (!simple || !vacancies) return null
    if (vfocus != null && vmap.byId.has(vfocus)) { const h = hostOf(vfocus); return h && h === focus ? { host: h, chain: vchainOf(vfocus), end: 'vac' } : null }
    if (focus && vmap.emp.has(focus.id)) { const ch = vchainOf(vmap.emp.get(focus.id)), h = ch.length && org.byId.get(vmap.host.get(ch[0].id)); return h && focus.m >= 0 && org.P[focus.m] === h ? { host: h, chain: ch, end: focus } : null }
    return null
  }, [vfocus, focus, vmap, simple, vacancies])
  const [full, setFull] = useState(false)
  const wrap = useRef(null)
  const start = () => new Set([focus ? focus.i : root.i])
  const [expanded, setExpanded] = useState(start)
  const [fitKey, setFitKey] = useState(0)
  const zoomRef = useRef(null)
  useEffect(() => { setExpanded(start()); setFitKey(k => k + 1) }, [root, focus])
  useEffect(() => { setFitKey(k => k + 1) }, [full, vacancies])   // fit again when the vacant boxes are shown or hidden
  useEffect(() => {   // fit again when the window or the panel changes size
    const el = wrap.current; if (!el || typeof ResizeObserver === 'undefined') return
    let t; const ro = new ResizeObserver(() => { clearTimeout(t); t = setTimeout(() => setFitKey(k => k + 1), 150) })
    ro.observe(el); return () => { ro.disconnect(); clearTimeout(t) }
  }, [])
  useEffect(() => {
    if (!full) return
    const k = e => { if (e.key === 'Escape') { e.stopImmediatePropagation(); setFull(false) } }
    window.addEventListener('keydown', k, true); return () => window.removeEventListener('keydown', k, true)
  }, [full])

  // Children: managers (people with a team) side by side; people without a team stacked in a
  // column beside them. Only very large groups of people without a team are summarised in one box.
  const build = n => {
    if (vline && n === vline.host && (vline.end === 'vac' || n !== focus)) {   // the line goes on through vacant positions
      const ch = vline.chain
      const vl = i => i < ch.length - 1 ? { vac: ch[i], kids: [vl(i + 1)], vline: true }
        : vline.end === 'vac' ? Object.assign(buildVac(ch[i], true), { vfoc: true }) : { vac: ch[i], kids: [build(vline.end)], vline: true }
      return { p: n, kids: [vl(0)], line: true }
    }
    if (next.has(n.i)) {   // manager on the reporting line above the focus person
      const c = next.get(n.i), o = { p: n, kids: [build(c)], line: true }
      const others = simple ? [] : n.kids.filter(k => k !== c)
      if (others.length) o.kids.push({ grp: true, others: true, parent: n, rest: others, kids: [] })
      return o
    }
    const o = { p: n, kids: [] }
    const vs = vacOf(n)
    const nk = kidsOf(n)
    if (!expanded.has(n.i) || (!nk.length && !vs.length)) return o
    // expanded managers become their own branches; everyone else is a box in a tidy column block
    const sub = nk.filter(k => hasTeam(k) && expanded.has(k.i))
    const rest = nk.filter(k => !sub.includes(k))
    const withTeam = rest.filter(k => hasTeam(k)), noTeam = rest.filter(k => !hasTeam(k))
    let items = [...withTeam, ...noTeam].map(k => ({ p: k, kids: [] }))
    if (noTeam.length > largeTeam) {
      const keep = noTeam.filter(k => k.rk >= org.senior).slice(0, 20)
      items = [...withTeam, ...keep].map(k => ({ p: k, kids: [] }))
      items.push({ grp: true, parent: n, rest: noTeam.filter(k => !keep.includes(k)), kids: [] })
    }
    items.push(...vs.filter(v => !vacOpenNow(v)).map(v => ({ vac: v, kids: [] })))
    const vb = vs.filter(v => vacOpenNow(v))
    if (items.length) {
      if (!sub.length && !vb.length && items.length <= 5) o.kids.push(...items)
      else o.kids.push({ col: true, items, kids: [] })
    }
    o.kids.push(...sub.map(build))
    o.kids.push(...vb.map(buildVac))
    return o
  }
  const lay = o => {
    if (o.col) { const n = o.items.length; o.cols = Math.ceil(n / 5); o.rows = Math.ceil(n / o.cols); o.w = 14 + o.cols * W + (o.cols - 1) * GX; return }
    o.kids.forEach(lay)
    if (!o.kids.length) { o.w = W; return }
    if (o.kids.length === 1 && o.kids[0].col) { o.solo = true; o.w = Math.max(W, 7 + o.kids[0].w); return }
    o.w = Math.max(W, o.kids.reduce((s, k) => s + k.w, 0) + GX * (o.kids.length - 1))
  }
  const placeCol = (c, x, y, spineTop, out, links) => {
    c.items.forEach((k, i) => {
      const ci = Math.floor(i / c.rows), r = i % c.rows
      k.x = x + 14 + ci * (W + GX); k.y = y + r * (H + 12); out.push(k)
      links.push(`M${k.x - 7},${k.y + H / 2}H${k.x}`)
    })
    for (let ci = 0; ci < c.cols; ci++) {
      const sx = x + 7 + ci * (W + GX), last = Math.min(c.rows, c.items.length - ci * c.rows) - 1
      links.push(`M${sx},${spineTop}V${y + last * (H + 12) + H / 2}`)
    }
    if (c.cols > 1) links.push(`M${x + 7},${spineTop}H${x + 7 + (c.cols - 1) * (W + GX)}`)
  }
  const place = (o, x, y, out, links) => {
    if (o.solo) {
      o.x = x; o.y = y; out.push(o)
      placeCol(o.kids[0], x + 7, y + H + 22, y + H, out, links); return
    }
    o.x = x + (o.w - W) / 2; o.y = y; out.push(o)
    if (!o.kids.length) return
    const tot = o.kids.reduce((s, k) => s + k.w, 0) + GX * (o.kids.length - 1); let cx = x + (o.w - tot) / 2
    const my = y + H + GY / 2
    o.kids.forEach(k => {
      if (k.col) { links.push(`M${o.x + W / 2},${y + H}V${my}H${cx + 7}`); placeCol(k, cx, y + H + GY, my, out, links) }
      else { place(k, cx, y + H + GY, out, links); links.push(`M${o.x + W / 2},${y + H}V${my}H${k.x + W / 2}V${k.y}`) }
      cx += k.w + GX
    })
  }

  useEffect(() => {
    const el = wrap.current
    let svg = d3.select(el).select('svg')
    if (svg.empty()) {
      svg = d3.select(el).append('svg'); svg.append('g')
      zoomRef.current = d3.zoom().scaleExtent([0.15, 2]).on('zoom', e => svg.select('g').attr('transform', e.transform))
      svg.call(zoomRef.current).on('dblclick.zoom', null)
    }
    const g0 = svg.select('g'); g0.selectAll('*').remove()
    const t = build(root); lay(t); const nodes = [], links = []; place(t, 0, 0, nodes, links)
    g0.append('g').selectAll('path').data(links).join('path').attr('class', 'lk').attr('d', d => d)
    const tr = (s, n) => s.length > n ? s.slice(0, n - 1) + '…' : s
    const bm = d => bench && !d.grp && !d.vac ? bench.people[d.p.id] : null
    const g = g0.append('g').selectAll('g').data(nodes).join('g').attr('transform', d => `translate(${d.x},${d.y})`)
      .attr('class', d => d.vac ? 'cn vac' + (d.vfoc ? ' vfoc' : d.vline ? ' vline' : '') + (d.vac.removed ? ' vk-removed' : d.vac.kind === 'replacement' ? ' vk-repl' : d.vac.kind === 'pending' ? ' vk-pend' : '') : 'cn' + (d.grp ? ' grp' : '') + (focus ? (d.p === focus && !(vline && vline.end === 'vac') ? ' focus' : d.line ? ' line' : '') : d.p === root ? ' root' : '') + (!d.grp && !d.p.kids.length && d.p.rk >= org.senior ? ' warn' : '') + (!d.grp && d.p.ctx && org.empType ? ' ctx' : '') + (!d.grp && d.p.hs ? ' hcs' : '') + (!d.grp && d.p.xf ? ' xf' : '') + (marks && !d.grp && !d.vac && marks[d.p.id] ? ' mk-' + marks[d.p.id].c : '') + (bm(d) ? (bm(d).t ? ' bm-' + bm(d).t : ' bm-na') + (bm(d).b ? ' bm-xl' : '') : '')).style('cursor', 'pointer')
    g.append('rect').attr('class', 'box').attr('width', W).attr('height', H).attr('rx', 9)
    const r = g.filter(d => !d.grp && !d.vac)
    // headcount saved (surrendered role): the box is cut through
    r.filter(d => d.p.hs).append('path').attr('class', 'hcs-cut').attr('d', `M6 ${H - 4} L${W - 6} 4`)
    r.append('rect').attr('class', 'bar').attr('width', 4).attr('height', H - 16).attr('y', 8).attr('rx', 2).style('fill', d => bm(d) ? null : d.p.ext || d.p.id === '00000' || /external/i.test(d.p.g || '') ? '#5F6B73' : org.FCOL[d.p.f])   // external advisers (e.g. a legal partner): grey, apart from the function colours
    // the admin's note on the person (Admin, Employees, Organogram note): a small tab on top of the card
    const nt = r.filter(d => d.p.note).append('g').attr('class', 'note-tab').attr('transform', 'translate(10,-8)')
    nt.append('rect').attr('height', 15).attr('rx', 4).attr('width', d => Math.min(W - 20, 12 + Math.min(d.p.note.length, 33) * 5.4))
    nt.append('text').attr('x', 6).attr('y', 11).text(d => d.p.note.length > 33 ? d.p.note.slice(0, 32).trimEnd() + '…' : d.p.note)
    nt.append('title').text(d => d.p.note)
    const hasSum = d => sums && onSummary && sums.has(d.p.id)
    r.append('text').attr('x', 14).attr('y', 22).style('font-weight', 700).style('font-size', '12.5px').text(d => tr(d.p.n, bm(d) ? (hasSum(d) ? 17 : 20) : hasSum(d) ? 23 : 26))
    // the work summary button: a small box in the top-right corner (only for employees with recorded activities)
    const sb = r.filter(hasSum).append('g').attr('class', 'sumbtn').attr('transform', `translate(${W - 26},8)`)
    sb.append('rect').attr('width', 18).attr('height', 18).attr('rx', 5)
    sb.append('rect').attr('class', 'sb-o').attr('x', 4).attr('y', 4).attr('width', 10).attr('height', 10).attr('rx', 1.5)
    sb.append('path').attr('d', 'M6.5 7.5h5M6.5 9.5h5M6.5 11.5h3')
    sb.append('title').text('Summary of work')
    sb.on('click', (e, d) => { e.stopPropagation(); onSummary(d.p) }).on('dblclick', e => e.stopPropagation())
    // grade benchmark: the level used (and the layer when it is beyond the model)
    // (the level tag, e.g. DIV / DEPT, is not shown on the cards)
    r.append('text').attr('class', 't2').attr('x', 14).attr('y', 39).text(d => tr(d.p.pos || '-', 31))
    // the top person and the function heads: no FTE / FTC tag (grade only)
    const lead = p => p === org.ROOT || p.m < 0 || org.P[p.m] === org.ROOT || (org.headIds && org.headIds.has(p.i))
    r.append('text').attr('class', d => marks && marks[d.p.id] ? 't3 mk-t' : 't3').attr('x', 14).attr('y', 59).text(d => marks && marks[d.p.id] ? tr([d.p.g && d.p.g !== '-' ? d.p.g : '', marks[d.p.id].t].filter(Boolean).join(' · '), 34) : bm(d) && bm(d).t
      ? [d.p.g, bm(d).t === 'at' ? 'at max' : `max ${bm(d).mx}`].join(' · ')
      : [d.p.g && d.p.g !== '-' ? d.p.g : '', d.p.hs ? (d.p.rp ? 'Replacement' + (d.p.dc ? ' · PR' : '') : 'Surrender') : lead(d.p) ? '' : typeName(d.p), d.p.rs ? 'Resigned' : d.p.ext ? 'External' : ''].filter(Boolean).join(' · '))
    r.append('text').attr('class', 'cnt').attr('x', W - 12).attr('y', 59).attr('text-anchor', 'end')
      .text(d => { const nk = kidsOf(d.p).length, nv = vacOf(d.p).reduce((a, v) => a + (v.open || 0), 0), more = nv && !expanded.has(d.p.i) ? ` +${fmt(nv)} vacant` : ''
        const tm = nk && d.p.team > nk ? ` · Team ${fmt(d.p.team)}` : ''   // the whole team below them, beside the direct reports
        return d.line ? fmt(nk) + ' direct' + (nv ? ` +${fmt(nv)} vacant` : '') + tm : nk ? (expanded.has(d.p.i) ? '▴ ' : '▾ ') + fmt(nk) + more + tm : nv ? (expanded.has(d.p.i) ? '▴ ' : '▾ ') + fmt(nv) + ' vacant' : '' })
    // vacant / to be hired positions: a dashed box with the position, FTE or FTC, the grade and how many
    const vg = g.filter(d => d.vac)
    vg.append('text').attr('class', 'vtag').attr('x', 12).attr('y', 20).text(d => d.vac.removed ? `Hiring removed${d.vac.removed_on ? ' · ' + d.vac.removed_on : ''}` : `${vacKindL(d.vac.kind)}${d.vac.open > 1 ? ` · ${fmt(d.vac.open)} positions` : ' · To be hired'}`)
    vg.append('text').attr('x', 12).attr('y', 39).style('font-weight', 700).style('font-size', '12px').text(d => tr(d.vac.position || 'Position', 30))
    vg.append('text').attr('class', 't3').attr('x', 12).attr('y', 59).text(d => [d.vac.emp_type, d.vac.grade, d.vac.unit].filter(Boolean).join(' · '))
    const vb = vg.filter(d => vacBranch(d.vac)), vl = vg.filter(d => !vacBranch(d.vac))
    vl.filter(d => d.vac.open > 1).append('text').attr('class', 'vcount').attr('x', W - 12).attr('y', 59).attr('text-anchor', 'end').text(d => '×' + fmt(d.vac.open))
    vl.filter(d => d.vac.open <= 1 && d.vac.jd).append('text').attr('class', 'vjd').attr('x', W - 12).attr('y', 59).attr('text-anchor', 'end').text('View JD ›')
    // a vacant position with a team: its own direct reports (staff, and the vacant positions directly under it); click to open
    vb.append('text').attr('class', 'cnt').attr('x', W - 12).attr('y', 59).attr('text-anchor', 'end').text(d => {
      const ne = vacEmps(d.vac).length, nv = vacKids(d.vac).reduce((a, k) => a + (k.open || 0), 0), op = expanded.has(vKey(d.vac)) ? '▴ ' : '▾ '
      return op + (ne ? fmt(ne) + (nv ? ` +${fmt(nv)} vacant` : '') : fmt(nv) + ' vacant') })
    vb.filter(d => d.vac.jd).append('text').attr('class', 'vjd vjd-top').attr('x', W - 12).attr('y', 20).attr('text-anchor', 'end').text('JD ›')
      .on('click', (e, d) => { e.stopPropagation(); onVacancy && onVacancy(d.vac) })
    const gr = g.filter(d => d.grp)
    gr.append('text').attr('x', 14).attr('y', 26).style('font-weight', 800).style('font-size', '15px').text(d => d.others ? `${fmt(d.rest.length)} other direct report${d.rest.length === 1 ? '' : 's'}` : `${fmt(d.rest.length)} more`)
    gr.append('text').attr('class', 't2').attr('x', 14).attr('y', 44).text(d => types().map(t => { const n = d.rest.filter(t.test).length; return n || t.k === 'fte' || t.k === 'ftc' ? `${fmt(n)} ${t.label}` : '' }).filter(Boolean).join(', '))
    gr.append('text').attr('class', 'cnt').attr('x', 14).attr('y', 62).text(d => d.others ? `Show ${short(d.parent.n, 18)}'s team` : 'Open list')
    g.append('title').text(d => d.vac ? `Vacant: ${d.vac.position}${d.vac.open > 1 ? ` (${d.vac.open} positions)` : ''}${d.vac.filled ? ` · ${d.vac.filled} of ${d.vac.count} filled` : ''}\n${d.vac.emp_type}${d.vac.grade ? ', grade ' + d.vac.grade : ''}${d.vac.note ? '\n' + d.vac.note : ''}\n${vacBranch(d.vac) ? 'Click to open or close its team.' + (d.vac.jd ? ' JD › reads the job description.' : '') : d.vac.jd ? 'Click to read the job description.' : 'Click for the details.'} Not counted as an employee.` : bm(d) ? `${d.p.n}\n${d.p.pos || ''}\n${benchTip(bm(d), d.p)}` : simple && !d.grp ? `${d.p.n}\n${d.p.pos || ''}` : d.grp ? (d.others ? 'Centre the chart on this manager to see their whole team' : 'Open the full list in employee view')
      : d.line ? `${d.p.n}\n${d.p.pos}\nOn the reporting line. Click to centre the chart on this person.`
      : `${d.p.n}\n${d.p.pos}\n${org.F[d.p.f]}\nClick to expand or collapse. Double-click to ${focus ? 'centre the chart on' : 'make'} this person${focus ? '' : ' the top'}.`)
    g.on('click', (e, d) => {
      if (!d.grp && !d.vac && onSelect) onSelect(d.p)   // the layer panel follows the person clicked
      if (d.vac) {
        if (!vacBranch(d.vac)) { onVacancy && onVacancy(d.vac); return }
        if (simple) {   // reporting line: the line from the top down to this vacant position, and its team; clicked again: one step back
          if (d.vfoc) { const up = vmap.par.get(d.vac.id); setVfocus(up != null ? up : null); return }
          const h = hostOf(d.vac.id); setVfocus(d.vac.id); if (h && h !== focus) onFocus && onFocus(h); setTimeout(() => setFitKey(k => k + 1), 0); return }
        setExpanded(s => { const n = new Set(s), k = vKey(d.vac); n.has(k) ? n.delete(k) : n.add(k); return n })
        setTimeout(() => setFitKey(k => k + 1), 0); return }
      if (simple && !d.grp) {
        // the top person always returns to the plain view (no expand / collapse: that would open the whole organisation);
        // the highlighted person steps back up one level; anyone else becomes the highlighted person
        const top = d.p === root0 || d.p.m < 0
        const back = focus && d.p === focus ? (focus.m >= 0 && org.P[focus.m] !== root0 ? org.P[focus.m] : null) : null
        onFocus && onFocus(top ? null : d.p === focus ? back : d.p); return }
      if (d.grp) { d.others && onFocus ? onFocus(d.parent) : onOpenList(d.parent); return }
      if (d.line && onFocus) { onFocus(d.p); return }
      if (!hasTeam(d.p)) return
      setExpanded(s => { const n = new Set(s); n.has(d.p.i) ? n.delete(d.p.i) : n.add(d.p.i); return n })
      setTimeout(() => setFitKey(k => k + 1), 0)   // fit the chart again so the opened team is in view
    })
    g.on('dblclick', (e, d) => { if (d.grp || d.vac) return; focus && onFocus ? onFocus(d.p) : onReroot(d.p) })
    el._layout = { t, nodes }
  }, [expanded, root, org, theme, vacancies, bench, sums, marks, vline])

  useEffect(() => {
    const el = wrap.current; const L = el._layout; if (!L) return
    const bw = L.t.w, bh = Math.max(...L.nodes.map(n => n.y)) + H, cw = el.clientWidth, ch = el.clientHeight
    let k = Math.min(1, (cw - 40) / bw, (ch - 40) / bh), tx = (cw - bw * k) / 2
    const kmin = simple ? 0.36 : 0.5   // the dashboard chart zooms out further so an expanded team still fits
    if (k < kmin) { k = kmin; tx = cw / 2 - (L.t.x + W / 2) * k }
    const fn = focus && L.nodes.find(n => n.p === focus)
    if (fn && bw * k > cw - 40) tx = cw / 2 - (fn.x + W / 2) * k   // keep the focus person in view
    d3.select(el).select('svg').call(zoomRef.current.transform, d3.zoomIdentity.translate(tx, 24).scale(k))
  }, [fitKey])

  const expandLevel = () => {
    const add = []
    const walk = o => { if (o.grp || o.vac) return; if (o.col) { o.items.forEach(walk); return } if (o.line || expanded.has(o.p.i)) o.kids.forEach(walk); else if (o.p.kids.length) add.push(o.p.i) }
    walk(build(root)); setExpanded(s => new Set([...s, ...add])); setFitKey(k => k + 1)
  }
  const up = top && (focus || root) === top ? null : focus ? (focus.m >= 0 ? org.P[focus.m] : null) : (root.m >= 0 ? org.P[root.m] : null)
  return <div className={'cc' + (full ? ' full' : '')}>
    <div className="cc-bar">
      {!simple && up && <button className="btn" onClick={() => focus ? onFocus(up) : onReroot(up)}>{`Up to ${short(up.n, 24)}`}</button>}
      {(!simple || (focus && focus !== root0)) && <button className="btn" onClick={expandLevel}>Expand One More Level</button>}
      {(!simple || (focus && focus !== root0)) && <button className="btn" onClick={() => { setExpanded(start()); setFitKey(k => k + 1) }}>Collapse</button>}
      {full && tools ? <span className="cc-tools">{tools}</span> : null}
      <button className="btn pri" onClick={() => setFull(f => !f)} title={full ? 'Back to the page (Esc)' : 'Open the chart full screen'}>{full ? 'Exit Full Screen' : 'Full Screen'}</button>
    </div>
    {full && strip ? <div className="cc-strip">{strip}</div> : null}
    <div className={full && side ? 'cc-body with-side' : 'cc-body'}>{full && side ? <div className="cc-side">{side}</div> : null}
      <div className={'ccwrap' + (compact ? ' compact' : '')} ref={wrap} /></div>
  </div>
}

function Sunburst({ org, onOpen, theme }) {
  const ref = useRef(null)
  useEffect(() => {
    const el = ref.current; el.innerHTML = ''
    const tip = document.getElementById('tip')
    const Wd = 720, R = Wd / 6
    const h = d3.hierarchy(org.ROOT, d => d.kids.length ? d.kids : null).sum(() => 1)
    const root = d3.partition().size([2 * Math.PI, h.height + 1])(h); root.each(d => { d.current = d })
    const arc = d3.arc().startAngle(d => d.x0).endAngle(d => d.x1).padAngle(d => Math.min((d.x1 - d.x0) / 2, 0.004)).padRadius(R * 1.5)
      .innerRadius(d => d.y0 * R).outerRadius(d => Math.max(d.y0 * R, d.y1 * R - 1))
    const svg = d3.select(el).append('svg').attr('viewBox', [-Wd / 2, -Wd / 2, Wd, Wd]).attr('role', 'img').attr('aria-label', 'Organisation by reporting line')
    const vis = d => d.y1 <= 3 && d.y0 >= 1 && d.x1 > d.x0
    const path = svg.append('g').selectAll('path').data(root.descendants().slice(1)).join('path')
      .attr('fill', d => org.FCOL[d.data.f]).attr('fill-opacity', d => vis(d.current) ? (d.children ? 0.9 : 0.55) : 0)
      .attr('pointer-events', d => vis(d.current) ? 'auto' : 'none').attr('d', d => arc(d.current))
    path.filter(d => d.children).style('cursor', 'pointer').on('click', clicked)
    path.on('mousemove', (e, d) => { tip.style.display = 'block'; tip.style.left = (e.clientX + 14) + 'px'; tip.style.top = (e.clientY + 14) + 'px'
      tip.innerHTML = `<b>${d.data.n}</b><br>${d.data.pos || ''}<br>${org.F[d.data.f]}${d.data.kids.length ? `<br>${fmt(d.data.nk)} direct, ${fmt(d.data.team)} total` : ''}` })
      .on('mouseleave', () => { tip.style.display = 'none' })
    const parent = svg.append('circle').datum(root).attr('r', R).attr('fill', css('--surface-2')).attr('stroke', css('--line')).attr('cursor', 'pointer').on('click', clicked)
    const t1 = svg.append('text').attr('text-anchor', 'middle').attr('y', -8).attr('fill', css('--ink')).style('font-weight', 800).style('font-size', '15px')
    const t2 = svg.append('text').attr('text-anchor', 'middle').attr('y', 14).attr('fill', css('--ink-3')).style('font-size', '12px')
    const t3 = svg.append('text').attr('text-anchor', 'middle').attr('y', 36).attr('fill', css('--teal')).style('font-size', '12px').style('font-weight', 700).style('cursor', 'pointer').text('Open in employee view')
    const label = p => { const n = p.data.n; t1.text(n.length > 22 ? n.slice(0, 21) + '…' : n); t2.text(fmt(p.data.team) + ' employees below'); t3.on('click', () => onOpen(p.data)) }
    label(root)
    function clicked(e, p) {
      if (!p) return; parent.datum(p.parent || root); label(p)
      root.each(d => { d.target = { x0: Math.max(0, Math.min(1, (d.x0 - p.x0) / (p.x1 - p.x0))) * 2 * Math.PI, x1: Math.max(0, Math.min(1, (d.x1 - p.x0) / (p.x1 - p.x0))) * 2 * Math.PI, y0: Math.max(0, d.y0 - p.depth), y1: Math.max(0, d.y1 - p.depth) } })
      const t = svg.transition().duration(matchMedia('(prefers-reduced-motion: reduce)').matches ? 0 : 650)
      path.transition(t).tween('data', d => { const i = d3.interpolate(d.current, d.target); return tt => { d.current = i(tt) } })
        .filter(function (d) { return +this.getAttribute('fill-opacity') || vis(d.target) })
        .attr('fill-opacity', d => vis(d.target) ? (d.children ? 0.9 : 0.55) : 0).attr('pointer-events', d => vis(d.target) ? 'auto' : 'none').attrTween('d', d => () => arc(d.current))
    }
    return () => { tip.style.display = 'none' }
  }, [org, theme])
  return <div className="sun-wrap">
    <div className="panel"><div id="sun" ref={ref} /></div>
    <div className="panel"><h2>Functions</h2><div className="flist">
      {org.fstats.map(s => <button key={s.f} onClick={() => onOpen(s.head || org.ROOT)}><i style={{ background: org.FCOL[s.f] }} /><span>{s.name}</span><b>{fmt(s.hc)}</b></button>)}</div></div>
  </div>
}

export default function Organogram({ org: full, orgFor, focus, setFocus, theme, lookups, user, showLine, notify, reloadOrg }) {
  const [layOn, setLayOn] = useState(false)
  const [selC, setSelC] = useState(null)
  const sums = useSumCodes(canSummary(user))
  const [sumCode, setSumCode] = useState(null)
  const [mode, setMode] = useState('people')
  const [q, setQ] = useState('')
  const [et, setEt] = useState('')
  const [classicCode, setClassicCode] = useState(null)
  const [code, setCode] = useState(() => full.P[focus]?.id)
  useEffect(() => { if (focus !== null && focus !== undefined && full.P[focus]) setCode(full.P[focus].id) }, [focus, full])
  const org = et && orgFor ? orgFor(et) : full
  const home = (org.scoped && org.fstats.length === 1 && org.fstats[0]?.head) || org.ROOT
  const p = (code && org.byId.get(code)) || home
  const classicRoot = (classicCode && org.byId.get(classicCode)) || null
  const setClassicRoot = x => setClassicCode(x ? x.id : null)
  const open = x => { setCode(x.id); const f = full.byId.get(x.id); if (f) setFocus(f.i); setMode('people'); window.scrollTo(0, 0) }
  const openClassic = x => { setClassicRoot(x); setMode('classic') }
  const hits = useMemo(() => { const s = q.trim().toLowerCase(); if (s.length < 2) return []; return org.P.filter(x => x.n.toLowerCase().includes(s) || x.id.toLowerCase().includes(s)).slice(0, 10) }, [q, org])
  return <section className="view on">
    <h1>Organogram</h1>
    <div className="orgbar">
      <div className="seg" role="group" aria-label="View">
        <button aria-pressed={mode === 'people'} onClick={() => setMode('people')}>Employee view</button>
        <button aria-pressed={mode === 'classic'} onClick={() => { setClassicRoot(p); setMode('classic') }}>Classic chart</button>
        <button aria-pressed={mode === 'whole'} onClick={() => setMode('whole')}>Whole organisation</button>
      </div>
      {canLayers(user) && mode === 'classic' && <button type="button" className={'btn bm-btn' + (layOn ? ' on' : '')} aria-pressed={layOn} onClick={() => setLayOn(!layOn)}>Layers</button>}
      <span className="seg" role="group" aria-label="Filter by employee type">
        {[['', 'All Employees'], ['FTE', 'FTE only'], ['FTC', 'FTC only']].map(([v, l]) => <button key={v} type="button" aria-pressed={et === v} onClick={() => setEt(v)}>{l}</button>)}</span>
      <div className="search"><input value={q} onChange={e => setQ(e.target.value)} placeholder="Search by name or employee code" aria-label="Search employees" />
        {hits.length > 0 && <div className="results" style={{ display: 'block' }}>{hits.map(x => <button key={x.i} onClick={() => { setQ(''); mode === 'classic' ? openClassic(x) : open(x) }}>{x.n} <small>{x.id}, {org.F[x.f]}</small></button>)}</div>}
        {q.trim().length >= 2 && !hits.length && <div className="results" style={{ display: 'block' }}><div style={{ padding: '10px 14px', color: 'var(--ink-3)', fontSize: 13 }}>No one matches that name or code.</div></div>}
      </div>
    </div>
    {et && <div className="msg ok" style={{ margin: '0 0 12px' }}>Showing {et} employees only: <b>{fmt(org.C.length)}</b> employees. Managers of the other type are shown in grey to connect the chart and are not counted.</div>}
    {mode === 'people' && <PeopleView p={p} org={org} open={open} openClassic={openClassic} largeTeam={lookups?.large_team || 40} showLine={showLine} />}
    {mode === 'classic' && <div className={canLayers(user) && layOn ? 'lp-wrap' : ''}>{canLayers(user) && layOn && <LayerPanel org={org} p={(selC && org.byId.get(selC)) || classicRoot || p} user={user} notify={notify} onChanged={reloadOrg} onPick={x => setSelC(x.id)} />}
      <Classic root={classicRoot || p} org={org} theme={theme} largeTeam={lookups?.large_team || 40} onReroot={setClassicRoot} onOpenList={x => open(x)} sums={sums} onSummary={x => setSumCode(x.id)} onSelect={x => setSelC(x.id)} /></div>}
    {sumCode && <SummaryModal code={sumCode} notify={notify} onClose={() => setSumCode(null)} />}
    {mode === 'whole' && <Sunburst org={org} onOpen={open} theme={theme} />}
    {user?.is_admin && org.orphans.length > 0 && <p className="formula" style={{ marginTop: 16 }}>{org.orphans.length} employees are not connected to {org.ROOT.n} because their manager code was not found. See Admin, Import.</p>}
    <div className="tip" id="tip" />
  </section>
}
